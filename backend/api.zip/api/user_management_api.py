"""
User Management API
Full CRUD endpoints for managing users - Admin only
"""

import logging
from datetime import datetime, timezone
from typing import Any, NoReturn, Optional, cast

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, EmailStr, Field

from backend.auth.dependencies import get_current_user, require_admin
from backend.auth.permissions import ROLE_PERMISSIONS, Permission, has_permission
from backend.db.runtime import get_db
from backend.utils.api_utils import sanitize_for_logging
from backend.utils.auth_utils import get_password_hash, get_pin_hash
from backend.utils.crypto_utils import get_pin_lookup_hash

logger = logging.getLogger(__name__)

user_management_router = APIRouter(prefix="/users", tags=["user-management"])


# ============================================================================
# Request/Response Models
# ============================================================================


class UserListItem(BaseModel):
    """User item in list response"""

    id: str
    username: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    role: str = "staff"
    is_active: bool = True
    created_at: Optional[datetime] = None
    last_login: Optional[datetime] = None
    permissions_count: int = 0


class UserListResponse(BaseModel):
    """Paginated user list response"""

    users: list[UserListItem]
    total: int
    page: int
    page_size: int
    total_pages: int


class UserDetailResponse(BaseModel):
    """Detailed user response"""

    id: str
    username: str
    email: Optional[str] = None
    full_name: Optional[str] = None
    role: str = "staff"
    is_active: bool = True
    created_at: Optional[datetime] = None
    last_login: Optional[datetime] = None
    permissions: list[str] = []
    custom_permissions: list[str] = []
    disabled_permissions: list[str] = []
    has_pin: bool = False


class AssignableUserItem(BaseModel):
    """User item for supervisor recount assignment."""

    username: str
    full_name: Optional[str] = None


class CreateUserRequest(BaseModel):
    """Request to create a new user"""

    username: str = Field(
        ...,
        min_length=3,
        max_length=50,
        pattern=r"^[a-zA-Z0-9_-]+$",
    )
    email: Optional[EmailStr] = None
    full_name: Optional[str] = Field(None, max_length=100)
    password: str = Field(..., min_length=6, max_length=128)
    pin: Optional[str] = Field(None, pattern=r"^\d{4}$")
    role: str = Field(
        default="staff",
        pattern=r"^(staff|supervisor|admin)$",
    )
    permissions: Optional[list[str]] = None


class UpdateUserRequest(BaseModel):
    """Request to update a user"""

    email: Optional[EmailStr] = None
    full_name: Optional[str] = Field(None, max_length=100)
    password: Optional[str] = Field(
        None,
        min_length=6,
        max_length=128,
    )
    pin: Optional[str] = Field(None, pattern=r"^\d{4}$")
    role: Optional[str] = Field(
        None,
        pattern=r"^(staff|supervisor|admin)$",
    )
    is_active: Optional[bool] = None
    permissions: Optional[list[str]] = None
    disabled_permissions: Optional[list[str]] = None


class BulkUserAction(BaseModel):
    """Request for bulk user actions"""

    user_ids: list[str]
    action: str = Field(
        ...,
        pattern=r"^(activate|deactivate|delete|change_role)$",
    )
    role: Optional[str] = Field(None, pattern=r"^(staff|supervisor|admin)$")


class BulkActionResult(BaseModel):
    """Result of bulk action"""

    success_count: int
    failed_count: int
    failed_ids: list[str]
    message: str


class ResetPasswordRequest(BaseModel):
    new_password: str = Field(..., min_length=6, max_length=128)


class ResetPinRequest(BaseModel):
    new_pin: str = Field(..., pattern=r"^\d{4}$")


# ============================================================================
# Helper Functions
# ============================================================================


def _user_to_list_item(user: dict[str, Any]) -> UserListItem:
    """Convert MongoDB user document to list item"""
    permissions = user.get("permissions", [])
    disabled = user.get("disabled_permissions", [])
    return UserListItem(
        id=str(user.get("_id", "")),
        username=user.get("username", ""),
        email=user.get("email"),
        full_name=user.get("full_name"),
        role=user.get("role", "staff"),
        is_active=user.get("is_active", True),
        created_at=user.get("created_at"),
        last_login=user.get("last_login"),
        permissions_count=len(permissions) - len(disabled),
    )


def _user_to_detail(user: dict[str, Any]) -> UserDetailResponse:
    """Convert MongoDB user document to detail response"""
    from backend.auth.permissions import get_user_permissions

    return UserDetailResponse(
        id=str(user.get("_id", "")),
        username=user.get("username", ""),
        email=user.get("email"),
        full_name=user.get("full_name"),
        role=user.get("role", "staff"),
        is_active=user.get("is_active", True),
        created_at=user.get("created_at"),
        last_login=user.get("last_login"),
        permissions=get_user_permissions(user),
        custom_permissions=user.get("permissions", []),
        disabled_permissions=user.get("disabled_permissions", []),
        has_pin=bool(user.get("pin_hash")),
    )


def _error_detail(message: str, code: str) -> dict[str, Any]:
    return {"success": False, "error": {"message": message, "code": code}}


def _raise_http_error(status_code: int, message: str, code: str) -> NoReturn:
    raise HTTPException(status_code=status_code, detail=_error_detail(message, code))


def _validate_permission_list(permissions: list[str]) -> None:
    valid_perms = [p.value for p in Permission]
    invalid = [p for p in permissions if p not in valid_perms]
    if invalid:
        _raise_http_error(
            status.HTTP_400_BAD_REQUEST,
            f"Invalid permissions: {', '.join(invalid)}",
            "INVALID_PERMISSIONS",
        )


def _is_self_update(existing: dict[str, Any], current_user: dict[str, Any]) -> bool:
    return str(existing.get("_id")) == str(current_user.get("_id"))


def _apply_role_update(
    update: dict[str, Any],
    request: UpdateUserRequest,
    existing: dict[str, Any],
    current_user: dict[str, Any],
) -> None:
    if request.role is None:
        return
    if _is_self_update(existing, current_user) and request.role != "admin":
        _raise_http_error(
            status.HTTP_400_BAD_REQUEST,
            "Cannot demote yourself",
            "SELF_DEMOTION_FORBIDDEN",
        )
    update["role"] = request.role


def _apply_active_update(
    update: dict[str, Any],
    request: UpdateUserRequest,
    existing: dict[str, Any],
    current_user: dict[str, Any],
) -> None:
    if request.is_active is None:
        return
    if _is_self_update(existing, current_user) and not request.is_active:
        _raise_http_error(
            status.HTTP_400_BAD_REQUEST,
            "Cannot deactivate yourself",
            "SELF_DEACTIVATION_FORBIDDEN",
        )
    update["is_active"] = request.is_active


async def _apply_email_update(
    update: dict[str, Any], db: Any, oid: Any, request: UpdateUserRequest
) -> None:
    if request.email is None:
        return
    if request.email:
        dup = await db.users.find_one({"email": request.email, "_id": {"$ne": oid}})
        if dup:
            _raise_http_error(status.HTTP_409_CONFLICT, "Email already exists", "DUPLICATE_EMAIL")
    update["email"] = request.email


def _apply_profile_update(update: dict[str, Any], request: UpdateUserRequest) -> None:
    if request.full_name is not None:
        update["full_name"] = request.full_name
    if request.password is not None:
        update["hashed_password"] = get_password_hash(request.password)
    if request.pin is not None:
        update["pin_hash"] = get_pin_hash(request.pin)
        update["pin_lookup_hash"] = get_pin_lookup_hash(request.pin)


def _apply_permissions_update(update: dict[str, Any], request: UpdateUserRequest) -> None:
    if request.permissions is not None:
        _validate_permission_list(request.permissions)
        update["permissions"] = request.permissions
    if request.disabled_permissions is not None:
        update["disabled_permissions"] = request.disabled_permissions


async def _build_update_payload(
    db: Any,
    oid: Any,
    request: UpdateUserRequest,
    existing: dict[str, Any],
    current_user: dict[str, Any],
) -> dict[str, Any]:
    update: dict[str, Any] = {"updated_at": datetime.now(timezone.utc).replace(tzinfo=None)}
    await _apply_email_update(update, db, oid, request)
    _apply_profile_update(update, request)
    _apply_role_update(update, request, existing, current_user)
    _apply_active_update(update, request, existing, current_user)
    _apply_permissions_update(update, request)
    return update


async def _resolve_user_or_raise(db: Any, user_id: str) -> tuple[Any, dict[str, Any]]:
    from bson import ObjectId

    try:
        oid = ObjectId(user_id)
    except Exception:
        _raise_http_error(status.HTTP_400_BAD_REQUEST, "Invalid user ID", "INVALID_ID")

    user = await db.users.find_one({"_id": oid})
    if not user:
        _raise_http_error(status.HTTP_404_NOT_FOUND, "User not found", "NOT_FOUND")

    return oid, cast(dict[str, Any], user)


# ============================================================================
# API Endpoints
# ============================================================================


@user_management_router.get("", response_model=UserListResponse)
async def list_users(
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(20, ge=1, le=100, description="Items per page"),
    search: Optional[str] = Query(
        None,
        description="Search by username, email, or name",
    ),
    role: Optional[str] = Query(None, description="Filter by role"),
    is_active: Optional[bool] = Query(
        None,
        description="Filter by active status",
    ),
    sort_by: str = Query("username", description="Sort field"),
    sort_order: str = Query(
        "asc",
        description="Sort order (asc/desc)",
    ),
    current_user: dict = Depends(require_admin),
):
    """
    List all users with pagination and filtering.
    Requires admin role.
    """
    db = get_db()

    # Build filter query
    query: dict[str, Any] = {}

    if search:
        query["$or"] = [
            {"username": {"$regex": search, "$options": "i"}},
            {"email": {"$regex": search, "$options": "i"}},
            {"full_name": {"$regex": search, "$options": "i"}},
        ]

    if role:
        query["role"] = role

    if is_active is not None:
        query["is_active"] = is_active

    # Count total
    total = await db.users.count_documents(query)

    # Sort
    sort_direction = 1 if sort_order == "asc" else -1
    sort_field = sort_by if sort_by in ["username", "email", "role", "created_at"] else "username"

    # Paginate
    skip = (page - 1) * page_size
    cursor = db.users.find(query).sort(sort_field, sort_direction).skip(skip).limit(page_size)

    users = await cursor.to_list(length=page_size)

    return UserListResponse(
        users=[_user_to_list_item(u) for u in users],
        total=total,
        page=page,
        page_size=page_size,
        total_pages=(total + page_size - 1) // page_size,
    )


@user_management_router.get("/assignable/staff", response_model=list[AssignableUserItem])
async def list_assignable_staff(
    current_user: dict = Depends(get_current_user),
):
    """
    List active staff users available for recount assignment.
    Accessible to supervisors/admins who can request recounts.
    """
    if not has_permission(current_user, Permission.COUNT_LINE_REJECT):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "success": False,
                "error": {
                    "message": f"Permission denied. Required: {Permission.COUNT_LINE_REJECT.value}",
                    "code": "PERMISSION_DENIED",
                    "category": "authorization",
                    "details": {
                        "required_permission": Permission.COUNT_LINE_REJECT.value,
                        "user_role": current_user.get("role"),
                    },
                },
            },
        )

    db = get_db()
    users = await db.users.find(
        {"role": "staff", "is_active": True},
        {"username": 1, "full_name": 1},
    ).to_list(length=200)
    users.sort(
        key=lambda user: (
            (user.get("full_name") or "").strip().lower(),
            user.get("username", "").lower(),
        )
    )
    return [
        AssignableUserItem(
            username=user.get("username", ""),
            full_name=user.get("full_name"),
        )
        for user in users
        if user.get("username")
    ]


@user_management_router.get("/{user_id}", response_model=UserDetailResponse)
async def get_user(
    user_id: str,
    current_user: dict = Depends(require_admin),
):
    """
    Get detailed information about a specific user.
    Requires admin role.
    """
    from bson import ObjectId

    db = get_db()

    # Validate ObjectId
    try:
        oid = ObjectId(user_id)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "success": False,
                "error": {
                    "message": "Invalid user ID",
                    "code": "INVALID_ID",
                },
            },
        ) from exc

    user = await db.users.find_one({"_id": oid})

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "success": False,
                "error": {
                    "message": "User not found",
                    "code": "NOT_FOUND",
                },
            },
        )

    return _user_to_detail(user)


@user_management_router.post(
    "",
    response_model=UserDetailResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_user(
    request: CreateUserRequest,
    current_user: dict = Depends(require_admin),
):
    """
    Create a new user.
    Requires admin role.
    """
    db = get_db()

    # Check if username exists
    existing = await db.users.find_one({"username": request.username})
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "success": False,
                "error": {
                    "message": "Username already exists",
                    "code": "DUPLICATE_USERNAME",
                },
            },
        )

    # Check if email exists (if provided)
    if request.email:
        existing_email = await db.users.find_one({"email": request.email})
        if existing_email:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "success": False,
                    "error": {
                        "message": "Email already exists",
                        "code": "DUPLICATE_EMAIL",
                    },
                },
            )

    # Validate permissions if provided
    if request.permissions:
        valid_perms = [p.value for p in Permission]
        invalid = [p for p in request.permissions if p not in valid_perms]
        if invalid:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "success": False,
                    "error": {
                        "message": (f"Invalid permissions: {', '.join(invalid)}"),
                        "code": "INVALID_PERMISSIONS",
                    },
                },
            )

    # Create user document
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    user_doc = {
        "username": request.username,
        "email": request.email,
        "full_name": request.full_name,
        "hashed_password": get_password_hash(request.password),
        "role": request.role,
        "is_active": True,
        "permissions": request.permissions or [],
        "disabled_permissions": [],
        "created_at": now,
        "updated_at": now,
    }

    # Add PIN if provided
    if request.pin:
        user_doc["pin_hash"] = get_pin_hash(request.pin)
        user_doc["pin_lookup_hash"] = get_pin_lookup_hash(request.pin)

    result = await db.users.insert_one(user_doc)
    user_doc["_id"] = result.inserted_id

    logger.info(
        "User created: %s by %s",
        sanitize_for_logging(request.username),
        current_user.get("username"),
    )

    return _user_to_detail(user_doc)


@user_management_router.put(
    "/{user_id}",
    response_model=UserDetailResponse,
)
async def update_user(
    user_id: str,
    request: UpdateUserRequest,
    current_user: dict = Depends(require_admin),
):
    """
    Update an existing user.
    Requires admin role.
    """
    from bson import ObjectId

    db = get_db()

    try:
        oid = ObjectId(user_id)
    except Exception:
        _raise_http_error(status.HTTP_400_BAD_REQUEST, "Invalid user ID", "INVALID_ID")

    existing = await db.users.find_one({"_id": oid})
    if not existing:
        _raise_http_error(status.HTTP_404_NOT_FOUND, "User not found", "NOT_FOUND")

    existing_doc = cast(dict[str, Any], existing)
    update = await _build_update_payload(db, oid, request, existing_doc, current_user)
    await db.users.update_one({"_id": oid}, {"$set": update})
    updated = await db.users.find_one({"_id": oid})

    logger.info(
        "User updated: %s by %s",
        sanitize_for_logging(existing_doc["username"]),
        current_user.get("username"),
    )

    if not updated:
        _raise_http_error(status.HTTP_404_NOT_FOUND, "User not found", "NOT_FOUND")

    return _user_to_detail(cast(dict[str, Any], updated))


@user_management_router.delete(
    "/{user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_user(
    user_id: str,
    current_user: dict = Depends(require_admin),
):
    """
    Delete a user.
    Requires admin role.
    """
    from bson import ObjectId

    db = get_db()

    # Validate ObjectId
    try:
        oid = ObjectId(user_id)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "success": False,
                "error": {
                    "message": "Invalid user ID",
                    "code": "INVALID_ID",
                },
            },
        ) from exc

    # Check if user exists
    existing = await db.users.find_one({"_id": oid})
    if not existing:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "success": False,
                "error": {
                    "message": "User not found",
                    "code": "NOT_FOUND",
                },
            },
        )

    # Prevent admin from deleting themselves
    if str(existing["_id"]) == str(current_user.get("_id")):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "success": False,
                "error": {
                    "message": "Cannot delete yourself",
                    "code": "SELF_DELETE_FORBIDDEN",
                },
            },
        )

    await db.users.delete_one({"_id": oid})

    logger.info(
        "User deleted: %s by %s",
        sanitize_for_logging(existing["username"]),
        current_user.get("username"),
    )


@user_management_router.post("/bulk", response_model=BulkActionResult)
async def bulk_user_action(
    request: BulkUserAction,
    current_user: dict = Depends(require_admin),
):
    """
    Perform bulk actions on users.
    Requires admin role.
    """
    from bson import ObjectId

    db = get_db()
    current_user_id = str(current_user.get("_id", ""))

    success_count = 0
    failed_ids: list[str] = []

    for user_id in request.user_ids:
        try:
            oid = ObjectId(user_id)

            # Skip self-modification
            if user_id == current_user_id:
                failed_ids.append(user_id)
                continue

            user = await db.users.find_one({"_id": oid})
            if not user:
                failed_ids.append(user_id)
                continue

            if request.action == "activate":
                await db.users.update_one(
                    {"_id": oid},
                    {"$set": {"is_active": True}},
                )
            elif request.action == "deactivate":
                await db.users.update_one(
                    {"_id": oid},
                    {"$set": {"is_active": False}},
                )
            elif request.action == "delete":
                await db.users.delete_one({"_id": oid})
            elif request.action == "change_role":
                if request.role:
                    await db.users.update_one(
                        {"_id": oid},
                        {"$set": {"role": request.role}},
                    )
                else:
                    failed_ids.append(user_id)
                    continue

            success_count += 1

        except Exception as e:
            logger.error(
                "Bulk action failed for user %s: %s",
                user_id,
                str(e),
            )
            failed_ids.append(user_id)

    action_msg = {
        "activate": "activated",
        "deactivate": "deactivated",
        "delete": "deleted",
        "change_role": f"role changed to {request.role}",
    }

    logger.info(
        "Bulk action '%s' completed: %s success, %s failed by %s",
        request.action,
        success_count,
        len(failed_ids),
        current_user.get("username"),
    )

    message = f"Successfully {action_msg.get(request.action, request.action)} {success_count} users"

    return BulkActionResult(
        success_count=success_count,
        failed_count=len(failed_ids),
        failed_ids=failed_ids,
        message=message,
    )


@user_management_router.get("/roles/available", response_model=dict)
async def get_available_roles(
    current_user: dict = Depends(get_current_user),
):
    """
    Get list of available roles and their permissions.
    Any authenticated user can view this.
    """
    return {
        "success": True,
        "data": {
            "roles": [
                {
                    "id": "staff",
                    "name": "Staff",
                    "description": ("Regular staff member with basic permissions"),
                    "permissions_count": len(ROLE_PERMISSIONS.get("staff", [])),
                },
                {
                    "id": "supervisor",
                    "name": "Supervisor",
                    "description": ("Supervisor with enhanced permissions for team management"),
                    "permissions_count": len(ROLE_PERMISSIONS.get("supervisor", [])),
                },
                {
                    "id": "admin",
                    "name": "Administrator",
                    "description": "Full system access with all permissions",
                    "permissions_count": len(ROLE_PERMISSIONS.get("admin", [])),
                },
            ]
        },
    }


@user_management_router.post("/{user_id}/reset-password")
async def reset_user_password(
    user_id: str,
    payload: Optional[ResetPasswordRequest] = None,
    new_password: Optional[str] = Query(None, min_length=6, max_length=128),
    current_user: dict = Depends(require_admin),
):
    """
    Reset a user's password.
    Requires admin role.
    """
    password_value = payload.new_password if payload else new_password
    if not password_value:
        raise HTTPException(status_code=422, detail="new_password is required")

    db = get_db()
    oid, user = await _resolve_user_or_raise(db, user_id)

    await db.users.update_one(
        {"_id": oid},
        {
            "$set": {
                "hashed_password": get_password_hash(password_value),
                "updated_at": datetime.now(timezone.utc).replace(tzinfo=None),
            }
        },
    )

    logger.info(
        "Password reset for user: %s by %s",
        sanitize_for_logging(user["username"]),
        current_user.get("username"),
    )

    return {"success": True, "message": "Password reset successfully"}


@user_management_router.post("/{user_id}/reset-pin")
async def reset_user_pin(
    user_id: str,
    payload: Optional[ResetPinRequest] = None,
    new_pin: Optional[str] = Query(None, pattern=r"^\d{4}$"),
    current_user: dict = Depends(require_admin),
):
    """
    Reset a user's PIN.
    Requires admin role.
    """
    pin_value = payload.new_pin if payload else new_pin
    if not pin_value:
        raise HTTPException(status_code=422, detail="new_pin is required")

    db = get_db()
    oid, user = await _resolve_user_or_raise(db, user_id)

    await db.users.update_one(
        {"_id": oid},
        {
            "$set": {
                "pin_hash": get_pin_hash(pin_value),
                "pin_lookup_hash": get_pin_lookup_hash(pin_value),
                "updated_at": datetime.now(timezone.utc).replace(tzinfo=None),
            }
        },
    )

    logger.info(
        "PIN reset for user: %s by %s",
        sanitize_for_logging(user["username"]),
        current_user.get("username"),
    )

    return {"success": True, "message": "PIN reset successfully"}
