__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  if (process.env.NODE_ENV === 'production') {
    module.exports = require(_dependencyMap[0], "./cjs/react.production.js");
  } else {
    module.exports = require(_dependencyMap[1], "./cjs/react.development.js");
  }
},11,[12,13],"node_modules/.pnpm/react@19.2.0/node_modules/react/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},12,[],"node_modules/.pnpm/metro-runtime@0.83.7/node_modules/metro-runtime/src/modules/empty-module.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * @license React
   * react.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */

  "use strict";

  "production" !== process.env.NODE_ENV && function () {
    function defineDeprecationWarning(methodName, info) {
      Object.defineProperty(Component.prototype, methodName, {
        get: function () {
          console.warn("%s(...) is deprecated in plain JavaScript React classes. %s", info[0], info[1]);
        }
      });
    }
    function getIteratorFn(maybeIterable) {
      if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
      maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
      return "function" === typeof maybeIterable ? maybeIterable : null;
    }
    function warnNoop(publicInstance, callerName) {
      publicInstance = (publicInstance = publicInstance.constructor) && (publicInstance.displayName || publicInstance.name) || "ReactClass";
      var warningKey = publicInstance + "." + callerName;
      didWarnStateUpdateForUnmountedComponent[warningKey] || (console.error("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", callerName, publicInstance), didWarnStateUpdateForUnmountedComponent[warningKey] = !0);
    }
    function Component(props, context, updater) {
      this.props = props;
      this.context = context;
      this.refs = emptyObject;
      this.updater = updater || ReactNoopUpdateQueue;
    }
    function ComponentDummy() {}
    function PureComponent(props, context, updater) {
      this.props = props;
      this.context = context;
      this.refs = emptyObject;
      this.updater = updater || ReactNoopUpdateQueue;
    }
    function noop() {}
    function testStringCoercion(value) {
      return "" + value;
    }
    function checkKeyStringCoercion(value) {
      try {
        testStringCoercion(value);
        var JSCompiler_inline_result = !1;
      } catch (e) {
        JSCompiler_inline_result = !0;
      }
      if (JSCompiler_inline_result) {
        JSCompiler_inline_result = console;
        var JSCompiler_temp_const = JSCompiler_inline_result.error;
        var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
        JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
        return testStringCoercion(value);
      }
    }
    function getComponentNameFromType(type) {
      if (null == type) return null;
      if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
      if ("string" === typeof type) return type;
      switch (type) {
        case REACT_FRAGMENT_TYPE:
          return "Fragment";
        case REACT_PROFILER_TYPE:
          return "Profiler";
        case REACT_STRICT_MODE_TYPE:
          return "StrictMode";
        case REACT_SUSPENSE_TYPE:
          return "Suspense";
        case REACT_SUSPENSE_LIST_TYPE:
          return "SuspenseList";
        case REACT_ACTIVITY_TYPE:
          return "Activity";
      }
      if ("object" === typeof type) switch ("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof) {
        case REACT_PORTAL_TYPE:
          return "Portal";
        case REACT_CONTEXT_TYPE:
          return type.displayName || "Context";
        case REACT_CONSUMER_TYPE:
          return (type._context.displayName || "Context") + ".Consumer";
        case REACT_FORWARD_REF_TYPE:
          var innerType = type.render;
          type = type.displayName;
          type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
          return type;
        case REACT_MEMO_TYPE:
          return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
        case REACT_LAZY_TYPE:
          innerType = type._payload;
          type = type._init;
          try {
            return getComponentNameFromType(type(innerType));
          } catch (x) {}
      }
      return null;
    }
    function getTaskName(type) {
      if (type === REACT_FRAGMENT_TYPE) return "<>";
      if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
      try {
        var name = getComponentNameFromType(type);
        return name ? "<" + name + ">" : "<...>";
      } catch (x) {
        return "<...>";
      }
    }
    function getOwner() {
      var dispatcher = ReactSharedInternals.A;
      return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
      return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
      if (hasOwnProperty.call(config, "key")) {
        var getter = Object.getOwnPropertyDescriptor(config, "key").get;
        if (getter && getter.isReactWarning) return !1;
      }
      return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
      function warnAboutAccessingKey() {
        specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
      }
      warnAboutAccessingKey.isReactWarning = !0;
      Object.defineProperty(props, "key", {
        get: warnAboutAccessingKey,
        configurable: !0
      });
    }
    function elementRefGetterWithDeprecationWarning() {
      var componentName = getComponentNameFromType(this.type);
      didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
      componentName = this.props.ref;
      return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
      var refProp = props.ref;
      type = {
        $$typeof: REACT_ELEMENT_TYPE,
        type: type,
        key: key,
        props: props,
        _owner: owner
      };
      null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
        enumerable: !1,
        get: elementRefGetterWithDeprecationWarning
      }) : Object.defineProperty(type, "ref", {
        enumerable: !1,
        value: null
      });
      type._store = {};
      Object.defineProperty(type._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: 0
      });
      Object.defineProperty(type, "_debugInfo", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: null
      });
      Object.defineProperty(type, "_debugStack", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: debugStack
      });
      Object.defineProperty(type, "_debugTask", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: debugTask
      });
      Object.freeze && (Object.freeze(type.props), Object.freeze(type));
      return type;
    }
    function cloneAndReplaceKey(oldElement, newKey) {
      newKey = ReactElement(oldElement.type, newKey, oldElement.props, oldElement._owner, oldElement._debugStack, oldElement._debugTask);
      oldElement._store && (newKey._store.validated = oldElement._store.validated);
      return newKey;
    }
    function validateChildKeys(node) {
      isValidElement(node) ? node._store && (node._store.validated = 1) : "object" === typeof node && null !== node && node.$$typeof === REACT_LAZY_TYPE && ("fulfilled" === node._payload.status ? isValidElement(node._payload.value) && node._payload.value._store && (node._payload.value._store.validated = 1) : node._store && (node._store.validated = 1));
    }
    function isValidElement(object) {
      return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    function escape(key) {
      var escaperLookup = {
        "=": "=0",
        ":": "=2"
      };
      return "$" + key.replace(/[=:]/g, function (match) {
        return escaperLookup[match];
      });
    }
    function getElementKey(element, index) {
      return "object" === typeof element && null !== element && null != element.key ? (checkKeyStringCoercion(element.key), escape("" + element.key)) : index.toString(36);
    }
    function resolveThenable(thenable) {
      switch (thenable.status) {
        case "fulfilled":
          return thenable.value;
        case "rejected":
          throw thenable.reason;
        default:
          switch ("string" === typeof thenable.status ? thenable.then(noop, noop) : (thenable.status = "pending", thenable.then(function (fulfilledValue) {
            "pending" === thenable.status && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
          }, function (error) {
            "pending" === thenable.status && (thenable.status = "rejected", thenable.reason = error);
          })), thenable.status) {
            case "fulfilled":
              return thenable.value;
            case "rejected":
              throw thenable.reason;
          }
      }
      throw thenable;
    }
    function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
      var type = typeof children;
      if ("undefined" === type || "boolean" === type) children = null;
      var invokeCallback = !1;
      if (null === children) invokeCallback = !0;else switch (type) {
        case "bigint":
        case "string":
        case "number":
          invokeCallback = !0;
          break;
        case "object":
          switch (children.$$typeof) {
            case REACT_ELEMENT_TYPE:
            case REACT_PORTAL_TYPE:
              invokeCallback = !0;
              break;
            case REACT_LAZY_TYPE:
              return invokeCallback = children._init, mapIntoArray(invokeCallback(children._payload), array, escapedPrefix, nameSoFar, callback);
          }
      }
      if (invokeCallback) {
        invokeCallback = children;
        callback = callback(invokeCallback);
        var childKey = "" === nameSoFar ? "." + getElementKey(invokeCallback, 0) : nameSoFar;
        isArrayImpl(callback) ? (escapedPrefix = "", null != childKey && (escapedPrefix = childKey.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function (c) {
          return c;
        })) : null != callback && (isValidElement(callback) && (null != callback.key && (invokeCallback && invokeCallback.key === callback.key || checkKeyStringCoercion(callback.key)), escapedPrefix = cloneAndReplaceKey(callback, escapedPrefix + (null == callback.key || invokeCallback && invokeCallback.key === callback.key ? "" : ("" + callback.key).replace(userProvidedKeyEscapeRegex, "$&/") + "/") + childKey), "" !== nameSoFar && null != invokeCallback && isValidElement(invokeCallback) && null == invokeCallback.key && invokeCallback._store && !invokeCallback._store.validated && (escapedPrefix._store.validated = 2), callback = escapedPrefix), array.push(callback));
        return 1;
      }
      invokeCallback = 0;
      childKey = "" === nameSoFar ? "." : nameSoFar + ":";
      if (isArrayImpl(children)) for (var i = 0; i < children.length; i++) nameSoFar = children[i], type = childKey + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);else if (i = getIteratorFn(children), "function" === typeof i) for (i === children.entries && (didWarnAboutMaps || console.warn("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), didWarnAboutMaps = !0), children = i.call(children), i = 0; !(nameSoFar = children.next()).done;) nameSoFar = nameSoFar.value, type = childKey + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);else if ("object" === type) {
        if ("function" === typeof children.then) return mapIntoArray(resolveThenable(children), array, escapedPrefix, nameSoFar, callback);
        array = String(children);
        throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === array ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead.");
      }
      return invokeCallback;
    }
    function mapChildren(children, func, context) {
      if (null == children) return children;
      var result = [],
        count = 0;
      mapIntoArray(children, result, "", "", function (child) {
        return func.call(context, child, count++);
      });
      return result;
    }
    function lazyInitializer(payload) {
      if (-1 === payload._status) {
        var ioInfo = payload._ioInfo;
        null != ioInfo && (ioInfo.start = ioInfo.end = performance.now());
        ioInfo = payload._result;
        var thenable = ioInfo();
        thenable.then(function (moduleObject) {
          if (0 === payload._status || -1 === payload._status) {
            payload._status = 1;
            payload._result = moduleObject;
            var _ioInfo = payload._ioInfo;
            null != _ioInfo && (_ioInfo.end = performance.now());
            void 0 === thenable.status && (thenable.status = "fulfilled", thenable.value = moduleObject);
          }
        }, function (error) {
          if (0 === payload._status || -1 === payload._status) {
            payload._status = 2;
            payload._result = error;
            var _ioInfo2 = payload._ioInfo;
            null != _ioInfo2 && (_ioInfo2.end = performance.now());
            void 0 === thenable.status && (thenable.status = "rejected", thenable.reason = error);
          }
        });
        ioInfo = payload._ioInfo;
        if (null != ioInfo) {
          ioInfo.value = thenable;
          var displayName = thenable.displayName;
          "string" === typeof displayName && (ioInfo.name = displayName);
        }
        -1 === payload._status && (payload._status = 0, payload._result = thenable);
      }
      if (1 === payload._status) return ioInfo = payload._result, void 0 === ioInfo && console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))\n\nDid you accidentally put curly braces around the import?", ioInfo), "default" in ioInfo || console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))", ioInfo), ioInfo.default;
      throw payload._result;
    }
    function resolveDispatcher() {
      var dispatcher = ReactSharedInternals.H;
      null === dispatcher && console.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.");
      return dispatcher;
    }
    function releaseAsyncTransition() {
      ReactSharedInternals.asyncTransitions--;
    }
    function enqueueTask(task) {
      if (null === enqueueTaskImpl) try {
        var requireString = ("require" + Math.random()).slice(0, 7);
        enqueueTaskImpl = (module && module[requireString]).call(module, "timers").setImmediate;
      } catch (_err) {
        enqueueTaskImpl = function (callback) {
          !1 === didWarnAboutMessageChannel && (didWarnAboutMessageChannel = !0, "undefined" === typeof MessageChannel && console.error("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));
          var channel = new MessageChannel();
          channel.port1.onmessage = callback;
          channel.port2.postMessage(void 0);
        };
      }
      return enqueueTaskImpl(task);
    }
    function aggregateErrors(errors) {
      return 1 < errors.length && "function" === typeof AggregateError ? new AggregateError(errors) : errors[0];
    }
    function popActScope(prevActQueue, prevActScopeDepth) {
      prevActScopeDepth !== actScopeDepth - 1 && console.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
      actScopeDepth = prevActScopeDepth;
    }
    function recursivelyFlushAsyncActWork(returnValue, resolve, reject) {
      var queue = ReactSharedInternals.actQueue;
      if (null !== queue) if (0 !== queue.length) try {
        flushActQueue(queue);
        enqueueTask(function () {
          return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
        });
        return;
      } catch (error) {
        ReactSharedInternals.thrownErrors.push(error);
      } else ReactSharedInternals.actQueue = null;
      0 < ReactSharedInternals.thrownErrors.length ? (queue = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(queue)) : resolve(returnValue);
    }
    function flushActQueue(queue) {
      if (!isFlushing) {
        isFlushing = !0;
        var i = 0;
        try {
          for (; i < queue.length; i++) {
            var callback = queue[i];
            do {
              ReactSharedInternals.didUsePromise = !1;
              var continuation = callback(!1);
              if (null !== continuation) {
                if (ReactSharedInternals.didUsePromise) {
                  queue[i] = callback;
                  queue.splice(0, i);
                  return;
                }
                callback = continuation;
              } else break;
            } while (1);
          }
          queue.length = 0;
        } catch (error) {
          queue.splice(0, i + 1), ReactSharedInternals.thrownErrors.push(error);
        } finally {
          isFlushing = !1;
        }
      }
    }
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
    var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"),
      REACT_PORTAL_TYPE = Symbol.for("react.portal"),
      REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"),
      REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"),
      REACT_PROFILER_TYPE = Symbol.for("react.profiler"),
      REACT_CONSUMER_TYPE = Symbol.for("react.consumer"),
      REACT_CONTEXT_TYPE = Symbol.for("react.context"),
      REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"),
      REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"),
      REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"),
      REACT_MEMO_TYPE = Symbol.for("react.memo"),
      REACT_LAZY_TYPE = Symbol.for("react.lazy"),
      REACT_ACTIVITY_TYPE = Symbol.for("react.activity"),
      MAYBE_ITERATOR_SYMBOL = Symbol.iterator,
      didWarnStateUpdateForUnmountedComponent = {},
      ReactNoopUpdateQueue = {
        isMounted: function () {
          return !1;
        },
        enqueueForceUpdate: function (publicInstance) {
          warnNoop(publicInstance, "forceUpdate");
        },
        enqueueReplaceState: function (publicInstance) {
          warnNoop(publicInstance, "replaceState");
        },
        enqueueSetState: function (publicInstance) {
          warnNoop(publicInstance, "setState");
        }
      },
      assign = Object.assign,
      emptyObject = {};
    Object.freeze(emptyObject);
    Component.prototype.isReactComponent = {};
    Component.prototype.setState = function (partialState, callback) {
      if ("object" !== typeof partialState && "function" !== typeof partialState && null != partialState) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, partialState, callback, "setState");
    };
    Component.prototype.forceUpdate = function (callback) {
      this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
    };
    var deprecatedAPIs = {
      isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
      replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
    };
    for (fnName in deprecatedAPIs) deprecatedAPIs.hasOwnProperty(fnName) && defineDeprecationWarning(fnName, deprecatedAPIs[fnName]);
    ComponentDummy.prototype = Component.prototype;
    deprecatedAPIs = PureComponent.prototype = new ComponentDummy();
    deprecatedAPIs.constructor = PureComponent;
    assign(deprecatedAPIs, Component.prototype);
    deprecatedAPIs.isPureReactComponent = !0;
    var isArrayImpl = Array.isArray,
      REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"),
      ReactSharedInternals = {
        H: null,
        A: null,
        T: null,
        S: null,
        actQueue: null,
        asyncTransitions: 0,
        isBatchingLegacy: !1,
        didScheduleLegacyUpdate: !1,
        didUsePromise: !1,
        thrownErrors: [],
        getCurrentStack: null,
        recentlyCreatedOwnerStacks: 0
      },
      hasOwnProperty = Object.prototype.hasOwnProperty,
      createTask = console.createTask ? console.createTask : function () {
        return null;
      };
    deprecatedAPIs = {
      react_stack_bottom_frame: function (callStackForError) {
        return callStackForError();
      }
    };
    var specialPropKeyWarningShown, didWarnAboutOldJSXRuntime;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = deprecatedAPIs.react_stack_bottom_frame.bind(deprecatedAPIs, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutMaps = !1,
      userProvidedKeyEscapeRegex = /\/+/g,
      reportGlobalError = "function" === typeof reportError ? reportError : function (error) {
        if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
          var event = new window.ErrorEvent("error", {
            bubbles: !0,
            cancelable: !0,
            message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
            error: error
          });
          if (!window.dispatchEvent(event)) return;
        } else if ("object" === typeof process && "function" === typeof process.emit) {
          process.emit("uncaughtException", error);
          return;
        }
        console.error(error);
      },
      didWarnAboutMessageChannel = !1,
      enqueueTaskImpl = null,
      actScopeDepth = 0,
      didWarnNoAwaitAct = !1,
      isFlushing = !1,
      queueSeveralMicrotasks = "function" === typeof queueMicrotask ? function (callback) {
        queueMicrotask(function () {
          return queueMicrotask(callback);
        });
      } : enqueueTask;
    deprecatedAPIs = Object.freeze({
      __proto__: null,
      c: function (size) {
        return resolveDispatcher().useMemoCache(size);
      }
    });
    var fnName = {
      map: mapChildren,
      forEach: function (children, forEachFunc, forEachContext) {
        mapChildren(children, function () {
          forEachFunc.apply(this, arguments);
        }, forEachContext);
      },
      count: function (children) {
        var n = 0;
        mapChildren(children, function () {
          n++;
        });
        return n;
      },
      toArray: function (children) {
        return mapChildren(children, function (child) {
          return child;
        }) || [];
      },
      only: function (children) {
        if (!isValidElement(children)) throw Error("React.Children.only expected to receive a single React element child.");
        return children;
      }
    };
    exports.Activity = REACT_ACTIVITY_TYPE;
    exports.Children = fnName;
    exports.Component = Component;
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.Profiler = REACT_PROFILER_TYPE;
    exports.PureComponent = PureComponent;
    exports.StrictMode = REACT_STRICT_MODE_TYPE;
    exports.Suspense = REACT_SUSPENSE_TYPE;
    exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
    exports.__COMPILER_RUNTIME = deprecatedAPIs;
    exports.act = function (callback) {
      var prevActQueue = ReactSharedInternals.actQueue,
        prevActScopeDepth = actScopeDepth;
      actScopeDepth++;
      var queue = ReactSharedInternals.actQueue = null !== prevActQueue ? prevActQueue : [],
        didAwaitActCall = !1;
      try {
        var result = callback();
      } catch (error) {
        ReactSharedInternals.thrownErrors.push(error);
      }
      if (0 < ReactSharedInternals.thrownErrors.length) throw popActScope(prevActQueue, prevActScopeDepth), callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
      if (null !== result && "object" === typeof result && "function" === typeof result.then) {
        var thenable = result;
        queueSeveralMicrotasks(function () {
          didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"));
        });
        return {
          then: function (resolve, reject) {
            didAwaitActCall = !0;
            thenable.then(function (returnValue) {
              popActScope(prevActQueue, prevActScopeDepth);
              if (0 === prevActScopeDepth) {
                try {
                  flushActQueue(queue), enqueueTask(function () {
                    return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
                  });
                } catch (error$0) {
                  ReactSharedInternals.thrownErrors.push(error$0);
                }
                if (0 < ReactSharedInternals.thrownErrors.length) {
                  var _thrownError = aggregateErrors(ReactSharedInternals.thrownErrors);
                  ReactSharedInternals.thrownErrors.length = 0;
                  reject(_thrownError);
                }
              } else resolve(returnValue);
            }, function (error) {
              popActScope(prevActQueue, prevActScopeDepth);
              0 < ReactSharedInternals.thrownErrors.length ? (error = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(error)) : reject(error);
            });
          }
        };
      }
      var returnValue$jscomp$0 = result;
      popActScope(prevActQueue, prevActScopeDepth);
      0 === prevActScopeDepth && (flushActQueue(queue), 0 !== queue.length && queueSeveralMicrotasks(function () {
        didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"));
      }), ReactSharedInternals.actQueue = null);
      if (0 < ReactSharedInternals.thrownErrors.length) throw callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
      return {
        then: function (resolve, reject) {
          didAwaitActCall = !0;
          0 === prevActScopeDepth ? (ReactSharedInternals.actQueue = queue, enqueueTask(function () {
            return recursivelyFlushAsyncActWork(returnValue$jscomp$0, resolve, reject);
          })) : resolve(returnValue$jscomp$0);
        }
      };
    };
    exports.cache = function (fn) {
      return function () {
        return fn.apply(null, arguments);
      };
    };
    exports.cacheSignal = function () {
      return null;
    };
    exports.captureOwnerStack = function () {
      var getCurrentStack = ReactSharedInternals.getCurrentStack;
      return null === getCurrentStack ? null : getCurrentStack();
    };
    exports.cloneElement = function (element, config, children) {
      if (null === element || void 0 === element) throw Error("The argument must be a React element, but you passed " + element + ".");
      var props = assign({}, element.props),
        key = element.key,
        owner = element._owner;
      if (null != config) {
        var JSCompiler_inline_result;
        a: {
          if (hasOwnProperty.call(config, "ref") && (JSCompiler_inline_result = Object.getOwnPropertyDescriptor(config, "ref").get) && JSCompiler_inline_result.isReactWarning) {
            JSCompiler_inline_result = !1;
            break a;
          }
          JSCompiler_inline_result = void 0 !== config.ref;
        }
        JSCompiler_inline_result && (owner = getOwner());
        hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key);
        for (propName in config) !hasOwnProperty.call(config, propName) || "key" === propName || "__self" === propName || "__source" === propName || "ref" === propName && void 0 === config.ref || (props[propName] = config[propName]);
      }
      var propName = arguments.length - 2;
      if (1 === propName) props.children = children;else if (1 < propName) {
        JSCompiler_inline_result = Array(propName);
        for (var i = 0; i < propName; i++) JSCompiler_inline_result[i] = arguments[i + 2];
        props.children = JSCompiler_inline_result;
      }
      props = ReactElement(element.type, key, props, owner, element._debugStack, element._debugTask);
      for (key = 2; key < arguments.length; key++) validateChildKeys(arguments[key]);
      return props;
    };
    exports.createContext = function (defaultValue) {
      defaultValue = {
        $$typeof: REACT_CONTEXT_TYPE,
        _currentValue: defaultValue,
        _currentValue2: defaultValue,
        _threadCount: 0,
        Provider: null,
        Consumer: null
      };
      defaultValue.Provider = defaultValue;
      defaultValue.Consumer = {
        $$typeof: REACT_CONSUMER_TYPE,
        _context: defaultValue
      };
      defaultValue._currentRenderer = null;
      defaultValue._currentRenderer2 = null;
      return defaultValue;
    };
    exports.createElement = function (type, config, children) {
      for (var i = 2; i < arguments.length; i++) validateChildKeys(arguments[i]);
      i = {};
      var key = null;
      if (null != config) for (propName in didWarnAboutOldJSXRuntime || !("__self" in config) || "key" in config || (didWarnAboutOldJSXRuntime = !0, console.warn("Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform")), hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key), config) hasOwnProperty.call(config, propName) && "key" !== propName && "__self" !== propName && "__source" !== propName && (i[propName] = config[propName]);
      var childrenLength = arguments.length - 2;
      if (1 === childrenLength) i.children = children;else if (1 < childrenLength) {
        for (var childArray = Array(childrenLength), _i = 0; _i < childrenLength; _i++) childArray[_i] = arguments[_i + 2];
        Object.freeze && Object.freeze(childArray);
        i.children = childArray;
      }
      if (type && type.defaultProps) for (propName in childrenLength = type.defaultProps, childrenLength) void 0 === i[propName] && (i[propName] = childrenLength[propName]);
      key && defineKeyPropWarningGetter(i, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
      var propName = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
      return ReactElement(type, key, i, getOwner(), propName ? Error("react-stack-top-frame") : unknownOwnerDebugStack, propName ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
    exports.createRef = function () {
      var refObject = {
        current: null
      };
      Object.seal(refObject);
      return refObject;
    };
    exports.forwardRef = function (render) {
      null != render && render.$$typeof === REACT_MEMO_TYPE ? console.error("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).") : "function" !== typeof render ? console.error("forwardRef requires a render function but was given %s.", null === render ? "null" : typeof render) : 0 !== render.length && 2 !== render.length && console.error("forwardRef render functions accept exactly two parameters: props and ref. %s", 1 === render.length ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined.");
      null != render && null != render.defaultProps && console.error("forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?");
      var elementType = {
          $$typeof: REACT_FORWARD_REF_TYPE,
          render: render
        },
        ownName;
      Object.defineProperty(elementType, "displayName", {
        enumerable: !1,
        configurable: !0,
        get: function () {
          return ownName;
        },
        set: function (name) {
          ownName = name;
          render.name || render.displayName || (Object.defineProperty(render, "name", {
            value: name
          }), render.displayName = name);
        }
      });
      return elementType;
    };
    exports.isValidElement = isValidElement;
    exports.lazy = function (ctor) {
      ctor = {
        _status: -1,
        _result: ctor
      };
      var lazyType = {
          $$typeof: REACT_LAZY_TYPE,
          _payload: ctor,
          _init: lazyInitializer
        },
        ioInfo = {
          name: "lazy",
          start: -1,
          end: -1,
          value: null,
          owner: null,
          debugStack: Error("react-stack-top-frame"),
          debugTask: console.createTask ? console.createTask("lazy()") : null
        };
      ctor._ioInfo = ioInfo;
      lazyType._debugInfo = [{
        awaited: ioInfo
      }];
      return lazyType;
    };
    exports.memo = function (type, compare) {
      null == type && console.error("memo: The first argument must be a component. Instead received: %s", null === type ? "null" : typeof type);
      compare = {
        $$typeof: REACT_MEMO_TYPE,
        type: type,
        compare: void 0 === compare ? null : compare
      };
      var ownName;
      Object.defineProperty(compare, "displayName", {
        enumerable: !1,
        configurable: !0,
        get: function () {
          return ownName;
        },
        set: function (name) {
          ownName = name;
          type.name || type.displayName || (Object.defineProperty(type, "name", {
            value: name
          }), type.displayName = name);
        }
      });
      return compare;
    };
    exports.startTransition = function (scope) {
      var prevTransition = ReactSharedInternals.T,
        currentTransition = {};
      currentTransition._updatedFibers = new Set();
      ReactSharedInternals.T = currentTransition;
      try {
        var returnValue = scope(),
          onStartTransitionFinish = ReactSharedInternals.S;
        null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
        "object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && (ReactSharedInternals.asyncTransitions++, returnValue.then(releaseAsyncTransition, releaseAsyncTransition), returnValue.then(noop, reportGlobalError));
      } catch (error) {
        reportGlobalError(error);
      } finally {
        null === prevTransition && currentTransition._updatedFibers && (scope = currentTransition._updatedFibers.size, currentTransition._updatedFibers.clear(), 10 < scope && console.warn("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.")), null !== prevTransition && null !== currentTransition.types && (null !== prevTransition.types && prevTransition.types !== currentTransition.types && console.error("We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React."), prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
      }
    };
    exports.unstable_useCacheRefresh = function () {
      return resolveDispatcher().useCacheRefresh();
    };
    exports.use = function (usable) {
      return resolveDispatcher().use(usable);
    };
    exports.useActionState = function (action, initialState, permalink) {
      return resolveDispatcher().useActionState(action, initialState, permalink);
    };
    exports.useCallback = function (callback, deps) {
      return resolveDispatcher().useCallback(callback, deps);
    };
    exports.useContext = function (Context) {
      var dispatcher = resolveDispatcher();
      Context.$$typeof === REACT_CONSUMER_TYPE && console.error("Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?");
      return dispatcher.useContext(Context);
    };
    exports.useDebugValue = function (value, formatterFn) {
      return resolveDispatcher().useDebugValue(value, formatterFn);
    };
    exports.useDeferredValue = function (value, initialValue) {
      return resolveDispatcher().useDeferredValue(value, initialValue);
    };
    exports.useEffect = function (create, deps) {
      null == create && console.warn("React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      return resolveDispatcher().useEffect(create, deps);
    };
    exports.useEffectEvent = function (callback) {
      return resolveDispatcher().useEffectEvent(callback);
    };
    exports.useId = function () {
      return resolveDispatcher().useId();
    };
    exports.useImperativeHandle = function (ref, create, deps) {
      return resolveDispatcher().useImperativeHandle(ref, create, deps);
    };
    exports.useInsertionEffect = function (create, deps) {
      null == create && console.warn("React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      return resolveDispatcher().useInsertionEffect(create, deps);
    };
    exports.useLayoutEffect = function (create, deps) {
      null == create && console.warn("React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      return resolveDispatcher().useLayoutEffect(create, deps);
    };
    exports.useMemo = function (create, deps) {
      return resolveDispatcher().useMemo(create, deps);
    };
    exports.useOptimistic = function (passthrough, reducer) {
      return resolveDispatcher().useOptimistic(passthrough, reducer);
    };
    exports.useReducer = function (reducer, initialArg, init) {
      return resolveDispatcher().useReducer(reducer, initialArg, init);
    };
    exports.useRef = function (initialValue) {
      return resolveDispatcher().useRef(initialValue);
    };
    exports.useState = function (initialState) {
      return resolveDispatcher().useState(initialState);
    };
    exports.useSyncExternalStore = function (subscribe, getSnapshot, getServerSnapshot) {
      return resolveDispatcher().useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
    };
    exports.useTransition = function () {
      return resolveDispatcher().useTransition();
    };
    exports.version = "19.2.0";
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
  }();
},13,[],"node_modules/.pnpm/react@19.2.0/node_modules/react/cjs/react.development.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  if (process.env.NODE_ENV === 'production') {
    module.exports = require(_dependencyMap[0], "./cjs/react-jsx-runtime.production.js");
  } else {
    module.exports = require(_dependencyMap[1], "./cjs/react-jsx-runtime.development.js");
  }
},202,[12,203],"node_modules/.pnpm/react@19.2.0/node_modules/react/jsx-runtime.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * @license React
   * react-jsx-runtime.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */

  "use strict";

  "production" !== process.env.NODE_ENV && function () {
    function getComponentNameFromType(type) {
      if (null == type) return null;
      if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
      if ("string" === typeof type) return type;
      switch (type) {
        case REACT_FRAGMENT_TYPE:
          return "Fragment";
        case REACT_PROFILER_TYPE:
          return "Profiler";
        case REACT_STRICT_MODE_TYPE:
          return "StrictMode";
        case REACT_SUSPENSE_TYPE:
          return "Suspense";
        case REACT_SUSPENSE_LIST_TYPE:
          return "SuspenseList";
        case REACT_ACTIVITY_TYPE:
          return "Activity";
      }
      if ("object" === typeof type) switch ("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof) {
        case REACT_PORTAL_TYPE:
          return "Portal";
        case REACT_CONTEXT_TYPE:
          return type.displayName || "Context";
        case REACT_CONSUMER_TYPE:
          return (type._context.displayName || "Context") + ".Consumer";
        case REACT_FORWARD_REF_TYPE:
          var innerType = type.render;
          type = type.displayName;
          type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
          return type;
        case REACT_MEMO_TYPE:
          return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
        case REACT_LAZY_TYPE:
          innerType = type._payload;
          type = type._init;
          try {
            return getComponentNameFromType(type(innerType));
          } catch (x) {}
      }
      return null;
    }
    function testStringCoercion(value) {
      return "" + value;
    }
    function checkKeyStringCoercion(value) {
      try {
        testStringCoercion(value);
        var JSCompiler_inline_result = !1;
      } catch (e) {
        JSCompiler_inline_result = !0;
      }
      if (JSCompiler_inline_result) {
        JSCompiler_inline_result = console;
        var JSCompiler_temp_const = JSCompiler_inline_result.error;
        var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
        JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
        return testStringCoercion(value);
      }
    }
    function getTaskName(type) {
      if (type === REACT_FRAGMENT_TYPE) return "<>";
      if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
      try {
        var name = getComponentNameFromType(type);
        return name ? "<" + name + ">" : "<...>";
      } catch (x) {
        return "<...>";
      }
    }
    function getOwner() {
      var dispatcher = ReactSharedInternals.A;
      return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
      return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
      if (hasOwnProperty.call(config, "key")) {
        var getter = Object.getOwnPropertyDescriptor(config, "key").get;
        if (getter && getter.isReactWarning) return !1;
      }
      return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
      function warnAboutAccessingKey() {
        specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
      }
      warnAboutAccessingKey.isReactWarning = !0;
      Object.defineProperty(props, "key", {
        get: warnAboutAccessingKey,
        configurable: !0
      });
    }
    function elementRefGetterWithDeprecationWarning() {
      var componentName = getComponentNameFromType(this.type);
      didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
      componentName = this.props.ref;
      return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
      var refProp = props.ref;
      type = {
        $$typeof: REACT_ELEMENT_TYPE,
        type: type,
        key: key,
        props: props,
        _owner: owner
      };
      null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
        enumerable: !1,
        get: elementRefGetterWithDeprecationWarning
      }) : Object.defineProperty(type, "ref", {
        enumerable: !1,
        value: null
      });
      type._store = {};
      Object.defineProperty(type._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: 0
      });
      Object.defineProperty(type, "_debugInfo", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: null
      });
      Object.defineProperty(type, "_debugStack", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: debugStack
      });
      Object.defineProperty(type, "_debugTask", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: debugTask
      });
      Object.freeze && (Object.freeze(type.props), Object.freeze(type));
      return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, debugStack, debugTask) {
      var children = config.children;
      if (void 0 !== children) if (isStaticChildren) {
        if (isArrayImpl(children)) {
          for (isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++) validateChildKeys(children[isStaticChildren]);
          Object.freeze && Object.freeze(children);
        } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
      } else validateChildKeys(children);
      if (hasOwnProperty.call(config, "key")) {
        children = getComponentNameFromType(type);
        var keys = Object.keys(config).filter(function (k) {
          return "key" !== k;
        });
        isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
        didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
      }
      children = null;
      void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
      hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
      if ("key" in config) {
        maybeKey = {};
        for (var propName in config) "key" !== propName && (maybeKey[propName] = config[propName]);
      } else maybeKey = config;
      children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
      return ReactElement(type, children, maybeKey, getOwner(), debugStack, debugTask);
    }
    function validateChildKeys(node) {
      isValidElement(node) ? node._store && (node._store.validated = 1) : "object" === typeof node && null !== node && node.$$typeof === REACT_LAZY_TYPE && ("fulfilled" === node._payload.status ? isValidElement(node._payload.value) && node._payload.value._store && (node._payload.value._store.validated = 1) : node._store && (node._store.validated = 1));
    }
    function isValidElement(object) {
      return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    var React = require(_dependencyMap[0], "react"),
      REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"),
      REACT_PORTAL_TYPE = Symbol.for("react.portal"),
      REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"),
      REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"),
      REACT_PROFILER_TYPE = Symbol.for("react.profiler"),
      REACT_CONSUMER_TYPE = Symbol.for("react.consumer"),
      REACT_CONTEXT_TYPE = Symbol.for("react.context"),
      REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"),
      REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"),
      REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"),
      REACT_MEMO_TYPE = Symbol.for("react.memo"),
      REACT_LAZY_TYPE = Symbol.for("react.lazy"),
      REACT_ACTIVITY_TYPE = Symbol.for("react.activity"),
      REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"),
      ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
      hasOwnProperty = Object.prototype.hasOwnProperty,
      isArrayImpl = Array.isArray,
      createTask = console.createTask ? console.createTask : function () {
        return null;
      };
    React = {
      react_stack_bottom_frame: function (callStackForError) {
        return callStackForError();
      }
    };
    var specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = React.react_stack_bottom_frame.bind(React, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutKeySpread = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsx = function (type, config, maybeKey) {
      var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
      return jsxDEVImpl(type, config, maybeKey, !1, trackActualOwner ? Error("react-stack-top-frame") : unknownOwnerDebugStack, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
    exports.jsxs = function (type, config, maybeKey) {
      var trackActualOwner = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
      return jsxDEVImpl(type, config, maybeKey, !0, trackActualOwner ? Error("react-stack-top-frame") : unknownOwnerDebugStack, trackActualOwner ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
  }();
},203,[11],"node_modules/.pnpm/react@19.2.0/node_modules/react/cjs/react-jsx-runtime.development.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "HydrationBoundary", {
    enumerable: true,
    get: function () {
      return _HydrationBoundaryJs.HydrationBoundary;
    }
  });
  Object.defineProperty(exports, "IsRestoringProvider", {
    enumerable: true,
    get: function () {
      return _IsRestoringProviderJs.IsRestoringProvider;
    }
  });
  Object.defineProperty(exports, "QueryClientContext", {
    enumerable: true,
    get: function () {
      return _QueryClientProviderJs.QueryClientContext;
    }
  });
  Object.defineProperty(exports, "QueryClientProvider", {
    enumerable: true,
    get: function () {
      return _QueryClientProviderJs.QueryClientProvider;
    }
  });
  Object.defineProperty(exports, "QueryErrorResetBoundary", {
    enumerable: true,
    get: function () {
      return _QueryErrorResetBoundaryJs.QueryErrorResetBoundary;
    }
  });
  Object.defineProperty(exports, "infiniteQueryOptions", {
    enumerable: true,
    get: function () {
      return _infiniteQueryOptionsJs.infiniteQueryOptions;
    }
  });
  Object.defineProperty(exports, "mutationOptions", {
    enumerable: true,
    get: function () {
      return _mutationOptionsJs.mutationOptions;
    }
  });
  Object.defineProperty(exports, "queryOptions", {
    enumerable: true,
    get: function () {
      return _queryOptionsJs.queryOptions;
    }
  });
  Object.defineProperty(exports, "useInfiniteQuery", {
    enumerable: true,
    get: function () {
      return _useInfiniteQueryJs.useInfiniteQuery;
    }
  });
  Object.defineProperty(exports, "useIsFetching", {
    enumerable: true,
    get: function () {
      return _useIsFetchingJs.useIsFetching;
    }
  });
  Object.defineProperty(exports, "useIsMutating", {
    enumerable: true,
    get: function () {
      return _useMutationStateJs.useIsMutating;
    }
  });
  Object.defineProperty(exports, "useIsRestoring", {
    enumerable: true,
    get: function () {
      return _IsRestoringProviderJs.useIsRestoring;
    }
  });
  Object.defineProperty(exports, "useMutation", {
    enumerable: true,
    get: function () {
      return _useMutationJs.useMutation;
    }
  });
  Object.defineProperty(exports, "useMutationState", {
    enumerable: true,
    get: function () {
      return _useMutationStateJs.useMutationState;
    }
  });
  Object.defineProperty(exports, "usePrefetchInfiniteQuery", {
    enumerable: true,
    get: function () {
      return _usePrefetchInfiniteQueryJs.usePrefetchInfiniteQuery;
    }
  });
  Object.defineProperty(exports, "usePrefetchQuery", {
    enumerable: true,
    get: function () {
      return _usePrefetchQueryJs.usePrefetchQuery;
    }
  });
  Object.defineProperty(exports, "useQueries", {
    enumerable: true,
    get: function () {
      return _useQueriesJs.useQueries;
    }
  });
  Object.defineProperty(exports, "useQuery", {
    enumerable: true,
    get: function () {
      return _useQueryJs.useQuery;
    }
  });
  Object.defineProperty(exports, "useQueryClient", {
    enumerable: true,
    get: function () {
      return _QueryClientProviderJs.useQueryClient;
    }
  });
  Object.defineProperty(exports, "useQueryErrorResetBoundary", {
    enumerable: true,
    get: function () {
      return _QueryErrorResetBoundaryJs.useQueryErrorResetBoundary;
    }
  });
  Object.defineProperty(exports, "useSuspenseInfiniteQuery", {
    enumerable: true,
    get: function () {
      return _useSuspenseInfiniteQueryJs.useSuspenseInfiniteQuery;
    }
  });
  Object.defineProperty(exports, "useSuspenseQueries", {
    enumerable: true,
    get: function () {
      return _useSuspenseQueriesJs.useSuspenseQueries;
    }
  });
  Object.defineProperty(exports, "useSuspenseQuery", {
    enumerable: true,
    get: function () {
      return _useSuspenseQueryJs.useSuspenseQuery;
    }
  });
  var _tanstackQueryCore = require(_dependencyMap[0], "@tanstack/query-core");
  Object.keys(_tanstackQueryCore).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _tanstackQueryCore[k];
        }
      });
    }
  });
  var _typesJs = require(_dependencyMap[1], "./types.js");
  Object.keys(_typesJs).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _typesJs[k];
        }
      });
    }
  });
  var _useQueriesJs = require(_dependencyMap[2], "./useQueries.js");
  var _useQueryJs = require(_dependencyMap[3], "./useQuery.js");
  var _useSuspenseQueryJs = require(_dependencyMap[4], "./useSuspenseQuery.js");
  var _useSuspenseInfiniteQueryJs = require(_dependencyMap[5], "./useSuspenseInfiniteQuery.js");
  var _useSuspenseQueriesJs = require(_dependencyMap[6], "./useSuspenseQueries.js");
  var _usePrefetchQueryJs = require(_dependencyMap[7], "./usePrefetchQuery.js");
  var _usePrefetchInfiniteQueryJs = require(_dependencyMap[8], "./usePrefetchInfiniteQuery.js");
  var _queryOptionsJs = require(_dependencyMap[9], "./queryOptions.js");
  var _infiniteQueryOptionsJs = require(_dependencyMap[10], "./infiniteQueryOptions.js");
  var _QueryClientProviderJs = require(_dependencyMap[11], "./QueryClientProvider.js");
  var _HydrationBoundaryJs = require(_dependencyMap[12], "./HydrationBoundary.js");
  var _QueryErrorResetBoundaryJs = require(_dependencyMap[13], "./QueryErrorResetBoundary.js");
  var _useIsFetchingJs = require(_dependencyMap[14], "./useIsFetching.js");
  var _useMutationStateJs = require(_dependencyMap[15], "./useMutationState.js");
  var _useMutationJs = require(_dependencyMap[16], "./useMutation.js");
  var _mutationOptionsJs = require(_dependencyMap[17], "./mutationOptions.js");
  var _useInfiniteQueryJs = require(_dependencyMap[18], "./useInfiniteQuery.js");
  var _IsRestoringProviderJs = require(_dependencyMap[19], "./IsRestoringProvider.js");
},1285,[1286,1312,1313,1319,1321,1322,1323,1324,1325,1326,1327,1314,1328,1316,1329,1330,1331,1332,1333,1315],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "CancelledError", {
    enumerable: true,
    get: function () {
      return _retryerJs.CancelledError;
    }
  });
  Object.defineProperty(exports, "InfiniteQueryObserver", {
    enumerable: true,
    get: function () {
      return _infiniteQueryObserverJs.InfiniteQueryObserver;
    }
  });
  Object.defineProperty(exports, "Mutation", {
    enumerable: true,
    get: function () {
      return _mutationJs.Mutation;
    }
  });
  Object.defineProperty(exports, "MutationCache", {
    enumerable: true,
    get: function () {
      return _mutationCacheJs.MutationCache;
    }
  });
  Object.defineProperty(exports, "MutationObserver", {
    enumerable: true,
    get: function () {
      return _mutationObserverJs.MutationObserver;
    }
  });
  Object.defineProperty(exports, "QueriesObserver", {
    enumerable: true,
    get: function () {
      return _queriesObserverJs.QueriesObserver;
    }
  });
  Object.defineProperty(exports, "Query", {
    enumerable: true,
    get: function () {
      return _queryJs.Query;
    }
  });
  Object.defineProperty(exports, "QueryCache", {
    enumerable: true,
    get: function () {
      return _queryCacheJs.QueryCache;
    }
  });
  Object.defineProperty(exports, "QueryClient", {
    enumerable: true,
    get: function () {
      return _queryClientJs.QueryClient;
    }
  });
  Object.defineProperty(exports, "QueryObserver", {
    enumerable: true,
    get: function () {
      return _queryObserverJs.QueryObserver;
    }
  });
  Object.defineProperty(exports, "defaultScheduler", {
    enumerable: true,
    get: function () {
      return _notifyManagerJs.defaultScheduler;
    }
  });
  Object.defineProperty(exports, "defaultShouldDehydrateMutation", {
    enumerable: true,
    get: function () {
      return _hydrationJs.defaultShouldDehydrateMutation;
    }
  });
  Object.defineProperty(exports, "defaultShouldDehydrateQuery", {
    enumerable: true,
    get: function () {
      return _hydrationJs.defaultShouldDehydrateQuery;
    }
  });
  Object.defineProperty(exports, "dehydrate", {
    enumerable: true,
    get: function () {
      return _hydrationJs.dehydrate;
    }
  });
  Object.defineProperty(exports, "environmentManager", {
    enumerable: true,
    get: function () {
      return _environmentManagerJs.environmentManager;
    }
  });
  Object.defineProperty(exports, "experimental_streamedQuery", {
    enumerable: true,
    get: function () {
      return _streamedQueryJs.streamedQuery;
    }
  });
  Object.defineProperty(exports, "focusManager", {
    enumerable: true,
    get: function () {
      return _focusManagerJs.focusManager;
    }
  });
  Object.defineProperty(exports, "hashKey", {
    enumerable: true,
    get: function () {
      return _utilsJs.hashKey;
    }
  });
  Object.defineProperty(exports, "hydrate", {
    enumerable: true,
    get: function () {
      return _hydrationJs.hydrate;
    }
  });
  Object.defineProperty(exports, "isCancelledError", {
    enumerable: true,
    get: function () {
      return _retryerJs.isCancelledError;
    }
  });
  Object.defineProperty(exports, "isServer", {
    enumerable: true,
    get: function () {
      return _utilsJs.isServer;
    }
  });
  Object.defineProperty(exports, "keepPreviousData", {
    enumerable: true,
    get: function () {
      return _utilsJs.keepPreviousData;
    }
  });
  Object.defineProperty(exports, "matchMutation", {
    enumerable: true,
    get: function () {
      return _utilsJs.matchMutation;
    }
  });
  Object.defineProperty(exports, "matchQuery", {
    enumerable: true,
    get: function () {
      return _utilsJs.matchQuery;
    }
  });
  Object.defineProperty(exports, "noop", {
    enumerable: true,
    get: function () {
      return _utilsJs.noop;
    }
  });
  Object.defineProperty(exports, "notifyManager", {
    enumerable: true,
    get: function () {
      return _notifyManagerJs.notifyManager;
    }
  });
  Object.defineProperty(exports, "onlineManager", {
    enumerable: true,
    get: function () {
      return _onlineManagerJs.onlineManager;
    }
  });
  Object.defineProperty(exports, "partialMatchKey", {
    enumerable: true,
    get: function () {
      return _utilsJs.partialMatchKey;
    }
  });
  Object.defineProperty(exports, "replaceEqualDeep", {
    enumerable: true,
    get: function () {
      return _utilsJs.replaceEqualDeep;
    }
  });
  Object.defineProperty(exports, "shouldThrowError", {
    enumerable: true,
    get: function () {
      return _utilsJs.shouldThrowError;
    }
  });
  Object.defineProperty(exports, "skipToken", {
    enumerable: true,
    get: function () {
      return _utilsJs.skipToken;
    }
  });
  Object.defineProperty(exports, "timeoutManager", {
    enumerable: true,
    get: function () {
      return _timeoutManagerJs.timeoutManager;
    }
  });
  var _focusManagerJs = require(_dependencyMap[0], "./focusManager.js");
  var _environmentManagerJs = require(_dependencyMap[1], "./environmentManager.js");
  var _hydrationJs = require(_dependencyMap[2], "./hydration.js");
  var _infiniteQueryObserverJs = require(_dependencyMap[3], "./infiniteQueryObserver.js");
  var _mutationCacheJs = require(_dependencyMap[4], "./mutationCache.js");
  var _mutationObserverJs = require(_dependencyMap[5], "./mutationObserver.js");
  var _notifyManagerJs = require(_dependencyMap[6], "./notifyManager.js");
  var _onlineManagerJs = require(_dependencyMap[7], "./onlineManager.js");
  var _queriesObserverJs = require(_dependencyMap[8], "./queriesObserver.js");
  var _queryCacheJs = require(_dependencyMap[9], "./queryCache.js");
  var _queryClientJs = require(_dependencyMap[10], "./queryClient.js");
  var _queryObserverJs = require(_dependencyMap[11], "./queryObserver.js");
  var _retryerJs = require(_dependencyMap[12], "./retryer.js");
  var _timeoutManagerJs = require(_dependencyMap[13], "./timeoutManager.js");
  var _utilsJs = require(_dependencyMap[14], "./utils.js");
  var _streamedQueryJs = require(_dependencyMap[15], "./streamedQuery.js");
  var _mutationJs = require(_dependencyMap[16], "./mutation.js");
  var _queryJs = require(_dependencyMap[17], "./query.js");
  var _typesJs = require(_dependencyMap[18], "./types.js");
  Object.keys(_typesJs).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _typesJs[k];
        }
      });
    }
  });
},1286,[1287,1289,1292,1294,1304,1306,1298,1301,1307,1308,1309,1295,1300,1291,1290,1310,1305,1299,1311],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "FocusManager", {
    enumerable: true,
    get: function () {
      return FocusManager;
    }
  });
  Object.defineProperty(exports, "focusManager", {
    enumerable: true,
    get: function () {
      return focusManager;
    }
  });
  var _subscribableJs = require(_dependencyMap[0], "./subscribable.js");
  // src/focusManager.ts

  var FocusManager = class extends _subscribableJs.Subscribable {
    #focused;
    #cleanup;
    #setup;
    constructor() {
      super();
      this.#setup = onFocus => {
        if (typeof window !== "undefined" && window.addEventListener) {
          const listener = () => onFocus();
          window.addEventListener("visibilitychange", listener, false);
          return () => {
            window.removeEventListener("visibilitychange", listener);
          };
        }
        return;
      };
    }
    onSubscribe() {
      if (!this.#cleanup) {
        this.setEventListener(this.#setup);
      }
    }
    onUnsubscribe() {
      if (!this.hasListeners()) {
        this.#cleanup?.();
        this.#cleanup = void 0;
      }
    }
    setEventListener(setup) {
      this.#setup = setup;
      this.#cleanup?.();
      this.#cleanup = setup(focused => {
        if (typeof focused === "boolean") {
          this.setFocused(focused);
        } else {
          this.onFocus();
        }
      });
    }
    setFocused(focused) {
      const changed = this.#focused !== focused;
      if (changed) {
        this.#focused = focused;
        this.onFocus();
      }
    }
    onFocus() {
      const isFocused = this.isFocused();
      this.listeners.forEach(listener => {
        listener(isFocused);
      });
    }
    isFocused() {
      if (typeof this.#focused === "boolean") {
        return this.#focused;
      }
      return globalThis.document?.visibilityState !== "hidden";
    }
  };
  var focusManager = new FocusManager();
},1287,[1288],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/focusManager.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "Subscribable", {
    enumerable: true,
    get: function () {
      return Subscribable;
    }
  });
  // src/subscribable.ts
  var Subscribable = class {
    constructor() {
      this.listeners = /* @__PURE__ */new Set();
      this.subscribe = this.subscribe.bind(this);
    }
    subscribe(listener) {
      this.listeners.add(listener);
      this.onSubscribe();
      return () => {
        this.listeners.delete(listener);
        this.onUnsubscribe();
      };
    }
    hasListeners() {
      return this.listeners.size > 0;
    }
    onSubscribe() {}
    onUnsubscribe() {}
  };
},1288,[],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/subscribable.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "environmentManager", {
    enumerable: true,
    get: function () {
      return environmentManager;
    }
  });
  var _utilsJs = require(_dependencyMap[0], "./utils.js");
  // src/environmentManager.ts

  var environmentManager = /* @__PURE__ */(() => {
    let isServerFn = () => _utilsJs.isServer;
    return {
      /**
       * Returns whether the current runtime should be treated as a server environment.
       */
      isServer() {
        return isServerFn();
      },
      /**
       * Overrides the server check globally.
       */
      setIsServer(isServerValue) {
        isServerFn = isServerValue;
      }
    };
  })();
},1289,[1290],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/environmentManager.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "addConsumeAwareSignal", {
    enumerable: true,
    get: function () {
      return addConsumeAwareSignal;
    }
  });
  Object.defineProperty(exports, "addToEnd", {
    enumerable: true,
    get: function () {
      return addToEnd;
    }
  });
  Object.defineProperty(exports, "addToStart", {
    enumerable: true,
    get: function () {
      return addToStart;
    }
  });
  Object.defineProperty(exports, "ensureQueryFn", {
    enumerable: true,
    get: function () {
      return ensureQueryFn;
    }
  });
  Object.defineProperty(exports, "functionalUpdate", {
    enumerable: true,
    get: function () {
      return functionalUpdate;
    }
  });
  Object.defineProperty(exports, "hashKey", {
    enumerable: true,
    get: function () {
      return hashKey;
    }
  });
  Object.defineProperty(exports, "hashQueryKeyByOptions", {
    enumerable: true,
    get: function () {
      return hashQueryKeyByOptions;
    }
  });
  Object.defineProperty(exports, "isPlainArray", {
    enumerable: true,
    get: function () {
      return isPlainArray;
    }
  });
  Object.defineProperty(exports, "isPlainObject", {
    enumerable: true,
    get: function () {
      return isPlainObject;
    }
  });
  Object.defineProperty(exports, "isServer", {
    enumerable: true,
    get: function () {
      return isServer;
    }
  });
  Object.defineProperty(exports, "isValidTimeout", {
    enumerable: true,
    get: function () {
      return isValidTimeout;
    }
  });
  Object.defineProperty(exports, "keepPreviousData", {
    enumerable: true,
    get: function () {
      return keepPreviousData;
    }
  });
  Object.defineProperty(exports, "matchMutation", {
    enumerable: true,
    get: function () {
      return matchMutation;
    }
  });
  Object.defineProperty(exports, "matchQuery", {
    enumerable: true,
    get: function () {
      return matchQuery;
    }
  });
  Object.defineProperty(exports, "noop", {
    enumerable: true,
    get: function () {
      return noop;
    }
  });
  Object.defineProperty(exports, "partialMatchKey", {
    enumerable: true,
    get: function () {
      return partialMatchKey;
    }
  });
  Object.defineProperty(exports, "replaceData", {
    enumerable: true,
    get: function () {
      return replaceData;
    }
  });
  Object.defineProperty(exports, "replaceEqualDeep", {
    enumerable: true,
    get: function () {
      return replaceEqualDeep;
    }
  });
  Object.defineProperty(exports, "resolveQueryBoolean", {
    enumerable: true,
    get: function () {
      return resolveQueryBoolean;
    }
  });
  Object.defineProperty(exports, "resolveStaleTime", {
    enumerable: true,
    get: function () {
      return resolveStaleTime;
    }
  });
  Object.defineProperty(exports, "shallowEqualObjects", {
    enumerable: true,
    get: function () {
      return shallowEqualObjects;
    }
  });
  Object.defineProperty(exports, "shouldThrowError", {
    enumerable: true,
    get: function () {
      return shouldThrowError;
    }
  });
  Object.defineProperty(exports, "skipToken", {
    enumerable: true,
    get: function () {
      return skipToken;
    }
  });
  Object.defineProperty(exports, "sleep", {
    enumerable: true,
    get: function () {
      return sleep;
    }
  });
  Object.defineProperty(exports, "timeUntilStale", {
    enumerable: true,
    get: function () {
      return timeUntilStale;
    }
  });
  var _timeoutManagerJs = require(_dependencyMap[0], "./timeoutManager.js");
  // src/utils.ts

  var isServer = typeof window === "undefined" || "Deno" in globalThis;
  function noop() {}
  function functionalUpdate(updater, input) {
    return typeof updater === "function" ? updater(input) : updater;
  }
  function isValidTimeout(value) {
    return typeof value === "number" && value >= 0 && value !== Infinity;
  }
  function timeUntilStale(updatedAt, staleTime) {
    return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
  }
  function resolveStaleTime(staleTime, query) {
    return typeof staleTime === "function" ? staleTime(query) : staleTime;
  }
  function resolveQueryBoolean(option, query) {
    return typeof option === "function" ? option(query) : option;
  }
  function matchQuery(filters, query) {
    const {
      type = "all",
      exact,
      fetchStatus,
      predicate,
      queryKey,
      stale
    } = filters;
    if (queryKey) {
      if (exact) {
        if (query.queryHash !== hashQueryKeyByOptions(queryKey, query.options)) {
          return false;
        }
      } else if (!partialMatchKey(query.queryKey, queryKey)) {
        return false;
      }
    }
    if (type !== "all") {
      const isActive = query.isActive();
      if (type === "active" && !isActive) {
        return false;
      }
      if (type === "inactive" && isActive) {
        return false;
      }
    }
    if (typeof stale === "boolean" && query.isStale() !== stale) {
      return false;
    }
    if (fetchStatus && fetchStatus !== query.state.fetchStatus) {
      return false;
    }
    if (predicate && !predicate(query)) {
      return false;
    }
    return true;
  }
  function matchMutation(filters, mutation) {
    const {
      exact,
      status,
      predicate,
      mutationKey
    } = filters;
    if (mutationKey) {
      if (!mutation.options.mutationKey) {
        return false;
      }
      if (exact) {
        if (hashKey(mutation.options.mutationKey) !== hashKey(mutationKey)) {
          return false;
        }
      } else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) {
        return false;
      }
    }
    if (status && mutation.state.status !== status) {
      return false;
    }
    if (predicate && !predicate(mutation)) {
      return false;
    }
    return true;
  }
  function hashQueryKeyByOptions(queryKey, options) {
    const hashFn = options?.queryKeyHashFn || hashKey;
    return hashFn(queryKey);
  }
  function hashKey(queryKey) {
    return JSON.stringify(queryKey, (_, val) => isPlainObject(val) ? Object.keys(val).sort().reduce((result, key) => {
      result[key] = val[key];
      return result;
    }, {}) : val);
  }
  function partialMatchKey(a, b) {
    if (a === b) {
      return true;
    }
    if (typeof a !== typeof b) {
      return false;
    }
    if (a && b && typeof a === "object" && typeof b === "object") {
      return Object.keys(b).every(key => partialMatchKey(a[key], b[key]));
    }
    return false;
  }
  var hasOwn = Object.prototype.hasOwnProperty;
  function replaceEqualDeep(a, b, depth = 0) {
    if (a === b) {
      return a;
    }
    if (depth > 500) return b;
    const array = isPlainArray(a) && isPlainArray(b);
    if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
    const aItems = array ? a : Object.keys(a);
    const aSize = aItems.length;
    const bItems = array ? b : Object.keys(b);
    const bSize = bItems.length;
    const copy = array ? new Array(bSize) : {};
    let equalItems = 0;
    for (let i = 0; i < bSize; i++) {
      const key = array ? i : bItems[i];
      const aItem = a[key];
      const bItem = b[key];
      if (aItem === bItem) {
        copy[key] = aItem;
        if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
        continue;
      }
      if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
        copy[key] = bItem;
        continue;
      }
      const v = replaceEqualDeep(aItem, bItem, depth + 1);
      copy[key] = v;
      if (v === aItem) equalItems++;
    }
    return aSize === bSize && equalItems === aSize ? a : copy;
  }
  function shallowEqualObjects(a, b) {
    if (!b || Object.keys(a).length !== Object.keys(b).length) {
      return false;
    }
    for (const key in a) {
      if (a[key] !== b[key]) {
        return false;
      }
    }
    return true;
  }
  function isPlainArray(value) {
    return Array.isArray(value) && value.length === Object.keys(value).length;
  }
  function isPlainObject(o) {
    if (!hasObjectPrototype(o)) {
      return false;
    }
    const ctor = o.constructor;
    if (ctor === void 0) {
      return true;
    }
    const prot = ctor.prototype;
    if (!hasObjectPrototype(prot)) {
      return false;
    }
    if (!prot.hasOwnProperty("isPrototypeOf")) {
      return false;
    }
    if (Object.getPrototypeOf(o) !== Object.prototype) {
      return false;
    }
    return true;
  }
  function hasObjectPrototype(o) {
    return Object.prototype.toString.call(o) === "[object Object]";
  }
  function sleep(timeout) {
    return new Promise(resolve => {
      _timeoutManagerJs.timeoutManager.setTimeout(resolve, timeout);
    });
  }
  function replaceData(prevData, data, options) {
    if (typeof options.structuralSharing === "function") {
      return options.structuralSharing(prevData, data);
    } else if (options.structuralSharing !== false) {
      if (process.env.NODE_ENV !== "production") {
        try {
          return replaceEqualDeep(prevData, data);
        } catch (error) {
          console.error(`Structural sharing requires data to be JSON serializable. To fix this, turn off structuralSharing or return JSON-serializable data from your queryFn. [${options.queryHash}]: ${error}`);
          throw error;
        }
      }
      return replaceEqualDeep(prevData, data);
    }
    return data;
  }
  function keepPreviousData(previousData) {
    return previousData;
  }
  function addToEnd(items, item, max = 0) {
    const newItems = [...items, item];
    return max && newItems.length > max ? newItems.slice(1) : newItems;
  }
  function addToStart(items, item, max = 0) {
    const newItems = [item, ...items];
    return max && newItems.length > max ? newItems.slice(0, -1) : newItems;
  }
  var skipToken = /* @__PURE__ */Symbol();
  function ensureQueryFn(options, fetchOptions) {
    if (process.env.NODE_ENV !== "production") {
      if (options.queryFn === skipToken) {
        console.error(`Attempted to invoke queryFn when set to skipToken. This is likely a configuration error. Query hash: '${options.queryHash}'`);
      }
    }
    if (!options.queryFn && fetchOptions?.initialPromise) {
      return () => fetchOptions.initialPromise;
    }
    if (!options.queryFn || options.queryFn === skipToken) {
      return () => Promise.reject(new Error(`Missing queryFn: '${options.queryHash}'`));
    }
    return options.queryFn;
  }
  function shouldThrowError(throwOnError, params) {
    if (typeof throwOnError === "function") {
      return throwOnError(...params);
    }
    return !!throwOnError;
  }
  function addConsumeAwareSignal(object, getSignal, onCancelled) {
    let consumed = false;
    let signal;
    Object.defineProperty(object, "signal", {
      enumerable: true,
      get: () => {
        signal ??= getSignal();
        if (consumed) {
          return signal;
        }
        consumed = true;
        if (signal.aborted) {
          onCancelled();
        } else {
          signal.addEventListener("abort", onCancelled, {
            once: true
          });
        }
        return signal;
      }
    });
    return object;
  }
},1290,[1291],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/utils.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "TimeoutManager", {
    enumerable: true,
    get: function () {
      return TimeoutManager;
    }
  });
  Object.defineProperty(exports, "defaultTimeoutProvider", {
    enumerable: true,
    get: function () {
      return defaultTimeoutProvider;
    }
  });
  Object.defineProperty(exports, "systemSetTimeoutZero", {
    enumerable: true,
    get: function () {
      return systemSetTimeoutZero;
    }
  });
  Object.defineProperty(exports, "timeoutManager", {
    enumerable: true,
    get: function () {
      return timeoutManager;
    }
  });
  // src/timeoutManager.ts
  var defaultTimeoutProvider = {
    // We need the wrapper function syntax below instead of direct references to
    // global setTimeout etc.
    //
    // BAD: `setTimeout: setTimeout`
    // GOOD: `setTimeout: (cb, delay) => setTimeout(cb, delay)`
    //
    // If we use direct references here, then anything that wants to spy on or
    // replace the global setTimeout (like tests) won't work since we'll already
    // have a hard reference to the original implementation at the time when this
    // file was imported.
    setTimeout: (callback, delay) => setTimeout(callback, delay),
    clearTimeout: timeoutId => clearTimeout(timeoutId),
    setInterval: (callback, delay) => setInterval(callback, delay),
    clearInterval: intervalId => clearInterval(intervalId)
  };
  var TimeoutManager = class {
    // We cannot have TimeoutManager<T> as we must instantiate it with a concrete
    // type at app boot; and if we leave that type, then any new timer provider
    // would need to support the default provider's concrete timer ID, which is
    // infeasible across environments.
    //
    // We settle for type safety for the TimeoutProvider type, and accept that
    // this class is unsafe internally to allow for extension.
    #provider = defaultTimeoutProvider;
    #providerCalled = false;
    setTimeoutProvider(provider) {
      if (process.env.NODE_ENV !== "production") {
        if (this.#providerCalled && provider !== this.#provider) {
          console.error(`[timeoutManager]: Switching provider after calls to previous provider might result in unexpected behavior.`, {
            previous: this.#provider,
            provider
          });
        }
      }
      this.#provider = provider;
      if (process.env.NODE_ENV !== "production") {
        this.#providerCalled = false;
      }
    }
    setTimeout(callback, delay) {
      if (process.env.NODE_ENV !== "production") {
        this.#providerCalled = true;
      }
      return this.#provider.setTimeout(callback, delay);
    }
    clearTimeout(timeoutId) {
      this.#provider.clearTimeout(timeoutId);
    }
    setInterval(callback, delay) {
      if (process.env.NODE_ENV !== "production") {
        this.#providerCalled = true;
      }
      return this.#provider.setInterval(callback, delay);
    }
    clearInterval(intervalId) {
      this.#provider.clearInterval(intervalId);
    }
  };
  var timeoutManager = new TimeoutManager();
  function systemSetTimeoutZero(callback) {
    setTimeout(callback, 0);
  }
},1291,[],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/timeoutManager.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "defaultShouldDehydrateMutation", {
    enumerable: true,
    get: function () {
      return defaultShouldDehydrateMutation;
    }
  });
  Object.defineProperty(exports, "defaultShouldDehydrateQuery", {
    enumerable: true,
    get: function () {
      return defaultShouldDehydrateQuery;
    }
  });
  Object.defineProperty(exports, "dehydrate", {
    enumerable: true,
    get: function () {
      return dehydrate;
    }
  });
  Object.defineProperty(exports, "hydrate", {
    enumerable: true,
    get: function () {
      return hydrate;
    }
  });
  var _thenableJs = require(_dependencyMap[0], "./thenable.js");
  var _utilsJs = require(_dependencyMap[1], "./utils.js");
  // src/hydration.ts

  function defaultTransformerFn(data) {
    return data;
  }
  function dehydrateMutation(mutation) {
    return {
      mutationKey: mutation.options.mutationKey,
      state: mutation.state,
      ...(mutation.options.scope && {
        scope: mutation.options.scope
      }),
      ...(mutation.meta && {
        meta: mutation.meta
      })
    };
  }
  function dehydrateQuery(query, serializeData, shouldRedactErrors) {
    const dehydratePromise = () => {
      const promise = query.promise?.then(serializeData).catch(error => {
        if (!shouldRedactErrors(error)) {
          return Promise.reject(error);
        }
        if (process.env.NODE_ENV !== "production") {
          console.error(`A query that was dehydrated as pending ended up rejecting. [${query.queryHash}]: ${error}; The error will be redacted in production builds`);
        }
        return Promise.reject(new Error("redacted"));
      });
      promise?.catch(_utilsJs.noop);
      return promise;
    };
    return {
      dehydratedAt: Date.now(),
      state: {
        ...query.state,
        ...(query.state.data !== void 0 && {
          data: serializeData(query.state.data)
        })
      },
      queryKey: query.queryKey,
      queryHash: query.queryHash,
      ...(query.state.status === "pending" && {
        promise: dehydratePromise()
      }),
      ...(query.meta && {
        meta: query.meta
      }),
      ...(query.queryType && {
        queryType: query.queryType
      })
    };
  }
  function defaultShouldDehydrateMutation(mutation) {
    return mutation.state.isPaused;
  }
  function defaultShouldDehydrateQuery(query) {
    return query.state.status === "success";
  }
  function defaultShouldRedactErrors(_) {
    return true;
  }
  function dehydrate(client, options = {}) {
    const filterMutation = options.shouldDehydrateMutation ?? client.getDefaultOptions().dehydrate?.shouldDehydrateMutation ?? defaultShouldDehydrateMutation;
    const mutations = client.getMutationCache().getAll().flatMap(mutation => filterMutation(mutation) ? [dehydrateMutation(mutation)] : []);
    const filterQuery = options.shouldDehydrateQuery ?? client.getDefaultOptions().dehydrate?.shouldDehydrateQuery ?? defaultShouldDehydrateQuery;
    const shouldRedactErrors = options.shouldRedactErrors ?? client.getDefaultOptions().dehydrate?.shouldRedactErrors ?? defaultShouldRedactErrors;
    const serializeData = options.serializeData ?? client.getDefaultOptions().dehydrate?.serializeData ?? defaultTransformerFn;
    const queries = client.getQueryCache().getAll().flatMap(query => filterQuery(query) ? [dehydrateQuery(query, serializeData, shouldRedactErrors)] : []);
    return {
      mutations,
      queries
    };
  }
  function hydrate(client, dehydratedState, options) {
    if (typeof dehydratedState !== "object" || dehydratedState === null) {
      return;
    }
    const mutationCache = client.getMutationCache();
    const queryCache = client.getQueryCache();
    const deserializeData = options?.defaultOptions?.deserializeData ?? client.getDefaultOptions().hydrate?.deserializeData ?? defaultTransformerFn;
    const mutations = dehydratedState.mutations || [];
    const queries = dehydratedState.queries || [];
    mutations.forEach(({
      state,
      ...mutationOptions
    }) => {
      mutationCache.build(client, {
        ...client.getDefaultOptions().hydrate?.mutations,
        ...options?.defaultOptions?.mutations,
        ...mutationOptions
      }, state);
    });
    queries.forEach(({
      queryKey,
      state,
      queryHash,
      meta,
      promise,
      dehydratedAt,
      queryType
    }) => {
      const syncData = promise ? (0, _thenableJs.tryResolveSync)(promise) : void 0;
      const rawData = state.data === void 0 ? syncData?.data : state.data;
      const data = rawData === void 0 ? rawData : deserializeData(rawData);
      let query = queryCache.get(queryHash);
      const existingQueryIsPending = query?.state.status === "pending";
      const existingQueryIsFetching = query?.state.fetchStatus === "fetching";
      if (query) {
        const hasNewerSyncData = syncData &&
        // We only need this undefined check to handle older dehydration
        // payloads that might not have dehydratedAt
        dehydratedAt !== void 0 && dehydratedAt > query.state.dataUpdatedAt;
        if (state.dataUpdatedAt > query.state.dataUpdatedAt || hasNewerSyncData) {
          const {
            fetchStatus: _ignored,
            ...serializedState
          } = state;
          query.setState({
            ...serializedState,
            data,
            // If the query was pending at the moment of dehydration, but resolved to have data
            // before hydration, we can assume the query should be hydrated as successful.
            //
            // Since you can opt into dehydrating failed queries, and those can have data from
            // previous successful fetches, we make sure we only do this for pending queries.
            ...(state.status === "pending" && data !== void 0 && {
              status: "success",
              // Preserve existing fetchStatus if the existing query is actively fetching.
              ...(!existingQueryIsFetching && {
                fetchStatus: "idle"
              })
            })
          });
        }
      } else {
        query = queryCache.build(client, {
          ...client.getDefaultOptions().hydrate?.queries,
          ...options?.defaultOptions?.queries,
          queryKey,
          queryHash,
          meta,
          _type: queryType
        },
        // Reset fetch status to idle to avoid
        // query being stuck in fetching state upon hydration
        {
          ...state,
          data,
          fetchStatus: "idle",
          // Like above, if the query was pending at the moment of dehydration but has data,
          // we can assume it should be hydrated as successful.
          status: state.status === "pending" && data !== void 0 ? "success" : state.status
        });
      }
      if (promise &&
      // If the data was synchronously available, there is no need to set up
      // a retryer and thus no reason to call fetch
      !syncData && !existingQueryIsPending && !existingQueryIsFetching && (
      // Only hydrate if dehydration is newer than any existing data,
      // this is always true for new queries
      dehydratedAt === void 0 || dehydratedAt > query.state.dataUpdatedAt)) {
        query.fetch(void 0, {
          // RSC transformed promises are not thenable
          initialPromise: Promise.resolve(promise).then(deserializeData)
        }).catch(_utilsJs.noop);
      }
    });
  }
},1292,[1293,1290],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/hydration.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "pendingThenable", {
    enumerable: true,
    get: function () {
      return pendingThenable;
    }
  });
  Object.defineProperty(exports, "tryResolveSync", {
    enumerable: true,
    get: function () {
      return tryResolveSync;
    }
  });
  var _utilsJs = require(_dependencyMap[0], "./utils.js");
  // src/thenable.ts

  function pendingThenable() {
    let resolve;
    let reject;
    const thenable = new Promise((_resolve, _reject) => {
      resolve = _resolve;
      reject = _reject;
    });
    thenable.status = "pending";
    thenable.catch(() => {});
    function finalize(data) {
      Object.assign(thenable, data);
      delete thenable.resolve;
      delete thenable.reject;
    }
    thenable.resolve = value => {
      finalize({
        status: "fulfilled",
        value
      });
      resolve(value);
    };
    thenable.reject = reason => {
      finalize({
        status: "rejected",
        reason
      });
      reject(reason);
    };
    return thenable;
  }
  function tryResolveSync(promise) {
    let data;
    promise.then(result => {
      data = result;
      return result;
    }, _utilsJs.noop)?.catch(_utilsJs.noop);
    if (data !== void 0) {
      return {
        data
      };
    }
    return void 0;
  }
},1293,[1290],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/thenable.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "InfiniteQueryObserver", {
    enumerable: true,
    get: function () {
      return InfiniteQueryObserver;
    }
  });
  var _queryObserverJs = require(_dependencyMap[0], "./queryObserver.js");
  var _infiniteQueryBehaviorJs = require(_dependencyMap[1], "./infiniteQueryBehavior.js");
  // src/infiniteQueryObserver.ts

  var InfiniteQueryObserver = class extends _queryObserverJs.QueryObserver {
    constructor(client, options) {
      super(client, options);
    }
    bindMethods() {
      super.bindMethods();
      this.fetchNextPage = this.fetchNextPage.bind(this);
      this.fetchPreviousPage = this.fetchPreviousPage.bind(this);
    }
    setOptions(options) {
      options._type = "infinite";
      super.setOptions(options);
    }
    getOptimisticResult(options) {
      options._type = "infinite";
      return super.getOptimisticResult(options);
    }
    fetchNextPage(options) {
      return this.fetch({
        ...options,
        meta: {
          fetchMore: {
            direction: "forward"
          }
        }
      });
    }
    fetchPreviousPage(options) {
      return this.fetch({
        ...options,
        meta: {
          fetchMore: {
            direction: "backward"
          }
        }
      });
    }
    createResult(query, options) {
      const {
        state
      } = query;
      const parentResult = super.createResult(query, options);
      const {
        isFetching,
        isRefetching,
        isError,
        isRefetchError
      } = parentResult;
      const fetchDirection = state.fetchMeta?.fetchMore?.direction;
      const isFetchNextPageError = isError && fetchDirection === "forward";
      const isFetchingNextPage = isFetching && fetchDirection === "forward";
      const isFetchPreviousPageError = isError && fetchDirection === "backward";
      const isFetchingPreviousPage = isFetching && fetchDirection === "backward";
      const result = {
        ...parentResult,
        fetchNextPage: this.fetchNextPage,
        fetchPreviousPage: this.fetchPreviousPage,
        hasNextPage: (0, _infiniteQueryBehaviorJs.hasNextPage)(options, state.data),
        hasPreviousPage: (0, _infiniteQueryBehaviorJs.hasPreviousPage)(options, state.data),
        isFetchNextPageError,
        isFetchingNextPage,
        isFetchPreviousPageError,
        isFetchingPreviousPage,
        isRefetchError: isRefetchError && !isFetchNextPageError && !isFetchPreviousPageError,
        isRefetching: isRefetching && !isFetchingNextPage && !isFetchingPreviousPage
      };
      return result;
    }
  };
},1294,[1295,1303],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/infiniteQueryObserver.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var _client, _currentQuery, _currentQueryInitialState, _currentResult, _currentResultState, _currentResultOptions, _currentThenable, _selectError, _selectFn, _selectResult, _lastQueryWithDefinedData, _staleTimeoutId, _refetchIntervalId, _currentRefetchInterval, _trackedProps, _executeFetch, _updateStaleTimeout, _computeRefetchInterval, _updateRefetchInterval, _updateTimers, _clearStaleTimeout, _clearRefetchInterval, _updateQuery, _notify; // src/queryObserver.ts
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "QueryObserver", {
    enumerable: true,
    get: function () {
      return QueryObserver;
    }
  });
  var _babelRuntimeHelpersClassPrivateFieldLooseBase = require(_dependencyMap[0], "@babel/runtime/helpers/classPrivateFieldLooseBase");
  var _classPrivateFieldLooseBase = _interopDefault(_babelRuntimeHelpersClassPrivateFieldLooseBase);
  var _babelRuntimeHelpersClassPrivateFieldLooseKey = require(_dependencyMap[1], "@babel/runtime/helpers/classPrivateFieldLooseKey");
  var _classPrivateFieldLooseKey = _interopDefault(_babelRuntimeHelpersClassPrivateFieldLooseKey);
  var _focusManagerJs = require(_dependencyMap[2], "./focusManager.js");
  var _environmentManagerJs = require(_dependencyMap[3], "./environmentManager.js");
  var _notifyManagerJs = require(_dependencyMap[4], "./notifyManager.js");
  var _queryJs = require(_dependencyMap[5], "./query.js");
  var _subscribableJs = require(_dependencyMap[6], "./subscribable.js");
  var _thenableJs = require(_dependencyMap[7], "./thenable.js");
  var _utilsJs = require(_dependencyMap[8], "./utils.js");
  var _timeoutManagerJs = require(_dependencyMap[9], "./timeoutManager.js");
  var QueryObserver = (_client = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("client"), _currentQuery = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("currentQuery"), _currentQueryInitialState = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("currentQueryInitialState"), _currentResult = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("currentResult"), _currentResultState = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("currentResultState"), _currentResultOptions = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("currentResultOptions"), _currentThenable = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("currentThenable"), _selectError = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("selectError"), _selectFn = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("selectFn"), _selectResult = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("selectResult"), _lastQueryWithDefinedData = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("lastQueryWithDefinedData"), _staleTimeoutId = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("staleTimeoutId"), _refetchIntervalId = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("refetchIntervalId"), _currentRefetchInterval = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("currentRefetchInterval"), _trackedProps = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("trackedProps"), _executeFetch = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("executeFetch"), _updateStaleTimeout = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("updateStaleTimeout"), _computeRefetchInterval = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("computeRefetchInterval"), _updateRefetchInterval = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("updateRefetchInterval"), _updateTimers = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("updateTimers"), _clearStaleTimeout = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("clearStaleTimeout"), _clearRefetchInterval = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("clearRefetchInterval"), _updateQuery = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("updateQuery"), _notify = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("notify"), class QueryObserver extends _subscribableJs.Subscribable {
    constructor(client, options) {
      super();
      Object.defineProperty(this, _notify, {
        value: _notify2
      });
      Object.defineProperty(this, _updateQuery, {
        value: _updateQuery2
      });
      Object.defineProperty(this, _clearRefetchInterval, {
        value: _clearRefetchInterval2
      });
      Object.defineProperty(this, _clearStaleTimeout, {
        value: _clearStaleTimeout2
      });
      Object.defineProperty(this, _updateTimers, {
        value: _updateTimers2
      });
      Object.defineProperty(this, _updateRefetchInterval, {
        value: _updateRefetchInterval2
      });
      Object.defineProperty(this, _computeRefetchInterval, {
        value: _computeRefetchInterval2
      });
      Object.defineProperty(this, _updateStaleTimeout, {
        value: _updateStaleTimeout2
      });
      Object.defineProperty(this, _executeFetch, {
        value: _executeFetch2
      });
      Object.defineProperty(this, _client, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _currentQuery, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _currentQueryInitialState, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _currentResult, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _currentResultState, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _currentResultOptions, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _currentThenable, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _selectError, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _selectFn, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _selectResult, {
        writable: true,
        value: void 0
      });
      // This property keeps track of the last query with defined data.
      // It will be used to pass the previous data and query to the placeholder function between renders.
      Object.defineProperty(this, _lastQueryWithDefinedData, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _staleTimeoutId, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _refetchIntervalId, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _currentRefetchInterval, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _trackedProps, {
        writable: true,
        value: /* @__PURE__ */new Set()
      });
      this.options = options;
      (0, _classPrivateFieldLooseBase.default)(this, _client)[_client] = client;
      (0, _classPrivateFieldLooseBase.default)(this, _selectError)[_selectError] = null;
      (0, _classPrivateFieldLooseBase.default)(this, _currentThenable)[_currentThenable] = (0, _thenableJs.pendingThenable)();
      this.bindMethods();
      this.setOptions(options);
    }
    bindMethods() {
      this.refetch = this.refetch.bind(this);
    }
    onSubscribe() {
      if (this.listeners.size === 1) {
        (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery].addObserver(this);
        if (shouldFetchOnMount((0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery], this.options)) {
          (0, _classPrivateFieldLooseBase.default)(this, _executeFetch)[_executeFetch]();
        } else {
          this.updateResult();
        }
        (0, _classPrivateFieldLooseBase.default)(this, _updateTimers)[_updateTimers]();
      }
    }
    onUnsubscribe() {
      if (!this.hasListeners()) {
        this.destroy();
      }
    }
    shouldFetchOnReconnect() {
      return shouldFetchOn((0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery], this.options, this.options.refetchOnReconnect);
    }
    shouldFetchOnWindowFocus() {
      return shouldFetchOn((0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery], this.options, this.options.refetchOnWindowFocus);
    }
    destroy() {
      this.listeners = /* @__PURE__ */new Set();
      (0, _classPrivateFieldLooseBase.default)(this, _clearStaleTimeout)[_clearStaleTimeout]();
      (0, _classPrivateFieldLooseBase.default)(this, _clearRefetchInterval)[_clearRefetchInterval]();
      (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery].removeObserver(this);
    }
    setOptions(options) {
      const prevOptions = this.options;
      const prevQuery = (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery];
      this.options = (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].defaultQueryOptions(options);
      if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof (0, _utilsJs.resolveQueryBoolean)(this.options.enabled, (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery]) !== "boolean") {
        throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
      }
      (0, _classPrivateFieldLooseBase.default)(this, _updateQuery)[_updateQuery]();
      (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery].setOptions(this.options);
      if (prevOptions._defaulted && !(0, _utilsJs.shallowEqualObjects)(this.options, prevOptions)) {
        (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].getQueryCache().notify({
          type: "observerOptionsUpdated",
          query: (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery],
          observer: this
        });
      }
      const mounted = this.hasListeners();
      if (mounted && shouldFetchOptionally((0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery], prevQuery, this.options, prevOptions)) {
        (0, _classPrivateFieldLooseBase.default)(this, _executeFetch)[_executeFetch]();
      }
      this.updateResult();
      if (mounted && ((0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery] !== prevQuery || (0, _utilsJs.resolveQueryBoolean)(this.options.enabled, (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery]) !== (0, _utilsJs.resolveQueryBoolean)(prevOptions.enabled, (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery]) || (0, _utilsJs.resolveStaleTime)(this.options.staleTime, (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery]) !== (0, _utilsJs.resolveStaleTime)(prevOptions.staleTime, (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery]))) {
        (0, _classPrivateFieldLooseBase.default)(this, _updateStaleTimeout)[_updateStaleTimeout]();
      }
      const nextRefetchInterval = (0, _classPrivateFieldLooseBase.default)(this, _computeRefetchInterval)[_computeRefetchInterval]();
      if (mounted && ((0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery] !== prevQuery || (0, _utilsJs.resolveQueryBoolean)(this.options.enabled, (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery]) !== (0, _utilsJs.resolveQueryBoolean)(prevOptions.enabled, (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery]) || nextRefetchInterval !== (0, _classPrivateFieldLooseBase.default)(this, _currentRefetchInterval)[_currentRefetchInterval])) {
        (0, _classPrivateFieldLooseBase.default)(this, _updateRefetchInterval)[_updateRefetchInterval](nextRefetchInterval);
      }
    }
    getOptimisticResult(options) {
      const query = (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].getQueryCache().build((0, _classPrivateFieldLooseBase.default)(this, _client)[_client], options);
      const result = this.createResult(query, options);
      if (shouldAssignObserverCurrentProperties(this, result)) {
        (0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult] = result;
        (0, _classPrivateFieldLooseBase.default)(this, _currentResultOptions)[_currentResultOptions] = this.options;
        (0, _classPrivateFieldLooseBase.default)(this, _currentResultState)[_currentResultState] = (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery].state;
      }
      return result;
    }
    getCurrentResult() {
      return (0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult];
    }
    trackResult(result, onPropTracked) {
      return new Proxy(result, {
        get: (target, key) => {
          this.trackProp(key);
          onPropTracked?.(key);
          if (key === "promise") {
            this.trackProp("data");
            if (!this.options.experimental_prefetchInRender && (0, _classPrivateFieldLooseBase.default)(this, _currentThenable)[_currentThenable].status === "pending") {
              (0, _classPrivateFieldLooseBase.default)(this, _currentThenable)[_currentThenable].reject(new Error("experimental_prefetchInRender feature flag is not enabled"));
            }
          }
          return Reflect.get(target, key);
        }
      });
    }
    trackProp(key) {
      (0, _classPrivateFieldLooseBase.default)(this, _trackedProps)[_trackedProps].add(key);
    }
    getCurrentQuery() {
      return (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery];
    }
    refetch({
      ...options
    } = {}) {
      return this.fetch({
        ...options
      });
    }
    fetchOptimistic(options) {
      const defaultedOptions = (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].defaultQueryOptions(options);
      const query = (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].getQueryCache().build((0, _classPrivateFieldLooseBase.default)(this, _client)[_client], defaultedOptions);
      return query.fetch().then(() => this.createResult(query, defaultedOptions));
    }
    fetch(fetchOptions) {
      return (0, _classPrivateFieldLooseBase.default)(this, _executeFetch)[_executeFetch]({
        ...fetchOptions,
        cancelRefetch: fetchOptions.cancelRefetch ?? true
      }).then(() => {
        this.updateResult();
        return (0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult];
      });
    }
    createResult(query, options) {
      const prevQuery = (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery];
      const prevOptions = this.options;
      const prevResult = (0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult];
      const prevResultState = (0, _classPrivateFieldLooseBase.default)(this, _currentResultState)[_currentResultState];
      const prevResultOptions = (0, _classPrivateFieldLooseBase.default)(this, _currentResultOptions)[_currentResultOptions];
      const queryChange = query !== prevQuery;
      const queryInitialState = queryChange ? query.state : (0, _classPrivateFieldLooseBase.default)(this, _currentQueryInitialState)[_currentQueryInitialState];
      const {
        state
      } = query;
      let newState = {
        ...state
      };
      let isPlaceholderData = false;
      let data;
      if (options._optimisticResults) {
        const mounted = this.hasListeners();
        const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
        const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
        if (fetchOnMount || fetchOptionally) {
          newState = {
            ...newState,
            ...(0, _queryJs.fetchState)(state.data, query.options)
          };
        }
        if (options._optimisticResults === "isRestoring") {
          newState.fetchStatus = "idle";
        }
      }
      let {
        error,
        errorUpdatedAt,
        status
      } = newState;
      data = newState.data;
      let skipSelect = false;
      if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
        let placeholderData;
        if (prevResult?.isPlaceholderData && options.placeholderData === prevResultOptions?.placeholderData) {
          placeholderData = prevResult.data;
          skipSelect = true;
        } else {
          placeholderData = typeof options.placeholderData === "function" ? options.placeholderData((0, _classPrivateFieldLooseBase.default)(this, _lastQueryWithDefinedData)[_lastQueryWithDefinedData]?.state.data, (0, _classPrivateFieldLooseBase.default)(this, _lastQueryWithDefinedData)[_lastQueryWithDefinedData]) : options.placeholderData;
        }
        if (placeholderData !== void 0) {
          status = "success";
          data = (0, _utilsJs.replaceData)(prevResult?.data, placeholderData, options);
          isPlaceholderData = true;
        }
      }
      if (options.select && data !== void 0 && !skipSelect) {
        if (prevResult && data === prevResultState?.data && options.select === (0, _classPrivateFieldLooseBase.default)(this, _selectFn)[_selectFn]) {
          data = (0, _classPrivateFieldLooseBase.default)(this, _selectResult)[_selectResult];
        } else {
          try {
            (0, _classPrivateFieldLooseBase.default)(this, _selectFn)[_selectFn] = options.select;
            data = options.select(data);
            data = (0, _utilsJs.replaceData)(prevResult?.data, data, options);
            (0, _classPrivateFieldLooseBase.default)(this, _selectResult)[_selectResult] = data;
            (0, _classPrivateFieldLooseBase.default)(this, _selectError)[_selectError] = null;
          } catch (selectError) {
            (0, _classPrivateFieldLooseBase.default)(this, _selectError)[_selectError] = selectError;
          }
        }
      }
      if ((0, _classPrivateFieldLooseBase.default)(this, _selectError)[_selectError]) {
        error = (0, _classPrivateFieldLooseBase.default)(this, _selectError)[_selectError];
        data = (0, _classPrivateFieldLooseBase.default)(this, _selectResult)[_selectResult];
        errorUpdatedAt = Date.now();
        status = "error";
      }
      const isFetching = newState.fetchStatus === "fetching";
      const isPending = status === "pending";
      const isError = status === "error";
      const isLoading = isPending && isFetching;
      const hasData = data !== void 0;
      const result = {
        status,
        fetchStatus: newState.fetchStatus,
        isPending,
        isSuccess: status === "success",
        isError,
        isInitialLoading: isLoading,
        isLoading,
        data,
        dataUpdatedAt: newState.dataUpdatedAt,
        error,
        errorUpdatedAt,
        failureCount: newState.fetchFailureCount,
        failureReason: newState.fetchFailureReason,
        errorUpdateCount: newState.errorUpdateCount,
        isFetched: query.isFetched(),
        isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
        isFetching,
        isRefetching: isFetching && !isPending,
        isLoadingError: isError && !hasData,
        isPaused: newState.fetchStatus === "paused",
        isPlaceholderData,
        isRefetchError: isError && hasData,
        isStale: isStale(query, options),
        refetch: this.refetch,
        promise: (0, _classPrivateFieldLooseBase.default)(this, _currentThenable)[_currentThenable],
        isEnabled: (0, _utilsJs.resolveQueryBoolean)(options.enabled, query) !== false
      };
      const nextResult = result;
      if (this.options.experimental_prefetchInRender) {
        const hasResultData = nextResult.data !== void 0;
        const isErrorWithoutData = nextResult.status === "error" && !hasResultData;
        const finalizeThenableIfPossible = thenable => {
          if (isErrorWithoutData) {
            thenable.reject(nextResult.error);
          } else if (hasResultData) {
            thenable.resolve(nextResult.data);
          }
        };
        const recreateThenable = () => {
          const pending = (0, _classPrivateFieldLooseBase.default)(this, _currentThenable)[_currentThenable] = nextResult.promise = (0, _thenableJs.pendingThenable)();
          finalizeThenableIfPossible(pending);
        };
        const prevThenable = (0, _classPrivateFieldLooseBase.default)(this, _currentThenable)[_currentThenable];
        switch (prevThenable.status) {
          case "pending":
            if (query.queryHash === prevQuery.queryHash) {
              finalizeThenableIfPossible(prevThenable);
            }
            break;
          case "fulfilled":
            if (isErrorWithoutData || nextResult.data !== prevThenable.value) {
              recreateThenable();
            }
            break;
          case "rejected":
            if (!isErrorWithoutData || nextResult.error !== prevThenable.reason) {
              recreateThenable();
            }
            break;
        }
      }
      return nextResult;
    }
    updateResult() {
      const prevResult = (0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult];
      const nextResult = this.createResult((0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery], this.options);
      (0, _classPrivateFieldLooseBase.default)(this, _currentResultState)[_currentResultState] = (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery].state;
      (0, _classPrivateFieldLooseBase.default)(this, _currentResultOptions)[_currentResultOptions] = this.options;
      if ((0, _classPrivateFieldLooseBase.default)(this, _currentResultState)[_currentResultState].data !== void 0) {
        (0, _classPrivateFieldLooseBase.default)(this, _lastQueryWithDefinedData)[_lastQueryWithDefinedData] = (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery];
      }
      if ((0, _utilsJs.shallowEqualObjects)(nextResult, prevResult)) {
        return;
      }
      (0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult] = nextResult;
      const shouldNotifyListeners = () => {
        if (!prevResult) {
          return true;
        }
        const {
          notifyOnChangeProps
        } = this.options;
        const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
        if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !(0, _classPrivateFieldLooseBase.default)(this, _trackedProps)[_trackedProps].size) {
          return true;
        }
        const includedProps = new Set(notifyOnChangePropsValue ?? (0, _classPrivateFieldLooseBase.default)(this, _trackedProps)[_trackedProps]);
        if (this.options.throwOnError) {
          includedProps.add("error");
        }
        return Object.keys((0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult]).some(key => {
          const typedKey = key;
          const changed = (0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult][typedKey] !== prevResult[typedKey];
          return changed && includedProps.has(typedKey);
        });
      };
      (0, _classPrivateFieldLooseBase.default)(this, _notify)[_notify]({
        listeners: shouldNotifyListeners()
      });
    }
    onQueryUpdate() {
      this.updateResult();
      if (this.hasListeners()) {
        (0, _classPrivateFieldLooseBase.default)(this, _updateTimers)[_updateTimers]();
      }
    }
  });
  function _executeFetch2(fetchOptions) {
    (0, _classPrivateFieldLooseBase.default)(this, _updateQuery)[_updateQuery]();
    let promise = (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery].fetch(this.options, fetchOptions);
    if (!fetchOptions?.throwOnError) {
      promise = promise.catch(_utilsJs.noop);
    }
    return promise;
  }
  function _updateStaleTimeout2() {
    (0, _classPrivateFieldLooseBase.default)(this, _clearStaleTimeout)[_clearStaleTimeout]();
    const staleTime = (0, _utilsJs.resolveStaleTime)(this.options.staleTime, (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery]);
    if (_environmentManagerJs.environmentManager.isServer() || (0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult].isStale || !(0, _utilsJs.isValidTimeout)(staleTime)) {
      return;
    }
    const time = (0, _utilsJs.timeUntilStale)((0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult].dataUpdatedAt, staleTime);
    const timeout = time + 1;
    (0, _classPrivateFieldLooseBase.default)(this, _staleTimeoutId)[_staleTimeoutId] = _timeoutManagerJs.timeoutManager.setTimeout(() => {
      if (!(0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult].isStale) {
        this.updateResult();
      }
    }, timeout);
  }
  function _computeRefetchInterval2() {
    return (typeof this.options.refetchInterval === "function" ? this.options.refetchInterval((0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery]) : this.options.refetchInterval) ?? false;
  }
  function _updateRefetchInterval2(nextInterval) {
    (0, _classPrivateFieldLooseBase.default)(this, _clearRefetchInterval)[_clearRefetchInterval]();
    (0, _classPrivateFieldLooseBase.default)(this, _currentRefetchInterval)[_currentRefetchInterval] = nextInterval;
    if (_environmentManagerJs.environmentManager.isServer() || (0, _utilsJs.resolveQueryBoolean)(this.options.enabled, (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery]) === false || !(0, _utilsJs.isValidTimeout)((0, _classPrivateFieldLooseBase.default)(this, _currentRefetchInterval)[_currentRefetchInterval]) || (0, _classPrivateFieldLooseBase.default)(this, _currentRefetchInterval)[_currentRefetchInterval] === 0) {
      return;
    }
    (0, _classPrivateFieldLooseBase.default)(this, _refetchIntervalId)[_refetchIntervalId] = _timeoutManagerJs.timeoutManager.setInterval(() => {
      if (this.options.refetchIntervalInBackground || _focusManagerJs.focusManager.isFocused()) {
        (0, _classPrivateFieldLooseBase.default)(this, _executeFetch)[_executeFetch]();
      }
    }, (0, _classPrivateFieldLooseBase.default)(this, _currentRefetchInterval)[_currentRefetchInterval]);
  }
  function _updateTimers2() {
    (0, _classPrivateFieldLooseBase.default)(this, _updateStaleTimeout)[_updateStaleTimeout]();
    (0, _classPrivateFieldLooseBase.default)(this, _updateRefetchInterval)[_updateRefetchInterval]((0, _classPrivateFieldLooseBase.default)(this, _computeRefetchInterval)[_computeRefetchInterval]());
  }
  function _clearStaleTimeout2() {
    if ((0, _classPrivateFieldLooseBase.default)(this, _staleTimeoutId)[_staleTimeoutId] !== void 0) {
      _timeoutManagerJs.timeoutManager.clearTimeout((0, _classPrivateFieldLooseBase.default)(this, _staleTimeoutId)[_staleTimeoutId]);
      (0, _classPrivateFieldLooseBase.default)(this, _staleTimeoutId)[_staleTimeoutId] = void 0;
    }
  }
  function _clearRefetchInterval2() {
    if ((0, _classPrivateFieldLooseBase.default)(this, _refetchIntervalId)[_refetchIntervalId] !== void 0) {
      _timeoutManagerJs.timeoutManager.clearInterval((0, _classPrivateFieldLooseBase.default)(this, _refetchIntervalId)[_refetchIntervalId]);
      (0, _classPrivateFieldLooseBase.default)(this, _refetchIntervalId)[_refetchIntervalId] = void 0;
    }
  }
  function _updateQuery2() {
    const query = (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].getQueryCache().build((0, _classPrivateFieldLooseBase.default)(this, _client)[_client], this.options);
    if (query === (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery]) {
      return;
    }
    const prevQuery = (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery];
    (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery] = query;
    (0, _classPrivateFieldLooseBase.default)(this, _currentQueryInitialState)[_currentQueryInitialState] = query.state;
    if (this.hasListeners()) {
      prevQuery?.removeObserver(this);
      query.addObserver(this);
    }
  }
  function _notify2(notifyOptions) {
    _notifyManagerJs.notifyManager.batch(() => {
      if (notifyOptions.listeners) {
        this.listeners.forEach(listener => {
          listener((0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult]);
        });
      }
      (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].getQueryCache().notify({
        query: (0, _classPrivateFieldLooseBase.default)(this, _currentQuery)[_currentQuery],
        type: "observerResultsUpdated"
      });
    });
  }
  function shouldLoadOnMount(query, options) {
    return (0, _utilsJs.resolveQueryBoolean)(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && (0, _utilsJs.resolveQueryBoolean)(options.retryOnMount, query) === false);
  }
  function shouldFetchOnMount(query, options) {
    return shouldLoadOnMount(query, options) || query.state.data !== void 0 && shouldFetchOn(query, options, options.refetchOnMount);
  }
  function shouldFetchOn(query, options, field) {
    if ((0, _utilsJs.resolveQueryBoolean)(options.enabled, query) !== false && (0, _utilsJs.resolveStaleTime)(options.staleTime, query) !== "static") {
      const value = typeof field === "function" ? field(query) : field;
      return value === "always" || value !== false && isStale(query, options);
    }
    return false;
  }
  function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
    return (query !== prevQuery || (0, _utilsJs.resolveQueryBoolean)(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale(query, options);
  }
  function isStale(query, options) {
    return (0, _utilsJs.resolveQueryBoolean)(options.enabled, query) !== false && query.isStaleByTime((0, _utilsJs.resolveStaleTime)(options.staleTime, query));
  }
  function shouldAssignObserverCurrentProperties(observer, optimisticResult) {
    if (!(0, _utilsJs.shallowEqualObjects)(observer.getCurrentResult(), optimisticResult)) {
      return true;
    }
    return false;
  }
},1295,[1296,1297,1287,1289,1298,1299,1288,1293,1290,1291],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/queryObserver.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  function _classPrivateFieldBase(e, t) {
    if (!{}.hasOwnProperty.call(e, t)) throw new TypeError("attempted to use private field on non-instance");
    return e;
  }
  module.exports = _classPrivateFieldBase, module.exports.__esModule = true, module.exports["default"] = module.exports;
},1296,[],"node_modules/.pnpm/@babel+runtime@7.29.2/node_modules/@babel/runtime/helpers/classPrivateFieldLooseBase.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  var id = 0;
  function _classPrivateFieldKey(e) {
    return "__private_" + id++ + "_" + e;
  }
  module.exports = _classPrivateFieldKey, module.exports.__esModule = true, module.exports["default"] = module.exports;
},1297,[],"node_modules/.pnpm/@babel+runtime@7.29.2/node_modules/@babel/runtime/helpers/classPrivateFieldLooseKey.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "createNotifyManager", {
    enumerable: true,
    get: function () {
      return createNotifyManager;
    }
  });
  Object.defineProperty(exports, "defaultScheduler", {
    enumerable: true,
    get: function () {
      return defaultScheduler;
    }
  });
  Object.defineProperty(exports, "notifyManager", {
    enumerable: true,
    get: function () {
      return notifyManager;
    }
  });
  var _timeoutManagerJs = require(_dependencyMap[0], "./timeoutManager.js");
  // src/notifyManager.ts

  var defaultScheduler = _timeoutManagerJs.systemSetTimeoutZero;
  function createNotifyManager() {
    let queue = [];
    let transactions = 0;
    let notifyFn = callback => {
      callback();
    };
    let batchNotifyFn = callback => {
      callback();
    };
    let scheduleFn = defaultScheduler;
    const schedule = callback => {
      if (transactions) {
        queue.push(callback);
      } else {
        scheduleFn(() => {
          notifyFn(callback);
        });
      }
    };
    const flush = () => {
      const originalQueue = queue;
      queue = [];
      if (originalQueue.length) {
        scheduleFn(() => {
          batchNotifyFn(() => {
            originalQueue.forEach(callback => {
              notifyFn(callback);
            });
          });
        });
      }
    };
    return {
      batch: callback => {
        let result;
        transactions++;
        try {
          result = callback();
        } finally {
          transactions--;
          if (!transactions) {
            flush();
          }
        }
        return result;
      },
      /**
       * All calls to the wrapped function will be batched.
       */
      batchCalls: callback => {
        return (...args) => {
          schedule(() => {
            callback(...args);
          });
        };
      },
      schedule,
      /**
       * Use this method to set a custom notify function.
       * This can be used to for example wrap notifications with `React.act` while running tests.
       */
      setNotifyFunction: fn => {
        notifyFn = fn;
      },
      /**
       * Use this method to set a custom function to batch notifications together into a single tick.
       * By default React Query will use the batch function provided by ReactDOM or React Native.
       */
      setBatchNotifyFunction: fn => {
        batchNotifyFn = fn;
      },
      setScheduler: fn => {
        scheduleFn = fn;
      }
    };
  }
  var notifyManager = createNotifyManager();
},1298,[1291],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/notifyManager.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var _queryType, _initialState, _revertState, _cache, _client, _retryer, _defaultOptions, _abortSignalConsumed, _isInitialPausedFetch, _dispatch; // src/query.ts
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "Query", {
    enumerable: true,
    get: function () {
      return Query;
    }
  });
  Object.defineProperty(exports, "fetchState", {
    enumerable: true,
    get: function () {
      return fetchState;
    }
  });
  var _babelRuntimeHelpersClassPrivateFieldLooseBase = require(_dependencyMap[0], "@babel/runtime/helpers/classPrivateFieldLooseBase");
  var _classPrivateFieldLooseBase = _interopDefault(_babelRuntimeHelpersClassPrivateFieldLooseBase);
  var _babelRuntimeHelpersClassPrivateFieldLooseKey = require(_dependencyMap[1], "@babel/runtime/helpers/classPrivateFieldLooseKey");
  var _classPrivateFieldLooseKey = _interopDefault(_babelRuntimeHelpersClassPrivateFieldLooseKey);
  var _utilsJs = require(_dependencyMap[2], "./utils.js");
  var _notifyManagerJs = require(_dependencyMap[3], "./notifyManager.js");
  var _retryerJs = require(_dependencyMap[4], "./retryer.js");
  var _removableJs = require(_dependencyMap[5], "./removable.js");
  var _infiniteQueryBehaviorJs = require(_dependencyMap[6], "./infiniteQueryBehavior.js");
  var Query = (_queryType = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("queryType"), _initialState = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("initialState"), _revertState = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("revertState"), _cache = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("cache"), _client = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("client"), _retryer = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("retryer"), _defaultOptions = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("defaultOptions"), _abortSignalConsumed = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("abortSignalConsumed"), _isInitialPausedFetch = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("isInitialPausedFetch"), _dispatch = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("dispatch"), class Query extends _removableJs.Removable {
    constructor(config) {
      super();
      Object.defineProperty(this, _dispatch, {
        value: _dispatch2
      });
      Object.defineProperty(this, _isInitialPausedFetch, {
        value: _isInitialPausedFetch2
      });
      Object.defineProperty(this, _queryType, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _initialState, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _revertState, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _cache, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _client, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _retryer, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _defaultOptions, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _abortSignalConsumed, {
        writable: true,
        value: void 0
      });
      (0, _classPrivateFieldLooseBase.default)(this, _abortSignalConsumed)[_abortSignalConsumed] = false;
      (0, _classPrivateFieldLooseBase.default)(this, _defaultOptions)[_defaultOptions] = config.defaultOptions;
      this.setOptions(config.options);
      this.observers = [];
      (0, _classPrivateFieldLooseBase.default)(this, _client)[_client] = config.client;
      (0, _classPrivateFieldLooseBase.default)(this, _cache)[_cache] = (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].getQueryCache();
      this.queryKey = config.queryKey;
      this.queryHash = config.queryHash;
      (0, _classPrivateFieldLooseBase.default)(this, _initialState)[_initialState] = getDefaultState(this.options);
      this.state = config.state ?? (0, _classPrivateFieldLooseBase.default)(this, _initialState)[_initialState];
      this.scheduleGc();
    }
    get meta() {
      return this.options.meta;
    }
    get queryType() {
      return (0, _classPrivateFieldLooseBase.default)(this, _queryType)[_queryType];
    }
    get promise() {
      return (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer]?.promise;
    }
    setOptions(options) {
      this.options = {
        ...(0, _classPrivateFieldLooseBase.default)(this, _defaultOptions)[_defaultOptions],
        ...options
      };
      if (options?._type) {
        (0, _classPrivateFieldLooseBase.default)(this, _queryType)[_queryType] = options._type;
      }
      this.updateGcTime(this.options.gcTime);
      if (this.state && this.state.data === void 0) {
        const defaultState = getDefaultState(this.options);
        if (defaultState.data !== void 0) {
          this.setState(successState(defaultState.data, defaultState.dataUpdatedAt));
          (0, _classPrivateFieldLooseBase.default)(this, _initialState)[_initialState] = defaultState;
        }
      }
    }
    optionalRemove() {
      if (!this.observers.length && this.state.fetchStatus === "idle") {
        (0, _classPrivateFieldLooseBase.default)(this, _cache)[_cache].remove(this);
      }
    }
    setData(newData, options) {
      const data = (0, _utilsJs.replaceData)(this.state.data, newData, this.options);
      (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
        data,
        type: "success",
        dataUpdatedAt: options?.updatedAt,
        manual: options?.manual
      });
      return data;
    }
    setState(state) {
      (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
        type: "setState",
        state
      });
    }
    cancel(options) {
      const promise = (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer]?.promise;
      (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer]?.cancel(options);
      return promise ? promise.then(_utilsJs.noop).catch(_utilsJs.noop) : Promise.resolve();
    }
    destroy() {
      super.destroy();
      this.cancel({
        silent: true
      });
    }
    get resetState() {
      return (0, _classPrivateFieldLooseBase.default)(this, _initialState)[_initialState];
    }
    reset() {
      this.destroy();
      this.setState(this.resetState);
    }
    isActive() {
      return this.observers.some(observer => (0, _utilsJs.resolveQueryBoolean)(observer.options.enabled, this) !== false);
    }
    isDisabled() {
      if (this.getObserversCount() > 0) {
        return !this.isActive();
      }
      return this.options.queryFn === _utilsJs.skipToken || !this.isFetched();
    }
    isFetched() {
      return this.state.dataUpdateCount + this.state.errorUpdateCount > 0;
    }
    isStatic() {
      if (this.getObserversCount() > 0) {
        return this.observers.some(observer => (0, _utilsJs.resolveStaleTime)(observer.options.staleTime, this) === "static");
      }
      return false;
    }
    isStale() {
      if (this.getObserversCount() > 0) {
        return this.observers.some(observer => observer.getCurrentResult().isStale);
      }
      return this.state.data === void 0 || this.state.isInvalidated;
    }
    isStaleByTime(staleTime = 0) {
      if (this.state.data === void 0) {
        return true;
      }
      if (staleTime === "static") {
        return false;
      }
      if (this.state.isInvalidated) {
        return true;
      }
      return !(0, _utilsJs.timeUntilStale)(this.state.dataUpdatedAt, staleTime);
    }
    onFocus() {
      const observer = this.observers.find(x => x.shouldFetchOnWindowFocus());
      observer?.refetch({
        cancelRefetch: false
      });
      (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer]?.continue();
    }
    onOnline() {
      const observer = this.observers.find(x => x.shouldFetchOnReconnect());
      observer?.refetch({
        cancelRefetch: false
      });
      (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer]?.continue();
    }
    addObserver(observer) {
      if (!this.observers.includes(observer)) {
        this.observers.push(observer);
        this.clearGcTimeout();
        (0, _classPrivateFieldLooseBase.default)(this, _cache)[_cache].notify({
          type: "observerAdded",
          query: this,
          observer
        });
      }
    }
    removeObserver(observer) {
      if (this.observers.includes(observer)) {
        this.observers = this.observers.filter(x => x !== observer);
        if (!this.observers.length) {
          if ((0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer]) {
            if ((0, _classPrivateFieldLooseBase.default)(this, _abortSignalConsumed)[_abortSignalConsumed] || (0, _classPrivateFieldLooseBase.default)(this, _isInitialPausedFetch)[_isInitialPausedFetch]()) {
              (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer].cancel({
                revert: true
              });
            } else {
              (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer].cancelRetry();
            }
          }
          this.scheduleGc();
        }
        (0, _classPrivateFieldLooseBase.default)(this, _cache)[_cache].notify({
          type: "observerRemoved",
          query: this,
          observer
        });
      }
    }
    getObserversCount() {
      return this.observers.length;
    }
    invalidate() {
      if (!this.state.isInvalidated) {
        (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
          type: "invalidate"
        });
      }
    }
    async fetch(options, fetchOptions) {
      if (this.state.fetchStatus !== "idle" &&
      // If the promise in the retryer is already rejected, we have to definitely
      // re-start the fetch; there is a chance that the query is still in a
      // pending state when that happens
      (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer]?.status() !== "rejected") {
        if (this.state.data !== void 0 && fetchOptions?.cancelRefetch) {
          this.cancel({
            silent: true
          });
        } else if ((0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer]) {
          (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer].continueRetry();
          return (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer].promise;
        }
      }
      if (options) {
        this.setOptions(options);
      }
      if (!this.options.queryFn) {
        const observer = this.observers.find(x => x.options.queryFn);
        if (observer) {
          this.setOptions(observer.options);
        }
      }
      if (process.env.NODE_ENV !== "production") {
        if (!Array.isArray(this.options.queryKey)) {
          console.error(`As of v4, queryKey needs to be an Array. If you are using a string like 'repoData', please change it to an Array, e.g. ['repoData']`);
        }
      }
      const abortController = new AbortController();
      const addSignalProperty = object => {
        Object.defineProperty(object, "signal", {
          enumerable: true,
          get: () => {
            (0, _classPrivateFieldLooseBase.default)(this, _abortSignalConsumed)[_abortSignalConsumed] = true;
            return abortController.signal;
          }
        });
      };
      const fetchFn = () => {
        const queryFn = (0, _utilsJs.ensureQueryFn)(this.options, fetchOptions);
        const createQueryFnContext = () => {
          const queryFnContext2 = {
            client: (0, _classPrivateFieldLooseBase.default)(this, _client)[_client],
            queryKey: this.queryKey,
            meta: this.meta
          };
          addSignalProperty(queryFnContext2);
          return queryFnContext2;
        };
        const queryFnContext = createQueryFnContext();
        (0, _classPrivateFieldLooseBase.default)(this, _abortSignalConsumed)[_abortSignalConsumed] = false;
        if (this.options.persister) {
          return this.options.persister(queryFn, queryFnContext, this);
        }
        return queryFn(queryFnContext);
      };
      const createFetchContext = () => {
        const context2 = {
          fetchOptions,
          options: this.options,
          queryKey: this.queryKey,
          client: (0, _classPrivateFieldLooseBase.default)(this, _client)[_client],
          state: this.state,
          fetchFn
        };
        addSignalProperty(context2);
        return context2;
      };
      const context = createFetchContext();
      const behavior = (0, _classPrivateFieldLooseBase.default)(this, _queryType)[_queryType] === "infinite" ? (0, _infiniteQueryBehaviorJs.infiniteQueryBehavior)(this.options.pages) : this.options.behavior;
      behavior?.onFetch(context, this);
      (0, _classPrivateFieldLooseBase.default)(this, _revertState)[_revertState] = this.state;
      if (this.state.fetchStatus === "idle" || this.state.fetchMeta !== context.fetchOptions?.meta) {
        (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
          type: "fetch",
          meta: context.fetchOptions?.meta
        });
      }
      (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer] = (0, _retryerJs.createRetryer)({
        initialPromise: fetchOptions?.initialPromise,
        fn: context.fetchFn,
        onCancel: error => {
          if (error instanceof _retryerJs.CancelledError && error.revert) {
            this.setState({
              ...(0, _classPrivateFieldLooseBase.default)(this, _revertState)[_revertState],
              fetchStatus: "idle"
            });
          }
          abortController.abort();
        },
        onFail: (failureCount, error) => {
          (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
            type: "failed",
            failureCount,
            error
          });
        },
        onPause: () => {
          (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
            type: "pause"
          });
        },
        onContinue: () => {
          (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
            type: "continue"
          });
        },
        retry: context.options.retry,
        retryDelay: context.options.retryDelay,
        networkMode: context.options.networkMode,
        canRun: () => true
      });
      try {
        const data = await (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer].start();
        if (data === void 0) {
          if (process.env.NODE_ENV !== "production") {
            console.error(`Query data cannot be undefined. Please make sure to return a value other than undefined from your query function. Affected query key: ${this.queryHash}`);
          }
          throw new Error(`${this.queryHash} data is undefined`);
        }
        this.setData(data);
        (0, _classPrivateFieldLooseBase.default)(this, _cache)[_cache].config.onSuccess?.(data, this);
        (0, _classPrivateFieldLooseBase.default)(this, _cache)[_cache].config.onSettled?.(data, this.state.error, this);
        return data;
      } catch (error) {
        if (error instanceof _retryerJs.CancelledError) {
          if (error.silent) {
            return (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer].promise;
          } else if (error.revert) {
            if (this.state.data === void 0) {
              throw error;
            }
            return this.state.data;
          }
        }
        (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
          type: "error",
          error
        });
        (0, _classPrivateFieldLooseBase.default)(this, _cache)[_cache].config.onError?.(error, this);
        (0, _classPrivateFieldLooseBase.default)(this, _cache)[_cache].config.onSettled?.(this.state.data, error, this);
        throw error;
      } finally {
        this.scheduleGc();
      }
    }
  });
  function _isInitialPausedFetch2() {
    return this.state.fetchStatus === "paused" && this.state.status === "pending";
  }
  function _dispatch2(action) {
    const reducer = state => {
      switch (action.type) {
        case "failed":
          return {
            ...state,
            fetchFailureCount: action.failureCount,
            fetchFailureReason: action.error
          };
        case "pause":
          return {
            ...state,
            fetchStatus: "paused"
          };
        case "continue":
          return {
            ...state,
            fetchStatus: "fetching"
          };
        case "fetch":
          return {
            ...state,
            ...fetchState(state.data, this.options),
            fetchMeta: action.meta ?? null
          };
        case "success":
          const newState = {
            ...state,
            ...successState(action.data, action.dataUpdatedAt),
            dataUpdateCount: state.dataUpdateCount + 1,
            ...(!action.manual && {
              fetchStatus: "idle",
              fetchFailureCount: 0,
              fetchFailureReason: null
            })
          };
          (0, _classPrivateFieldLooseBase.default)(this, _revertState)[_revertState] = action.manual ? newState : void 0;
          return newState;
        case "error":
          const error = action.error;
          return {
            ...state,
            error,
            errorUpdateCount: state.errorUpdateCount + 1,
            errorUpdatedAt: Date.now(),
            fetchFailureCount: state.fetchFailureCount + 1,
            fetchFailureReason: error,
            fetchStatus: "idle",
            status: "error",
            // flag existing data as invalidated if we get a background error
            // note that "no data" always means stale so we can set unconditionally here
            isInvalidated: true
          };
        case "invalidate":
          return {
            ...state,
            isInvalidated: true
          };
        case "setState":
          return {
            ...state,
            ...action.state
          };
      }
    };
    this.state = reducer(this.state);
    _notifyManagerJs.notifyManager.batch(() => {
      this.observers.forEach(observer => {
        observer.onQueryUpdate();
      });
      (0, _classPrivateFieldLooseBase.default)(this, _cache)[_cache].notify({
        query: this,
        type: "updated",
        action
      });
    });
  }
  function fetchState(data, options) {
    return {
      fetchFailureCount: 0,
      fetchFailureReason: null,
      fetchStatus: (0, _retryerJs.canFetch)(options.networkMode) ? "fetching" : "paused",
      ...(data === void 0 && {
        error: null,
        status: "pending"
      })
    };
  }
  function successState(data, dataUpdatedAt) {
    return {
      data,
      dataUpdatedAt: dataUpdatedAt ?? Date.now(),
      error: null,
      isInvalidated: false,
      status: "success"
    };
  }
  function getDefaultState(options) {
    const data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
    const hasData = data !== void 0;
    const initialDataUpdatedAt = hasData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
    return {
      data,
      dataUpdateCount: 0,
      dataUpdatedAt: hasData ? initialDataUpdatedAt ?? Date.now() : 0,
      error: null,
      errorUpdateCount: 0,
      errorUpdatedAt: 0,
      fetchFailureCount: 0,
      fetchFailureReason: null,
      fetchMeta: null,
      isInvalidated: false,
      status: hasData ? "success" : "pending",
      fetchStatus: "idle"
    };
  }
},1299,[1296,1297,1290,1298,1300,1302,1303],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/query.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "CancelledError", {
    enumerable: true,
    get: function () {
      return CancelledError;
    }
  });
  Object.defineProperty(exports, "canFetch", {
    enumerable: true,
    get: function () {
      return canFetch;
    }
  });
  Object.defineProperty(exports, "createRetryer", {
    enumerable: true,
    get: function () {
      return createRetryer;
    }
  });
  Object.defineProperty(exports, "isCancelledError", {
    enumerable: true,
    get: function () {
      return isCancelledError;
    }
  });
  var _focusManagerJs = require(_dependencyMap[0], "./focusManager.js");
  var _onlineManagerJs = require(_dependencyMap[1], "./onlineManager.js");
  var _thenableJs = require(_dependencyMap[2], "./thenable.js");
  var _environmentManagerJs = require(_dependencyMap[3], "./environmentManager.js");
  var _utilsJs = require(_dependencyMap[4], "./utils.js");
  // src/retryer.ts

  function defaultRetryDelay(failureCount) {
    return Math.min(1e3 * 2 ** failureCount, 3e4);
  }
  function canFetch(networkMode) {
    return (networkMode ?? "online") === "online" ? _onlineManagerJs.onlineManager.isOnline() : true;
  }
  var CancelledError = class extends Error {
    constructor(options) {
      super("CancelledError");
      this.revert = options?.revert;
      this.silent = options?.silent;
    }
  };
  function isCancelledError(value) {
    return value instanceof CancelledError;
  }
  function createRetryer(config) {
    let isRetryCancelled = false;
    let failureCount = 0;
    let continueFn;
    const thenable = (0, _thenableJs.pendingThenable)();
    const isResolved = () => thenable.status !== "pending";
    const cancel = cancelOptions => {
      if (!isResolved()) {
        const error = new CancelledError(cancelOptions);
        reject(error);
        config.onCancel?.(error);
      }
    };
    const cancelRetry = () => {
      isRetryCancelled = true;
    };
    const continueRetry = () => {
      isRetryCancelled = false;
    };
    const canContinue = () => _focusManagerJs.focusManager.isFocused() && (config.networkMode === "always" || _onlineManagerJs.onlineManager.isOnline()) && config.canRun();
    const canStart = () => canFetch(config.networkMode) && config.canRun();
    const resolve = value => {
      if (!isResolved()) {
        continueFn?.();
        thenable.resolve(value);
      }
    };
    const reject = value => {
      if (!isResolved()) {
        continueFn?.();
        thenable.reject(value);
      }
    };
    const pause = () => {
      return new Promise(continueResolve => {
        continueFn = value => {
          if (isResolved() || canContinue()) {
            continueResolve(value);
          }
        };
        config.onPause?.();
      }).then(() => {
        continueFn = void 0;
        if (!isResolved()) {
          config.onContinue?.();
        }
      });
    };
    const run = () => {
      if (isResolved()) {
        return;
      }
      let promiseOrValue;
      const initialPromise = failureCount === 0 ? config.initialPromise : void 0;
      try {
        promiseOrValue = initialPromise ?? config.fn();
      } catch (error) {
        promiseOrValue = Promise.reject(error);
      }
      Promise.resolve(promiseOrValue).then(resolve).catch(error => {
        if (isResolved()) {
          return;
        }
        const retry = config.retry ?? (_environmentManagerJs.environmentManager.isServer() ? 0 : 3);
        const retryDelay = config.retryDelay ?? defaultRetryDelay;
        const delay = typeof retryDelay === "function" ? retryDelay(failureCount, error) : retryDelay;
        const shouldRetry = retry === true || typeof retry === "number" && failureCount < retry || typeof retry === "function" && retry(failureCount, error);
        if (isRetryCancelled || !shouldRetry) {
          reject(error);
          return;
        }
        failureCount++;
        config.onFail?.(failureCount, error);
        (0, _utilsJs.sleep)(delay).then(() => {
          return canContinue() ? void 0 : pause();
        }).then(() => {
          if (isRetryCancelled) {
            reject(error);
          } else {
            run();
          }
        });
      });
    };
    return {
      promise: thenable,
      status: () => thenable.status,
      cancel,
      continue: () => {
        continueFn?.();
        return thenable;
      },
      cancelRetry,
      continueRetry,
      canStart,
      start: () => {
        if (canStart()) {
          run();
        } else {
          pause().then(run);
        }
        return thenable;
      }
    };
  }
},1300,[1287,1301,1293,1289,1290],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/retryer.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "OnlineManager", {
    enumerable: true,
    get: function () {
      return OnlineManager;
    }
  });
  Object.defineProperty(exports, "onlineManager", {
    enumerable: true,
    get: function () {
      return onlineManager;
    }
  });
  var _subscribableJs = require(_dependencyMap[0], "./subscribable.js");
  // src/onlineManager.ts

  var OnlineManager = class extends _subscribableJs.Subscribable {
    #online = true;
    #cleanup;
    #setup;
    constructor() {
      super();
      this.#setup = onOnline => {
        if (typeof window !== "undefined" && window.addEventListener) {
          const onlineListener = () => onOnline(true);
          const offlineListener = () => onOnline(false);
          window.addEventListener("online", onlineListener, false);
          window.addEventListener("offline", offlineListener, false);
          return () => {
            window.removeEventListener("online", onlineListener);
            window.removeEventListener("offline", offlineListener);
          };
        }
        return;
      };
    }
    onSubscribe() {
      if (!this.#cleanup) {
        this.setEventListener(this.#setup);
      }
    }
    onUnsubscribe() {
      if (!this.hasListeners()) {
        this.#cleanup?.();
        this.#cleanup = void 0;
      }
    }
    setEventListener(setup) {
      this.#setup = setup;
      this.#cleanup?.();
      this.#cleanup = setup(this.setOnline.bind(this));
    }
    setOnline(online) {
      const changed = this.#online !== online;
      if (changed) {
        this.#online = online;
        this.listeners.forEach(listener => {
          listener(online);
        });
      }
    }
    isOnline() {
      return this.#online;
    }
  };
  var onlineManager = new OnlineManager();
},1301,[1288],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/onlineManager.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "Removable", {
    enumerable: true,
    get: function () {
      return Removable;
    }
  });
  var _timeoutManagerJs = require(_dependencyMap[0], "./timeoutManager.js");
  var _environmentManagerJs = require(_dependencyMap[1], "./environmentManager.js");
  var _utilsJs = require(_dependencyMap[2], "./utils.js");
  // src/removable.ts

  var Removable = class {
    #gcTimeout;
    destroy() {
      this.clearGcTimeout();
    }
    scheduleGc() {
      this.clearGcTimeout();
      if ((0, _utilsJs.isValidTimeout)(this.gcTime)) {
        this.#gcTimeout = _timeoutManagerJs.timeoutManager.setTimeout(() => {
          this.optionalRemove();
        }, this.gcTime);
      }
    }
    updateGcTime(newGcTime) {
      this.gcTime = Math.max(this.gcTime || 0, newGcTime ?? (_environmentManagerJs.environmentManager.isServer() ? Infinity : 5 * 60 * 1e3));
    }
    clearGcTimeout() {
      if (this.#gcTimeout !== void 0) {
        _timeoutManagerJs.timeoutManager.clearTimeout(this.#gcTimeout);
        this.#gcTimeout = void 0;
      }
    }
  };
},1302,[1291,1289,1290],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/removable.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "hasNextPage", {
    enumerable: true,
    get: function () {
      return hasNextPage;
    }
  });
  Object.defineProperty(exports, "hasPreviousPage", {
    enumerable: true,
    get: function () {
      return hasPreviousPage;
    }
  });
  Object.defineProperty(exports, "infiniteQueryBehavior", {
    enumerable: true,
    get: function () {
      return infiniteQueryBehavior;
    }
  });
  var _utilsJs = require(_dependencyMap[0], "./utils.js");
  // src/infiniteQueryBehavior.ts

  function infiniteQueryBehavior(pages) {
    return {
      onFetch: (context, query) => {
        const options = context.options;
        const direction = context.fetchOptions?.meta?.fetchMore?.direction;
        const oldPages = context.state.data?.pages || [];
        const oldPageParams = context.state.data?.pageParams || [];
        let result = {
          pages: [],
          pageParams: []
        };
        let currentPage = 0;
        const fetchFn = async () => {
          let cancelled = false;
          const addSignalProperty = object => {
            (0, _utilsJs.addConsumeAwareSignal)(object, () => context.signal, () => cancelled = true);
          };
          const queryFn = (0, _utilsJs.ensureQueryFn)(context.options, context.fetchOptions);
          const fetchPage = async (data, param, previous) => {
            if (cancelled) {
              return Promise.reject(context.signal.reason);
            }
            if (param == null && data.pages.length) {
              return Promise.resolve(data);
            }
            const createQueryFnContext = () => {
              const queryFnContext2 = {
                client: context.client,
                queryKey: context.queryKey,
                pageParam: param,
                direction: previous ? "backward" : "forward",
                meta: context.options.meta
              };
              addSignalProperty(queryFnContext2);
              return queryFnContext2;
            };
            const queryFnContext = createQueryFnContext();
            const page = await queryFn(queryFnContext);
            const {
              maxPages
            } = context.options;
            const addTo = previous ? _utilsJs.addToStart : _utilsJs.addToEnd;
            return {
              pages: addTo(data.pages, page, maxPages),
              pageParams: addTo(data.pageParams, param, maxPages)
            };
          };
          if (direction && oldPages.length) {
            const previous = direction === "backward";
            const pageParamFn = previous ? getPreviousPageParam : getNextPageParam;
            const oldData = {
              pages: oldPages,
              pageParams: oldPageParams
            };
            const param = pageParamFn(options, oldData);
            result = await fetchPage(oldData, param, previous);
          } else {
            const remainingPages = pages ?? oldPages.length;
            do {
              const param = currentPage === 0 ? oldPageParams[0] ?? options.initialPageParam : getNextPageParam(options, result);
              if (currentPage > 0 && param == null) {
                break;
              }
              result = await fetchPage(result, param);
              currentPage++;
            } while (currentPage < remainingPages);
          }
          return result;
        };
        if (context.options.persister) {
          context.fetchFn = () => {
            return context.options.persister?.(fetchFn, {
              client: context.client,
              queryKey: context.queryKey,
              meta: context.options.meta,
              signal: context.signal
            }, query);
          };
        } else {
          context.fetchFn = fetchFn;
        }
      }
    };
  }
  function getNextPageParam(options, {
    pages,
    pageParams
  }) {
    const lastIndex = pages.length - 1;
    return pages.length > 0 ? options.getNextPageParam(pages[lastIndex], pages, pageParams[lastIndex], pageParams) : void 0;
  }
  function getPreviousPageParam(options, {
    pages,
    pageParams
  }) {
    return pages.length > 0 ? options.getPreviousPageParam?.(pages[0], pages, pageParams[0], pageParams) : void 0;
  }
  function hasNextPage(options, data) {
    if (!data) return false;
    return getNextPageParam(options, data) != null;
  }
  function hasPreviousPage(options, data) {
    if (!data || !options.getPreviousPageParam) return false;
    return getPreviousPageParam(options, data) != null;
  }
},1303,[1290],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "MutationCache", {
    enumerable: true,
    get: function () {
      return MutationCache;
    }
  });
  var _notifyManagerJs = require(_dependencyMap[0], "./notifyManager.js");
  var _mutationJs = require(_dependencyMap[1], "./mutation.js");
  var _utilsJs = require(_dependencyMap[2], "./utils.js");
  var _subscribableJs = require(_dependencyMap[3], "./subscribable.js");
  // src/mutationCache.ts

  var MutationCache = class extends _subscribableJs.Subscribable {
    constructor(config = {}) {
      super();
      this.config = config;
      this.#mutations = /* @__PURE__ */new Set();
      this.#scopes = /* @__PURE__ */new Map();
      this.#mutationId = 0;
    }
    #mutations;
    #scopes;
    #mutationId;
    build(client, options, state) {
      const mutation = new _mutationJs.Mutation({
        client,
        mutationCache: this,
        mutationId: ++this.#mutationId,
        options: client.defaultMutationOptions(options),
        state
      });
      this.add(mutation);
      return mutation;
    }
    add(mutation) {
      this.#mutations.add(mutation);
      const scope = scopeFor(mutation);
      if (typeof scope === "string") {
        const scopedMutations = this.#scopes.get(scope);
        if (scopedMutations) {
          scopedMutations.push(mutation);
        } else {
          this.#scopes.set(scope, [mutation]);
        }
      }
      this.notify({
        type: "added",
        mutation
      });
    }
    remove(mutation) {
      if (this.#mutations.delete(mutation)) {
        const scope = scopeFor(mutation);
        if (typeof scope === "string") {
          const scopedMutations = this.#scopes.get(scope);
          if (scopedMutations) {
            if (scopedMutations.length > 1) {
              const index = scopedMutations.indexOf(mutation);
              if (index !== -1) {
                scopedMutations.splice(index, 1);
              }
            } else if (scopedMutations[0] === mutation) {
              this.#scopes.delete(scope);
            }
          }
        }
      }
      this.notify({
        type: "removed",
        mutation
      });
    }
    canRun(mutation) {
      const scope = scopeFor(mutation);
      if (typeof scope === "string") {
        const mutationsWithSameScope = this.#scopes.get(scope);
        const firstPendingMutation = mutationsWithSameScope?.find(m => m.state.status === "pending");
        return !firstPendingMutation || firstPendingMutation === mutation;
      } else {
        return true;
      }
    }
    runNext(mutation) {
      const scope = scopeFor(mutation);
      if (typeof scope === "string") {
        const foundMutation = this.#scopes.get(scope)?.find(m => m !== mutation && m.state.isPaused);
        return foundMutation?.continue() ?? Promise.resolve();
      } else {
        return Promise.resolve();
      }
    }
    clear() {
      _notifyManagerJs.notifyManager.batch(() => {
        this.#mutations.forEach(mutation => {
          this.notify({
            type: "removed",
            mutation
          });
        });
        this.#mutations.clear();
        this.#scopes.clear();
      });
    }
    getAll() {
      return Array.from(this.#mutations);
    }
    find(filters) {
      const defaultedFilters = {
        exact: true,
        ...filters
      };
      return this.getAll().find(mutation => (0, _utilsJs.matchMutation)(defaultedFilters, mutation));
    }
    findAll(filters = {}) {
      return this.getAll().filter(mutation => (0, _utilsJs.matchMutation)(filters, mutation));
    }
    notify(event) {
      _notifyManagerJs.notifyManager.batch(() => {
        this.listeners.forEach(listener => {
          listener(event);
        });
      });
    }
    resumePausedMutations() {
      const pausedMutations = this.getAll().filter(x => x.state.isPaused);
      return _notifyManagerJs.notifyManager.batch(() => Promise.all(pausedMutations.map(mutation => mutation.continue().catch(_utilsJs.noop))));
    }
  };
  function scopeFor(mutation) {
    return mutation.options.scope?.id;
  }
},1304,[1298,1305,1290,1288],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/mutationCache.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var _client, _observers, _mutationCache, _retryer, _dispatch; // src/mutation.ts
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "Mutation", {
    enumerable: true,
    get: function () {
      return Mutation;
    }
  });
  Object.defineProperty(exports, "getDefaultState", {
    enumerable: true,
    get: function () {
      return getDefaultState;
    }
  });
  var _babelRuntimeHelpersClassPrivateFieldLooseBase = require(_dependencyMap[0], "@babel/runtime/helpers/classPrivateFieldLooseBase");
  var _classPrivateFieldLooseBase = _interopDefault(_babelRuntimeHelpersClassPrivateFieldLooseBase);
  var _babelRuntimeHelpersClassPrivateFieldLooseKey = require(_dependencyMap[1], "@babel/runtime/helpers/classPrivateFieldLooseKey");
  var _classPrivateFieldLooseKey = _interopDefault(_babelRuntimeHelpersClassPrivateFieldLooseKey);
  var _notifyManagerJs = require(_dependencyMap[2], "./notifyManager.js");
  var _removableJs = require(_dependencyMap[3], "./removable.js");
  var _retryerJs = require(_dependencyMap[4], "./retryer.js");
  var Mutation = (_client = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("client"), _observers = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("observers"), _mutationCache = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("mutationCache"), _retryer = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("retryer"), _dispatch = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("dispatch"), class Mutation extends _removableJs.Removable {
    constructor(config) {
      super();
      Object.defineProperty(this, _dispatch, {
        value: _dispatch2
      });
      Object.defineProperty(this, _client, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _observers, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _mutationCache, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _retryer, {
        writable: true,
        value: void 0
      });
      (0, _classPrivateFieldLooseBase.default)(this, _client)[_client] = config.client;
      this.mutationId = config.mutationId;
      (0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache] = config.mutationCache;
      (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers] = [];
      this.state = config.state || getDefaultState();
      this.setOptions(config.options);
      this.scheduleGc();
    }
    setOptions(options) {
      this.options = options;
      this.updateGcTime(this.options.gcTime);
    }
    get meta() {
      return this.options.meta;
    }
    addObserver(observer) {
      if (!(0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers].includes(observer)) {
        (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers].push(observer);
        this.clearGcTimeout();
        (0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache].notify({
          type: "observerAdded",
          mutation: this,
          observer
        });
      }
    }
    removeObserver(observer) {
      (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers] = (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers].filter(x => x !== observer);
      this.scheduleGc();
      (0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache].notify({
        type: "observerRemoved",
        mutation: this,
        observer
      });
    }
    optionalRemove() {
      if (!(0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers].length) {
        if (this.state.status === "pending") {
          this.scheduleGc();
        } else {
          (0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache].remove(this);
        }
      }
    }
    continue() {
      return (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer]?.continue() ??
      // continuing a mutation assumes that variables are set, mutation must have been dehydrated before
      this.execute(this.state.variables);
    }
    async execute(variables) {
      const onContinue = () => {
        (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
          type: "continue"
        });
      };
      const mutationFnContext = {
        client: (0, _classPrivateFieldLooseBase.default)(this, _client)[_client],
        meta: this.options.meta,
        mutationKey: this.options.mutationKey
      };
      (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer] = (0, _retryerJs.createRetryer)({
        fn: () => {
          if (!this.options.mutationFn) {
            return Promise.reject(new Error("No mutationFn found"));
          }
          return this.options.mutationFn(variables, mutationFnContext);
        },
        onFail: (failureCount, error) => {
          (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
            type: "failed",
            failureCount,
            error
          });
        },
        onPause: () => {
          (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
            type: "pause"
          });
        },
        onContinue,
        retry: this.options.retry ?? 0,
        retryDelay: this.options.retryDelay,
        networkMode: this.options.networkMode,
        canRun: () => (0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache].canRun(this)
      });
      const restored = this.state.status === "pending";
      const isPaused = !(0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer].canStart();
      try {
        if (restored) {
          onContinue();
        } else {
          (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
            type: "pending",
            variables,
            isPaused
          });
          if ((0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache].config.onMutate) {
            await (0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache].config.onMutate(variables, this, mutationFnContext);
          }
          const context = await this.options.onMutate?.(variables, mutationFnContext);
          if (context !== this.state.context) {
            (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
              type: "pending",
              context,
              variables,
              isPaused
            });
          }
        }
        const data = await (0, _classPrivateFieldLooseBase.default)(this, _retryer)[_retryer].start();
        await (0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache].config.onSuccess?.(data, variables, this.state.context, this, mutationFnContext);
        await this.options.onSuccess?.(data, variables, this.state.context, mutationFnContext);
        await (0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache].config.onSettled?.(data, null, this.state.variables, this.state.context, this, mutationFnContext);
        await this.options.onSettled?.(data, null, variables, this.state.context, mutationFnContext);
        (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
          type: "success",
          data
        });
        return data;
      } catch (error) {
        try {
          await (0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache].config.onError?.(error, variables, this.state.context, this, mutationFnContext);
        } catch (e) {
          void Promise.reject(e);
        }
        try {
          await this.options.onError?.(error, variables, this.state.context, mutationFnContext);
        } catch (e) {
          void Promise.reject(e);
        }
        try {
          await (0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache].config.onSettled?.(void 0, error, this.state.variables, this.state.context, this, mutationFnContext);
        } catch (e) {
          void Promise.reject(e);
        }
        try {
          await this.options.onSettled?.(void 0, error, variables, this.state.context, mutationFnContext);
        } catch (e) {
          void Promise.reject(e);
        }
        (0, _classPrivateFieldLooseBase.default)(this, _dispatch)[_dispatch]({
          type: "error",
          error
        });
        throw error;
      } finally {
        (0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache].runNext(this);
      }
    }
  });
  function _dispatch2(action) {
    const reducer = state => {
      switch (action.type) {
        case "failed":
          return {
            ...state,
            failureCount: action.failureCount,
            failureReason: action.error
          };
        case "pause":
          return {
            ...state,
            isPaused: true
          };
        case "continue":
          return {
            ...state,
            isPaused: false
          };
        case "pending":
          return {
            ...state,
            context: action.context,
            data: void 0,
            failureCount: 0,
            failureReason: null,
            error: null,
            isPaused: action.isPaused,
            status: "pending",
            variables: action.variables,
            submittedAt: Date.now()
          };
        case "success":
          return {
            ...state,
            data: action.data,
            failureCount: 0,
            failureReason: null,
            error: null,
            status: "success",
            isPaused: false
          };
        case "error":
          return {
            ...state,
            data: void 0,
            error: action.error,
            failureCount: state.failureCount + 1,
            failureReason: action.error,
            isPaused: false,
            status: "error"
          };
      }
    };
    this.state = reducer(this.state);
    _notifyManagerJs.notifyManager.batch(() => {
      (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers].forEach(observer => {
        observer.onMutationUpdate(action);
      });
      (0, _classPrivateFieldLooseBase.default)(this, _mutationCache)[_mutationCache].notify({
        mutation: this,
        type: "updated",
        action
      });
    });
  }
  function getDefaultState() {
    return {
      context: void 0,
      data: void 0,
      error: null,
      failureCount: 0,
      failureReason: null,
      isPaused: false,
      status: "idle",
      variables: void 0,
      submittedAt: 0
    };
  }
},1305,[1296,1297,1298,1302,1300],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/mutation.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var _client, _currentResult, _currentMutation, _mutateOptions, _updateResult, _notify; // src/mutationObserver.ts
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "MutationObserver", {
    enumerable: true,
    get: function () {
      return MutationObserver;
    }
  });
  var _babelRuntimeHelpersClassPrivateFieldLooseBase = require(_dependencyMap[0], "@babel/runtime/helpers/classPrivateFieldLooseBase");
  var _classPrivateFieldLooseBase = _interopDefault(_babelRuntimeHelpersClassPrivateFieldLooseBase);
  var _babelRuntimeHelpersClassPrivateFieldLooseKey = require(_dependencyMap[1], "@babel/runtime/helpers/classPrivateFieldLooseKey");
  var _classPrivateFieldLooseKey = _interopDefault(_babelRuntimeHelpersClassPrivateFieldLooseKey);
  var _mutationJs = require(_dependencyMap[2], "./mutation.js");
  var _notifyManagerJs = require(_dependencyMap[3], "./notifyManager.js");
  var _subscribableJs = require(_dependencyMap[4], "./subscribable.js");
  var _utilsJs = require(_dependencyMap[5], "./utils.js");
  var MutationObserver = (_client = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("client"), _currentResult = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("currentResult"), _currentMutation = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("currentMutation"), _mutateOptions = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("mutateOptions"), _updateResult = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("updateResult"), _notify = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("notify"), class MutationObserver extends _subscribableJs.Subscribable {
    constructor(client, options) {
      super();
      Object.defineProperty(this, _notify, {
        value: _notify2
      });
      Object.defineProperty(this, _updateResult, {
        value: _updateResult2
      });
      Object.defineProperty(this, _client, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _currentResult, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _currentMutation, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _mutateOptions, {
        writable: true,
        value: void 0
      });
      (0, _classPrivateFieldLooseBase.default)(this, _client)[_client] = client;
      this.setOptions(options);
      this.bindMethods();
      (0, _classPrivateFieldLooseBase.default)(this, _updateResult)[_updateResult]();
    }
    bindMethods() {
      this.mutate = this.mutate.bind(this);
      this.reset = this.reset.bind(this);
    }
    setOptions(options) {
      const prevOptions = this.options;
      this.options = (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].defaultMutationOptions(options);
      if (!(0, _utilsJs.shallowEqualObjects)(this.options, prevOptions)) {
        (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].getMutationCache().notify({
          type: "observerOptionsUpdated",
          mutation: (0, _classPrivateFieldLooseBase.default)(this, _currentMutation)[_currentMutation],
          observer: this
        });
      }
      if (prevOptions?.mutationKey && this.options.mutationKey && (0, _utilsJs.hashKey)(prevOptions.mutationKey) !== (0, _utilsJs.hashKey)(this.options.mutationKey)) {
        this.reset();
      } else if ((0, _classPrivateFieldLooseBase.default)(this, _currentMutation)[_currentMutation]?.state.status === "pending") {
        (0, _classPrivateFieldLooseBase.default)(this, _currentMutation)[_currentMutation].setOptions(this.options);
      }
    }
    onUnsubscribe() {
      if (!this.hasListeners()) {
        (0, _classPrivateFieldLooseBase.default)(this, _currentMutation)[_currentMutation]?.removeObserver(this);
      }
    }
    onMutationUpdate(action) {
      (0, _classPrivateFieldLooseBase.default)(this, _updateResult)[_updateResult]();
      (0, _classPrivateFieldLooseBase.default)(this, _notify)[_notify](action);
    }
    getCurrentResult() {
      return (0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult];
    }
    reset() {
      (0, _classPrivateFieldLooseBase.default)(this, _currentMutation)[_currentMutation]?.removeObserver(this);
      (0, _classPrivateFieldLooseBase.default)(this, _currentMutation)[_currentMutation] = void 0;
      (0, _classPrivateFieldLooseBase.default)(this, _updateResult)[_updateResult]();
      (0, _classPrivateFieldLooseBase.default)(this, _notify)[_notify]();
    }
    mutate(variables, options) {
      (0, _classPrivateFieldLooseBase.default)(this, _mutateOptions)[_mutateOptions] = options;
      (0, _classPrivateFieldLooseBase.default)(this, _currentMutation)[_currentMutation]?.removeObserver(this);
      (0, _classPrivateFieldLooseBase.default)(this, _currentMutation)[_currentMutation] = (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].getMutationCache().build((0, _classPrivateFieldLooseBase.default)(this, _client)[_client], this.options);
      (0, _classPrivateFieldLooseBase.default)(this, _currentMutation)[_currentMutation].addObserver(this);
      return (0, _classPrivateFieldLooseBase.default)(this, _currentMutation)[_currentMutation].execute(variables);
    }
  });
  function _updateResult2() {
    const state = (0, _classPrivateFieldLooseBase.default)(this, _currentMutation)[_currentMutation]?.state ?? (0, _mutationJs.getDefaultState)();
    (0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult] = {
      ...state,
      isPending: state.status === "pending",
      isSuccess: state.status === "success",
      isError: state.status === "error",
      isIdle: state.status === "idle",
      mutate: this.mutate,
      reset: this.reset
    };
  }
  function _notify2(action) {
    _notifyManagerJs.notifyManager.batch(() => {
      if ((0, _classPrivateFieldLooseBase.default)(this, _mutateOptions)[_mutateOptions] && this.hasListeners()) {
        const variables = (0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult].variables;
        const onMutateResult = (0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult].context;
        const context = {
          client: (0, _classPrivateFieldLooseBase.default)(this, _client)[_client],
          meta: this.options.meta,
          mutationKey: this.options.mutationKey
        };
        if (action?.type === "success") {
          try {
            (0, _classPrivateFieldLooseBase.default)(this, _mutateOptions)[_mutateOptions].onSuccess?.(action.data, variables, onMutateResult, context);
          } catch (e) {
            void Promise.reject(e);
          }
          try {
            (0, _classPrivateFieldLooseBase.default)(this, _mutateOptions)[_mutateOptions].onSettled?.(action.data, null, variables, onMutateResult, context);
          } catch (e) {
            void Promise.reject(e);
          }
        } else if (action?.type === "error") {
          try {
            (0, _classPrivateFieldLooseBase.default)(this, _mutateOptions)[_mutateOptions].onError?.(action.error, variables, onMutateResult, context);
          } catch (e) {
            void Promise.reject(e);
          }
          try {
            (0, _classPrivateFieldLooseBase.default)(this, _mutateOptions)[_mutateOptions].onSettled?.(void 0, action.error, variables, onMutateResult, context);
          } catch (e) {
            void Promise.reject(e);
          }
        }
      }
      this.listeners.forEach(listener => {
        listener((0, _classPrivateFieldLooseBase.default)(this, _currentResult)[_currentResult]);
      });
    });
  }
},1306,[1296,1297,1305,1298,1288,1290],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/mutationObserver.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var _client, _result, _queries, _options, _observers, _combinedResult, _lastCombine, _lastResult, _lastQueryHashes, _observerMatches, _trackResult, _combineResult, _shouldSkipCombine, _findMatchingObservers, _onUpdate, _notify; // src/queriesObserver.ts
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "QueriesObserver", {
    enumerable: true,
    get: function () {
      return QueriesObserver;
    }
  });
  var _babelRuntimeHelpersClassPrivateFieldLooseBase = require(_dependencyMap[0], "@babel/runtime/helpers/classPrivateFieldLooseBase");
  var _classPrivateFieldLooseBase = _interopDefault(_babelRuntimeHelpersClassPrivateFieldLooseBase);
  var _babelRuntimeHelpersClassPrivateFieldLooseKey = require(_dependencyMap[1], "@babel/runtime/helpers/classPrivateFieldLooseKey");
  var _classPrivateFieldLooseKey = _interopDefault(_babelRuntimeHelpersClassPrivateFieldLooseKey);
  var _notifyManagerJs = require(_dependencyMap[2], "./notifyManager.js");
  var _queryObserverJs = require(_dependencyMap[3], "./queryObserver.js");
  var _subscribableJs = require(_dependencyMap[4], "./subscribable.js");
  var _utilsJs = require(_dependencyMap[5], "./utils.js");
  function difference(array1, array2) {
    const excludeSet = new Set(array2);
    return array1.filter(x => !excludeSet.has(x));
  }
  function replaceAt(array, index, value) {
    const copy = array.slice(0);
    copy[index] = value;
    return copy;
  }
  var QueriesObserver = (_client = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("client"), _result = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("result"), _queries = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("queries"), _options = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("options"), _observers = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("observers"), _combinedResult = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("combinedResult"), _lastCombine = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("lastCombine"), _lastResult = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("lastResult"), _lastQueryHashes = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("lastQueryHashes"), _observerMatches = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("observerMatches"), _trackResult = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("trackResult"), _combineResult = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("combineResult"), _shouldSkipCombine = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("shouldSkipCombine"), _findMatchingObservers = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("findMatchingObservers"), _onUpdate = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("onUpdate"), _notify = /*#__PURE__*/(0, _classPrivateFieldLooseKey.default)("notify"), class QueriesObserver extends _subscribableJs.Subscribable {
    constructor(client, _queries2, _options2) {
      super();
      Object.defineProperty(this, _notify, {
        value: _notify2
      });
      Object.defineProperty(this, _onUpdate, {
        value: _onUpdate2
      });
      Object.defineProperty(this, _findMatchingObservers, {
        value: _findMatchingObservers2
      });
      Object.defineProperty(this, _shouldSkipCombine, {
        value: _shouldSkipCombine2
      });
      Object.defineProperty(this, _combineResult, {
        value: _combineResult2
      });
      Object.defineProperty(this, _trackResult, {
        value: _trackResult2
      });
      Object.defineProperty(this, _client, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _result, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _queries, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _options, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _observers, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _combinedResult, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _lastCombine, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _lastResult, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _lastQueryHashes, {
        writable: true,
        value: void 0
      });
      Object.defineProperty(this, _observerMatches, {
        writable: true,
        value: []
      });
      (0, _classPrivateFieldLooseBase.default)(this, _client)[_client] = client;
      (0, _classPrivateFieldLooseBase.default)(this, _options)[_options] = _options2;
      (0, _classPrivateFieldLooseBase.default)(this, _queries)[_queries] = [];
      (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers] = [];
      (0, _classPrivateFieldLooseBase.default)(this, _result)[_result] = [];
      this.setQueries(_queries2);
    }
    onSubscribe() {
      if (this.listeners.size === 1) {
        (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers].forEach(observer => {
          observer.subscribe(result => {
            (0, _classPrivateFieldLooseBase.default)(this, _onUpdate)[_onUpdate](observer, result);
          });
        });
      }
    }
    onUnsubscribe() {
      if (!this.listeners.size) {
        this.destroy();
      }
    }
    destroy() {
      this.listeners = /* @__PURE__ */new Set();
      (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers].forEach(observer => {
        observer.destroy();
      });
    }
    setQueries(queries, options) {
      (0, _classPrivateFieldLooseBase.default)(this, _queries)[_queries] = queries;
      (0, _classPrivateFieldLooseBase.default)(this, _options)[_options] = options;
      if (process.env.NODE_ENV !== "production") {
        const queryHashes = queries.map(query => (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].defaultQueryOptions(query).queryHash);
        if (new Set(queryHashes).size !== queryHashes.length) {
          console.warn("[QueriesObserver]: Duplicate Queries found. This might result in unexpected behavior.");
        }
      }
      _notifyManagerJs.notifyManager.batch(() => {
        const prevObservers = (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers];
        const newObserverMatches = (0, _classPrivateFieldLooseBase.default)(this, _findMatchingObservers)[_findMatchingObservers]((0, _classPrivateFieldLooseBase.default)(this, _queries)[_queries]);
        newObserverMatches.forEach(match => match.observer.setOptions(match.defaultedQueryOptions));
        const newObservers = newObserverMatches.map(match => match.observer);
        const newResult = newObservers.map(observer => observer.getCurrentResult());
        const hasLengthChange = prevObservers.length !== newObservers.length;
        const hasIndexChange = newObservers.some((observer, index) => observer !== prevObservers[index]);
        const hasStructuralChange = hasLengthChange || hasIndexChange;
        const hasResultChange = hasStructuralChange ? true : newResult.some((result, index) => {
          const prev = (0, _classPrivateFieldLooseBase.default)(this, _result)[_result][index];
          return !prev || !(0, _utilsJs.shallowEqualObjects)(result, prev);
        });
        if (!hasStructuralChange && !hasResultChange) return;
        if (hasStructuralChange) {
          (0, _classPrivateFieldLooseBase.default)(this, _observerMatches)[_observerMatches] = newObserverMatches;
          (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers] = newObservers;
        }
        (0, _classPrivateFieldLooseBase.default)(this, _result)[_result] = newResult;
        if (!this.hasListeners()) return;
        if (hasStructuralChange) {
          difference(prevObservers, newObservers).forEach(observer => {
            observer.destroy();
          });
          difference(newObservers, prevObservers).forEach(observer => {
            observer.subscribe(result => {
              (0, _classPrivateFieldLooseBase.default)(this, _onUpdate)[_onUpdate](observer, result);
            });
          });
        }
        (0, _classPrivateFieldLooseBase.default)(this, _notify)[_notify]();
      });
    }
    getCurrentResult() {
      return (0, _classPrivateFieldLooseBase.default)(this, _result)[_result];
    }
    getQueries() {
      return (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers].map(observer => observer.getCurrentQuery());
    }
    getObservers() {
      return (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers];
    }
    getOptimisticResult(queries, combine) {
      const matches = (0, _classPrivateFieldLooseBase.default)(this, _findMatchingObservers)[_findMatchingObservers](queries);
      const result = matches.map(match => match.observer.getOptimisticResult(match.defaultedQueryOptions));
      const queryHashes = matches.map(match => match.defaultedQueryOptions.queryHash);
      return [result, r => {
        return (0, _classPrivateFieldLooseBase.default)(this, _combineResult)[_combineResult](r ?? result, combine, queryHashes);
      }, () => {
        return (0, _classPrivateFieldLooseBase.default)(this, _trackResult)[_trackResult](result, matches);
      }];
    }
  });
  function _trackResult2(result, matches) {
    return matches.map((match, index) => {
      const observerResult = result[index];
      return !match.defaultedQueryOptions.notifyOnChangeProps ? match.observer.trackResult(observerResult, accessedProp => {
        matches.forEach(m => {
          m.observer.trackProp(accessedProp);
        });
      }) : observerResult;
    });
  }
  function _combineResult2(input, combine, queryHashes) {
    if (combine) {
      const lastHashes = (0, _classPrivateFieldLooseBase.default)(this, _lastQueryHashes)[_lastQueryHashes];
      const queryHashesChanged = queryHashes !== void 0 && lastHashes !== void 0 && (lastHashes.length !== queryHashes.length || queryHashes.some((hash, i) => hash !== lastHashes[i]));
      if (!(0, _classPrivateFieldLooseBase.default)(this, _combinedResult)[_combinedResult] || (0, _classPrivateFieldLooseBase.default)(this, _result)[_result] !== (0, _classPrivateFieldLooseBase.default)(this, _lastResult)[_lastResult] || queryHashesChanged || combine !== (0, _classPrivateFieldLooseBase.default)(this, _lastCombine)[_lastCombine]) {
        (0, _classPrivateFieldLooseBase.default)(this, _lastCombine)[_lastCombine] = combine;
        (0, _classPrivateFieldLooseBase.default)(this, _lastResult)[_lastResult] = (0, _classPrivateFieldLooseBase.default)(this, _result)[_result];
        if (queryHashes !== void 0) {
          (0, _classPrivateFieldLooseBase.default)(this, _lastQueryHashes)[_lastQueryHashes] = queryHashes;
        }
        (0, _classPrivateFieldLooseBase.default)(this, _combinedResult)[_combinedResult] = (0, _utilsJs.replaceEqualDeep)((0, _classPrivateFieldLooseBase.default)(this, _combinedResult)[_combinedResult], combine(input));
      }
      return (0, _classPrivateFieldLooseBase.default)(this, _combinedResult)[_combinedResult];
    }
    return input;
  }
  function _shouldSkipCombine2() {
    return (0, _classPrivateFieldLooseBase.default)(this, _options)[_options]?.combine !== void 0 && (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers].some((observer, index) => {
      return observer.options.suspense && (0, _classPrivateFieldLooseBase.default)(this, _result)[_result][index]?.data === void 0;
    });
  }
  function _findMatchingObservers2(queries) {
    const prevObserversMap = /* @__PURE__ */new Map();
    (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers].forEach(observer => {
      const key = observer.options.queryHash;
      if (!key) return;
      const previousObservers = prevObserversMap.get(key);
      if (previousObservers) {
        previousObservers.push(observer);
      } else {
        prevObserversMap.set(key, [observer]);
      }
    });
    const observers = [];
    queries.forEach(options => {
      const defaultedOptions = (0, _classPrivateFieldLooseBase.default)(this, _client)[_client].defaultQueryOptions(options);
      const match = prevObserversMap.get(defaultedOptions.queryHash)?.shift();
      const observer = match ?? new _queryObserverJs.QueryObserver((0, _classPrivateFieldLooseBase.default)(this, _client)[_client], defaultedOptions);
      observers.push({
        defaultedQueryOptions: defaultedOptions,
        observer
      });
    });
    return observers;
  }
  function _onUpdate2(observer, result) {
    const index = (0, _classPrivateFieldLooseBase.default)(this, _observers)[_observers].indexOf(observer);
    if (index !== -1) {
      (0, _classPrivateFieldLooseBase.default)(this, _result)[_result] = replaceAt((0, _classPrivateFieldLooseBase.default)(this, _result)[_result], index, result);
      (0, _classPrivateFieldLooseBase.default)(this, _notify)[_notify]();
    }
  }
  function _notify2() {
    if (this.hasListeners()) {
      const newTracked = (0, _classPrivateFieldLooseBase.default)(this, _trackResult)[_trackResult]((0, _classPrivateFieldLooseBase.default)(this, _result)[_result], (0, _classPrivateFieldLooseBase.default)(this, _observerMatches)[_observerMatches]);
      const shouldSkipCombine = (0, _classPrivateFieldLooseBase.default)(this, _shouldSkipCombine)[_shouldSkipCombine]();
      const previousResult = (0, _classPrivateFieldLooseBase.default)(this, _combinedResult)[_combinedResult];
      const newResult = shouldSkipCombine ? previousResult : (0, _classPrivateFieldLooseBase.default)(this, _combineResult)[_combineResult](newTracked, (0, _classPrivateFieldLooseBase.default)(this, _options)[_options]?.combine);
      if (shouldSkipCombine || previousResult !== newResult) {
        _notifyManagerJs.notifyManager.batch(() => {
          this.listeners.forEach(listener => {
            listener((0, _classPrivateFieldLooseBase.default)(this, _result)[_result]);
          });
        });
      }
    }
  }
},1307,[1296,1297,1298,1295,1288,1290],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/queriesObserver.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "QueryCache", {
    enumerable: true,
    get: function () {
      return QueryCache;
    }
  });
  var _utilsJs = require(_dependencyMap[0], "./utils.js");
  var _queryJs = require(_dependencyMap[1], "./query.js");
  var _notifyManagerJs = require(_dependencyMap[2], "./notifyManager.js");
  var _subscribableJs = require(_dependencyMap[3], "./subscribable.js");
  // src/queryCache.ts

  var QueryCache = class extends _subscribableJs.Subscribable {
    constructor(config = {}) {
      super();
      this.config = config;
      this.#queries = /* @__PURE__ */new Map();
    }
    #queries;
    build(client, options, state) {
      const queryKey = options.queryKey;
      const queryHash = options.queryHash ?? (0, _utilsJs.hashQueryKeyByOptions)(queryKey, options);
      let query = this.get(queryHash);
      if (!query) {
        query = new _queryJs.Query({
          client,
          queryKey,
          queryHash,
          options: client.defaultQueryOptions(options),
          state,
          defaultOptions: client.getQueryDefaults(queryKey)
        });
        this.add(query);
      }
      return query;
    }
    add(query) {
      if (!this.#queries.has(query.queryHash)) {
        this.#queries.set(query.queryHash, query);
        this.notify({
          type: "added",
          query
        });
      }
    }
    remove(query) {
      const queryInMap = this.#queries.get(query.queryHash);
      if (queryInMap) {
        query.destroy();
        if (queryInMap === query) {
          this.#queries.delete(query.queryHash);
        }
        this.notify({
          type: "removed",
          query
        });
      }
    }
    clear() {
      _notifyManagerJs.notifyManager.batch(() => {
        this.getAll().forEach(query => {
          this.remove(query);
        });
      });
    }
    get(queryHash) {
      return this.#queries.get(queryHash);
    }
    getAll() {
      return [...this.#queries.values()];
    }
    find(filters) {
      const defaultedFilters = {
        exact: true,
        ...filters
      };
      return this.getAll().find(query => (0, _utilsJs.matchQuery)(defaultedFilters, query));
    }
    findAll(filters = {}) {
      const queries = this.getAll();
      return Object.keys(filters).length > 0 ? queries.filter(query => (0, _utilsJs.matchQuery)(filters, query)) : queries;
    }
    notify(event) {
      _notifyManagerJs.notifyManager.batch(() => {
        this.listeners.forEach(listener => {
          listener(event);
        });
      });
    }
    onFocus() {
      _notifyManagerJs.notifyManager.batch(() => {
        this.getAll().forEach(query => {
          query.onFocus();
        });
      });
    }
    onOnline() {
      _notifyManagerJs.notifyManager.batch(() => {
        this.getAll().forEach(query => {
          query.onOnline();
        });
      });
    }
  };
},1308,[1290,1299,1298,1288],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/queryCache.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "QueryClient", {
    enumerable: true,
    get: function () {
      return QueryClient;
    }
  });
  var _utilsJs = require(_dependencyMap[0], "./utils.js");
  var _queryCacheJs = require(_dependencyMap[1], "./queryCache.js");
  var _mutationCacheJs = require(_dependencyMap[2], "./mutationCache.js");
  var _focusManagerJs = require(_dependencyMap[3], "./focusManager.js");
  var _onlineManagerJs = require(_dependencyMap[4], "./onlineManager.js");
  var _notifyManagerJs = require(_dependencyMap[5], "./notifyManager.js");
  // src/queryClient.ts

  var QueryClient = class {
    #queryCache;
    #mutationCache;
    #defaultOptions;
    #queryDefaults;
    #mutationDefaults;
    #mountCount;
    #unsubscribeFocus;
    #unsubscribeOnline;
    constructor(config = {}) {
      this.#queryCache = config.queryCache || new _queryCacheJs.QueryCache();
      this.#mutationCache = config.mutationCache || new _mutationCacheJs.MutationCache();
      this.#defaultOptions = config.defaultOptions || {};
      this.#queryDefaults = /* @__PURE__ */new Map();
      this.#mutationDefaults = /* @__PURE__ */new Map();
      this.#mountCount = 0;
    }
    mount() {
      this.#mountCount++;
      if (this.#mountCount !== 1) return;
      this.#unsubscribeFocus = _focusManagerJs.focusManager.subscribe(async focused => {
        if (focused) {
          await this.resumePausedMutations();
          this.#queryCache.onFocus();
        }
      });
      this.#unsubscribeOnline = _onlineManagerJs.onlineManager.subscribe(async online => {
        if (online) {
          await this.resumePausedMutations();
          this.#queryCache.onOnline();
        }
      });
    }
    unmount() {
      this.#mountCount--;
      if (this.#mountCount !== 0) return;
      this.#unsubscribeFocus?.();
      this.#unsubscribeFocus = void 0;
      this.#unsubscribeOnline?.();
      this.#unsubscribeOnline = void 0;
    }
    isFetching(filters) {
      return this.#queryCache.findAll({
        ...filters,
        fetchStatus: "fetching"
      }).length;
    }
    isMutating(filters) {
      return this.#mutationCache.findAll({
        ...filters,
        status: "pending"
      }).length;
    }
    /**
     * Imperative (non-reactive) way to retrieve data for a QueryKey.
     * Should only be used in callbacks or functions where reading the latest data is necessary, e.g. for optimistic updates.
     *
     * Hint: Do not use this function inside a component, because it won't receive updates.
     * Use `useQuery` to create a `QueryObserver` that subscribes to changes.
     */
    getQueryData(queryKey) {
      const options = this.defaultQueryOptions({
        queryKey
      });
      return this.#queryCache.get(options.queryHash)?.state.data;
    }
    ensureQueryData(options) {
      const defaultedOptions = this.defaultQueryOptions(options);
      const query = this.#queryCache.build(this, defaultedOptions);
      const cachedData = query.state.data;
      if (cachedData === void 0) {
        return this.fetchQuery(options);
      }
      if (options.revalidateIfStale && query.isStaleByTime((0, _utilsJs.resolveStaleTime)(defaultedOptions.staleTime, query))) {
        void this.prefetchQuery(defaultedOptions);
      }
      return Promise.resolve(cachedData);
    }
    getQueriesData(filters) {
      return this.#queryCache.findAll(filters).map(({
        queryKey,
        state
      }) => {
        const data = state.data;
        return [queryKey, data];
      });
    }
    setQueryData(queryKey, updater, options) {
      const defaultedOptions = this.defaultQueryOptions({
        queryKey
      });
      const query = this.#queryCache.get(defaultedOptions.queryHash);
      const prevData = query?.state.data;
      const data = (0, _utilsJs.functionalUpdate)(updater, prevData);
      if (data === void 0) {
        return void 0;
      }
      return this.#queryCache.build(this, defaultedOptions).setData(data, {
        ...options,
        manual: true
      });
    }
    setQueriesData(filters, updater, options) {
      return _notifyManagerJs.notifyManager.batch(() => this.#queryCache.findAll(filters).map(({
        queryKey
      }) => [queryKey, this.setQueryData(queryKey, updater, options)]));
    }
    getQueryState(queryKey) {
      const options = this.defaultQueryOptions({
        queryKey
      });
      return this.#queryCache.get(options.queryHash)?.state;
    }
    removeQueries(filters) {
      const queryCache = this.#queryCache;
      _notifyManagerJs.notifyManager.batch(() => {
        queryCache.findAll(filters).forEach(query => {
          queryCache.remove(query);
        });
      });
    }
    resetQueries(filters, options) {
      const queryCache = this.#queryCache;
      return _notifyManagerJs.notifyManager.batch(() => {
        queryCache.findAll(filters).forEach(query => {
          query.reset();
        });
        return this.refetchQueries({
          type: "active",
          ...filters
        }, options);
      });
    }
    cancelQueries(filters, cancelOptions = {}) {
      const defaultedCancelOptions = {
        revert: true,
        ...cancelOptions
      };
      const promises = _notifyManagerJs.notifyManager.batch(() => this.#queryCache.findAll(filters).map(query => query.cancel(defaultedCancelOptions)));
      return Promise.all(promises).then(_utilsJs.noop).catch(_utilsJs.noop);
    }
    invalidateQueries(filters, options = {}) {
      return _notifyManagerJs.notifyManager.batch(() => {
        this.#queryCache.findAll(filters).forEach(query => {
          query.invalidate();
        });
        if (filters?.refetchType === "none") {
          return Promise.resolve();
        }
        return this.refetchQueries({
          ...filters,
          type: filters?.refetchType ?? filters?.type ?? "active"
        }, options);
      });
    }
    refetchQueries(filters, options = {}) {
      const fetchOptions = {
        ...options,
        cancelRefetch: options.cancelRefetch ?? true
      };
      const promises = _notifyManagerJs.notifyManager.batch(() => this.#queryCache.findAll(filters).filter(query => !query.isDisabled() && !query.isStatic()).map(query => {
        let promise = query.fetch(void 0, fetchOptions);
        if (!fetchOptions.throwOnError) {
          promise = promise.catch(_utilsJs.noop);
        }
        return query.state.fetchStatus === "paused" ? Promise.resolve() : promise;
      }));
      return Promise.all(promises).then(_utilsJs.noop);
    }
    fetchQuery(options) {
      const defaultedOptions = this.defaultQueryOptions(options);
      if (defaultedOptions.retry === void 0) {
        defaultedOptions.retry = false;
      }
      const query = this.#queryCache.build(this, defaultedOptions);
      return query.isStaleByTime((0, _utilsJs.resolveStaleTime)(defaultedOptions.staleTime, query)) ? query.fetch(defaultedOptions) : Promise.resolve(query.state.data);
    }
    prefetchQuery(options) {
      return this.fetchQuery(options).then(_utilsJs.noop).catch(_utilsJs.noop);
    }
    fetchInfiniteQuery(options) {
      options._type = "infinite";
      return this.fetchQuery(options);
    }
    prefetchInfiniteQuery(options) {
      return this.fetchInfiniteQuery(options).then(_utilsJs.noop).catch(_utilsJs.noop);
    }
    ensureInfiniteQueryData(options) {
      options._type = "infinite";
      return this.ensureQueryData(options);
    }
    resumePausedMutations() {
      if (_onlineManagerJs.onlineManager.isOnline()) {
        return this.#mutationCache.resumePausedMutations();
      }
      return Promise.resolve();
    }
    getQueryCache() {
      return this.#queryCache;
    }
    getMutationCache() {
      return this.#mutationCache;
    }
    getDefaultOptions() {
      return this.#defaultOptions;
    }
    setDefaultOptions(options) {
      this.#defaultOptions = options;
    }
    setQueryDefaults(queryKey, options) {
      this.#queryDefaults.set((0, _utilsJs.hashKey)(queryKey), {
        queryKey,
        defaultOptions: options
      });
    }
    getQueryDefaults(queryKey) {
      const defaults = [...this.#queryDefaults.values()];
      const result = {};
      defaults.forEach(queryDefault => {
        if ((0, _utilsJs.partialMatchKey)(queryKey, queryDefault.queryKey)) {
          Object.assign(result, queryDefault.defaultOptions);
        }
      });
      return result;
    }
    setMutationDefaults(mutationKey, options) {
      this.#mutationDefaults.set((0, _utilsJs.hashKey)(mutationKey), {
        mutationKey,
        defaultOptions: options
      });
    }
    getMutationDefaults(mutationKey) {
      const defaults = [...this.#mutationDefaults.values()];
      const result = {};
      defaults.forEach(queryDefault => {
        if ((0, _utilsJs.partialMatchKey)(mutationKey, queryDefault.mutationKey)) {
          Object.assign(result, queryDefault.defaultOptions);
        }
      });
      return result;
    }
    defaultQueryOptions(options) {
      if (options._defaulted) {
        return options;
      }
      const defaultedOptions = {
        ...this.#defaultOptions.queries,
        ...this.getQueryDefaults(options.queryKey),
        ...options,
        _defaulted: true
      };
      if (!defaultedOptions.queryHash) {
        defaultedOptions.queryHash = (0, _utilsJs.hashQueryKeyByOptions)(defaultedOptions.queryKey, defaultedOptions);
      }
      if (defaultedOptions.refetchOnReconnect === void 0) {
        defaultedOptions.refetchOnReconnect = defaultedOptions.networkMode !== "always";
      }
      if (defaultedOptions.throwOnError === void 0) {
        defaultedOptions.throwOnError = !!defaultedOptions.suspense;
      }
      if (!defaultedOptions.networkMode && defaultedOptions.persister) {
        defaultedOptions.networkMode = "offlineFirst";
      }
      if (defaultedOptions.queryFn === _utilsJs.skipToken) {
        defaultedOptions.enabled = false;
      }
      return defaultedOptions;
    }
    defaultMutationOptions(options) {
      if (options?._defaulted) {
        return options;
      }
      return {
        ...this.#defaultOptions.mutations,
        ...(options?.mutationKey && this.getMutationDefaults(options.mutationKey)),
        ...options,
        _defaulted: true
      };
    }
    clear() {
      this.#queryCache.clear();
      this.#mutationCache.clear();
    }
  };
},1309,[1290,1308,1304,1287,1301,1298],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/queryClient.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "streamedQuery", {
    enumerable: true,
    get: function () {
      return streamedQuery;
    }
  });
  var _utilsJs = require(_dependencyMap[0], "./utils.js");
  // src/streamedQuery.ts

  function streamedQuery({
    streamFn,
    refetchMode = "reset",
    reducer = (items, chunk) => (0, _utilsJs.addToEnd)(items, chunk),
    initialValue = []
  }) {
    return async context => {
      const query = context.client.getQueryCache().find({
        queryKey: context.queryKey,
        exact: true
      });
      const isRefetch = !!query && query.isFetched();
      if (isRefetch && refetchMode === "reset") {
        query.setState({
          ...query.resetState,
          fetchStatus: "fetching"
        });
      }
      let result = initialValue;
      let cancelled = false;
      const streamFnContext = (0, _utilsJs.addConsumeAwareSignal)({
        client: context.client,
        meta: context.meta,
        queryKey: context.queryKey,
        pageParam: context.pageParam,
        direction: context.direction
      }, () => context.signal, () => cancelled = true);
      const stream = await streamFn(streamFnContext);
      const isReplaceRefetch = isRefetch && refetchMode === "replace";
      for await (const chunk of stream) {
        if (cancelled) {
          break;
        }
        if (isReplaceRefetch) {
          result = reducer(result, chunk);
        } else {
          context.client.setQueryData(context.queryKey, prev => reducer(prev === void 0 ? initialValue : prev, chunk));
        }
      }
      if (isReplaceRefetch && !cancelled) {
        context.client.setQueryData(context.queryKey, result);
      }
      return context.client.getQueryData(context.queryKey) ?? initialValue;
    };
  }
},1310,[1290],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/streamedQuery.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "dataTagErrorSymbol", {
    enumerable: true,
    get: function () {
      return dataTagErrorSymbol;
    }
  });
  Object.defineProperty(exports, "dataTagSymbol", {
    enumerable: true,
    get: function () {
      return dataTagSymbol;
    }
  });
  Object.defineProperty(exports, "unsetMarker", {
    enumerable: true,
    get: function () {
      return unsetMarker;
    }
  });
  // src/types.ts
  var dataTagSymbol = /* @__PURE__ */Symbol("dataTagSymbol");
  var dataTagErrorSymbol = /* @__PURE__ */Symbol("dataTagErrorSymbol");
  var unsetMarker = /* @__PURE__ */Symbol("unsetMarker");
},1311,[],"node_modules/.pnpm/@tanstack+query-core@5.100.6/node_modules/@tanstack/query-core/build/modern/types.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {},1312,[],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/types.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/useQueries.ts
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "useQueries", {
    enumerable: true,
    get: function () {
      return useQueries;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  var _tanstackQueryCore = require(_dependencyMap[1], "@tanstack/query-core");
  var _QueryClientProviderJs = require(_dependencyMap[2], "./QueryClientProvider.js");
  var _IsRestoringProviderJs = require(_dependencyMap[3], "./IsRestoringProvider.js");
  var _QueryErrorResetBoundaryJs = require(_dependencyMap[4], "./QueryErrorResetBoundary.js");
  var _errorBoundaryUtilsJs = require(_dependencyMap[5], "./errorBoundaryUtils.js");
  var _suspenseJs = require(_dependencyMap[6], "./suspense.js");
  function useQueries({
    queries,
    ...options
  }, queryClient) {
    const client = (0, _QueryClientProviderJs.useQueryClient)(queryClient);
    const isRestoring = (0, _IsRestoringProviderJs.useIsRestoring)();
    const errorResetBoundary = (0, _QueryErrorResetBoundaryJs.useQueryErrorResetBoundary)();
    const defaultedQueries = React.useMemo(() => queries.map(opts => {
      const defaultedOptions = client.defaultQueryOptions(opts);
      defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : "optimistic";
      return defaultedOptions;
    }), [queries, client, isRestoring]);
    defaultedQueries.forEach(queryOptions => {
      (0, _suspenseJs.ensureSuspenseTimers)(queryOptions);
      const query = client.getQueryCache().get(queryOptions.queryHash);
      (0, _errorBoundaryUtilsJs.ensurePreventErrorBoundaryRetry)(queryOptions, errorResetBoundary, query);
    });
    (0, _errorBoundaryUtilsJs.useClearResetErrorBoundary)(errorResetBoundary);
    const [observer] = React.useState(() => new _tanstackQueryCore.QueriesObserver(client, defaultedQueries, options));
    const [optimisticResult, getCombinedResult, trackResult] = observer.getOptimisticResult(defaultedQueries, options.combine);
    const shouldSubscribe = !isRestoring && options.subscribed !== false;
    React.useSyncExternalStore(React.useCallback(onStoreChange => shouldSubscribe ? observer.subscribe(_tanstackQueryCore.notifyManager.batchCalls(onStoreChange)) : _tanstackQueryCore.noop, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
    React.useEffect(() => {
      observer.setQueries(defaultedQueries, options);
    }, [defaultedQueries, options, observer]);
    const shouldAtLeastOneSuspend = optimisticResult.some((result, index) => (0, _suspenseJs.shouldSuspend)(defaultedQueries[index], result));
    const suspensePromises = shouldAtLeastOneSuspend ? optimisticResult.flatMap((result, index) => {
      const opts = defaultedQueries[index];
      if (opts && (0, _suspenseJs.shouldSuspend)(opts, result)) {
        const queryObserver = new _tanstackQueryCore.QueryObserver(client, opts);
        return (0, _suspenseJs.fetchOptimistic)(opts, queryObserver, errorResetBoundary);
      }
      return [];
    }) : [];
    if (suspensePromises.length > 0) {
      throw Promise.all(suspensePromises);
    }
    const firstSingleResultWhichShouldThrow = optimisticResult.find((result, index) => {
      const query = defaultedQueries[index];
      return query && (0, _errorBoundaryUtilsJs.getHasError)({
        result,
        errorResetBoundary,
        throwOnError: query.throwOnError,
        query: client.getQueryCache().get(query.queryHash),
        suspense: query.suspense
      });
    });
    if (firstSingleResultWhichShouldThrow?.error) {
      throw firstSingleResultWhichShouldThrow.error;
    }
    return getCombinedResult(trackResult());
  }
},1313,[11,1286,1314,1315,1316,1317,1318],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/useQueries.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/QueryClientProvider.tsx
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "QueryClientContext", {
    enumerable: true,
    get: function () {
      return QueryClientContext;
    }
  });
  Object.defineProperty(exports, "QueryClientProvider", {
    enumerable: true,
    get: function () {
      return QueryClientProvider;
    }
  });
  Object.defineProperty(exports, "useQueryClient", {
    enumerable: true,
    get: function () {
      return useQueryClient;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  var _reactJsxRuntime = require(_dependencyMap[1], "react/jsx-runtime");
  var QueryClientContext = /*#__PURE__*/React.createContext(void 0);
  var useQueryClient = queryClient => {
    const client = React.useContext(QueryClientContext);
    if (queryClient) {
      return queryClient;
    }
    if (!client) {
      throw new Error("No QueryClient set, use QueryClientProvider to set one");
    }
    return client;
  };
  var QueryClientProvider = ({
    client,
    children
  }) => {
    React.useEffect(() => {
      client.mount();
      return () => {
        client.unmount();
      };
    }, [client]);
    return /* @__PURE__ */(0, _reactJsxRuntime.jsx)(QueryClientContext.Provider, {
      value: client,
      children
    });
  };
},1314,[11,202],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/IsRestoringProvider.ts
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "IsRestoringProvider", {
    enumerable: true,
    get: function () {
      return IsRestoringProvider;
    }
  });
  Object.defineProperty(exports, "useIsRestoring", {
    enumerable: true,
    get: function () {
      return useIsRestoring;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  var IsRestoringContext = /*#__PURE__*/React.createContext(false);
  var useIsRestoring = () => React.useContext(IsRestoringContext);
  var IsRestoringProvider = IsRestoringContext.Provider;
},1315,[11],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/IsRestoringProvider.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/QueryErrorResetBoundary.tsx
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "QueryErrorResetBoundary", {
    enumerable: true,
    get: function () {
      return QueryErrorResetBoundary;
    }
  });
  Object.defineProperty(exports, "useQueryErrorResetBoundary", {
    enumerable: true,
    get: function () {
      return useQueryErrorResetBoundary;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  var _reactJsxRuntime = require(_dependencyMap[1], "react/jsx-runtime");
  function createValue() {
    let isReset = false;
    return {
      clearReset: () => {
        isReset = false;
      },
      reset: () => {
        isReset = true;
      },
      isReset: () => {
        return isReset;
      }
    };
  }
  var QueryErrorResetBoundaryContext = /*#__PURE__*/React.createContext(createValue());
  var useQueryErrorResetBoundary = () => React.useContext(QueryErrorResetBoundaryContext);
  var QueryErrorResetBoundary = ({
    children
  }) => {
    const [value] = React.useState(() => createValue());
    return /* @__PURE__ */(0, _reactJsxRuntime.jsx)(QueryErrorResetBoundaryContext.Provider, {
      value,
      children: typeof children === "function" ? children(value) : children
    });
  };
},1316,[11,202],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/errorBoundaryUtils.ts
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "ensurePreventErrorBoundaryRetry", {
    enumerable: true,
    get: function () {
      return ensurePreventErrorBoundaryRetry;
    }
  });
  Object.defineProperty(exports, "getHasError", {
    enumerable: true,
    get: function () {
      return getHasError;
    }
  });
  Object.defineProperty(exports, "useClearResetErrorBoundary", {
    enumerable: true,
    get: function () {
      return useClearResetErrorBoundary;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  var _tanstackQueryCore = require(_dependencyMap[1], "@tanstack/query-core");
  var ensurePreventErrorBoundaryRetry = (options, errorResetBoundary, query) => {
    const throwOnError = query?.state.error && typeof options.throwOnError === "function" ? (0, _tanstackQueryCore.shouldThrowError)(options.throwOnError, [query.state.error, query]) : options.throwOnError;
    if (options.suspense || options.experimental_prefetchInRender || throwOnError) {
      if (!errorResetBoundary.isReset()) {
        options.retryOnMount = false;
      }
    }
  };
  var useClearResetErrorBoundary = errorResetBoundary => {
    React.useEffect(() => {
      errorResetBoundary.clearReset();
    }, [errorResetBoundary]);
  };
  var getHasError = ({
    result,
    errorResetBoundary,
    throwOnError,
    query,
    suspense
  }) => {
    return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || (0, _tanstackQueryCore.shouldThrowError)(throwOnError, [result.error, query]));
  };
},1317,[11,1286],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/errorBoundaryUtils.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "defaultThrowOnError", {
    enumerable: true,
    get: function () {
      return defaultThrowOnError;
    }
  });
  Object.defineProperty(exports, "ensureSuspenseTimers", {
    enumerable: true,
    get: function () {
      return ensureSuspenseTimers;
    }
  });
  Object.defineProperty(exports, "fetchOptimistic", {
    enumerable: true,
    get: function () {
      return fetchOptimistic;
    }
  });
  Object.defineProperty(exports, "shouldSuspend", {
    enumerable: true,
    get: function () {
      return shouldSuspend;
    }
  });
  Object.defineProperty(exports, "willFetch", {
    enumerable: true,
    get: function () {
      return willFetch;
    }
  });
  // src/suspense.ts
  var defaultThrowOnError = (_error, query) => query.state.data === void 0;
  var ensureSuspenseTimers = defaultedOptions => {
    if (defaultedOptions.suspense) {
      const MIN_SUSPENSE_TIME_MS = 1e3;
      const clamp = value => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
      const originalStaleTime = defaultedOptions.staleTime;
      defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
      if (typeof defaultedOptions.gcTime === "number") {
        defaultedOptions.gcTime = Math.max(defaultedOptions.gcTime, MIN_SUSPENSE_TIME_MS);
      }
    }
  };
  var willFetch = (result, isRestoring) => result.isLoading && result.isFetching && !isRestoring;
  var shouldSuspend = (defaultedOptions, result) => defaultedOptions?.suspense && result.isPending;
  var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
    errorResetBoundary.clearReset();
  });
},1318,[],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/suspense.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/useQuery.ts
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "useQuery", {
    enumerable: true,
    get: function () {
      return useQuery;
    }
  });
  var _tanstackQueryCore = require(_dependencyMap[0], "@tanstack/query-core");
  var _useBaseQueryJs = require(_dependencyMap[1], "./useBaseQuery.js");
  function useQuery(options, queryClient) {
    return (0, _useBaseQueryJs.useBaseQuery)(options, _tanstackQueryCore.QueryObserver, queryClient);
  }
},1319,[1286,1320],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/useQuery.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/useBaseQuery.ts
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "useBaseQuery", {
    enumerable: true,
    get: function () {
      return useBaseQuery;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  var _tanstackQueryCore = require(_dependencyMap[1], "@tanstack/query-core");
  var _QueryClientProviderJs = require(_dependencyMap[2], "./QueryClientProvider.js");
  var _QueryErrorResetBoundaryJs = require(_dependencyMap[3], "./QueryErrorResetBoundary.js");
  var _errorBoundaryUtilsJs = require(_dependencyMap[4], "./errorBoundaryUtils.js");
  var _IsRestoringProviderJs = require(_dependencyMap[5], "./IsRestoringProvider.js");
  var _suspenseJs = require(_dependencyMap[6], "./suspense.js");
  function useBaseQuery(options, Observer, queryClient) {
    if (process.env.NODE_ENV !== "production") {
      if (typeof options !== "object" || Array.isArray(options)) {
        throw new Error('Bad argument type. Starting with v5, only the "Object" form is allowed when calling query related functions. Please use the error stack to find the culprit call. More info here: https://tanstack.com/query/latest/docs/react/guides/migrating-to-v5#supports-a-single-signature-one-object');
      }
    }
    const isRestoring = (0, _IsRestoringProviderJs.useIsRestoring)();
    const errorResetBoundary = (0, _QueryErrorResetBoundaryJs.useQueryErrorResetBoundary)();
    const client = (0, _QueryClientProviderJs.useQueryClient)(queryClient);
    const defaultedOptions = client.defaultQueryOptions(options);
    client.getDefaultOptions().queries?._experimental_beforeQuery?.(defaultedOptions);
    const query = client.getQueryCache().get(defaultedOptions.queryHash);
    if (process.env.NODE_ENV !== "production") {
      if (!defaultedOptions.queryFn) {
        console.error(`[${defaultedOptions.queryHash}]: No queryFn was passed as an option, and no default queryFn was found. The queryFn parameter is only optional when using a default queryFn. More info here: https://tanstack.com/query/latest/docs/framework/react/guides/default-query-function`);
      }
    }
    defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : "optimistic";
    (0, _suspenseJs.ensureSuspenseTimers)(defaultedOptions);
    (0, _errorBoundaryUtilsJs.ensurePreventErrorBoundaryRetry)(defaultedOptions, errorResetBoundary, query);
    (0, _errorBoundaryUtilsJs.useClearResetErrorBoundary)(errorResetBoundary);
    const isNewCacheEntry = !client.getQueryCache().get(defaultedOptions.queryHash);
    const [observer] = React.useState(() => new Observer(client, defaultedOptions));
    const result = observer.getOptimisticResult(defaultedOptions);
    const shouldSubscribe = !isRestoring && options.subscribed !== false;
    React.useSyncExternalStore(React.useCallback(onStoreChange => {
      const unsubscribe = shouldSubscribe ? observer.subscribe(_tanstackQueryCore.notifyManager.batchCalls(onStoreChange)) : _tanstackQueryCore.noop;
      observer.updateResult();
      return unsubscribe;
    }, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
    React.useEffect(() => {
      observer.setOptions(defaultedOptions);
    }, [defaultedOptions, observer]);
    if ((0, _suspenseJs.shouldSuspend)(defaultedOptions, result)) {
      throw (0, _suspenseJs.fetchOptimistic)(defaultedOptions, observer, errorResetBoundary);
    }
    if ((0, _errorBoundaryUtilsJs.getHasError)({
      result,
      errorResetBoundary,
      throwOnError: defaultedOptions.throwOnError,
      query,
      suspense: defaultedOptions.suspense
    })) {
      throw result.error;
    }
    ;
    client.getDefaultOptions().queries?._experimental_afterQuery?.(defaultedOptions, result);
    if (defaultedOptions.experimental_prefetchInRender && !_tanstackQueryCore.environmentManager.isServer() && (0, _suspenseJs.willFetch)(result, isRestoring)) {
      const promise = isNewCacheEntry ?
      // Fetch immediately on render in order to ensure `.promise` is resolved even if the component is unmounted
      (0, _suspenseJs.fetchOptimistic)(defaultedOptions, observer, errorResetBoundary) :
      // subscribe to the "cache promise" so that we can finalize the currentThenable once data comes in
      query?.promise;
      promise?.catch(_tanstackQueryCore.noop).finally(() => {
        observer.updateResult();
      });
    }
    return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
  }
},1320,[11,1286,1314,1316,1317,1315,1318],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/useBaseQuery.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/useSuspenseQuery.ts
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "useSuspenseQuery", {
    enumerable: true,
    get: function () {
      return useSuspenseQuery;
    }
  });
  var _tanstackQueryCore = require(_dependencyMap[0], "@tanstack/query-core");
  var _useBaseQueryJs = require(_dependencyMap[1], "./useBaseQuery.js");
  var _suspenseJs = require(_dependencyMap[2], "./suspense.js");
  function useSuspenseQuery(options, queryClient) {
    if (process.env.NODE_ENV !== "production") {
      if (options.queryFn === _tanstackQueryCore.skipToken) {
        console.error("skipToken is not allowed for useSuspenseQuery");
      }
    }
    return (0, _useBaseQueryJs.useBaseQuery)({
      ...options,
      enabled: true,
      suspense: true,
      throwOnError: _suspenseJs.defaultThrowOnError,
      placeholderData: void 0
    }, _tanstackQueryCore.QueryObserver, queryClient);
  }
},1321,[1286,1320,1318],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/useSuspenseQuery.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/useSuspenseInfiniteQuery.ts
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "useSuspenseInfiniteQuery", {
    enumerable: true,
    get: function () {
      return useSuspenseInfiniteQuery;
    }
  });
  var _tanstackQueryCore = require(_dependencyMap[0], "@tanstack/query-core");
  var _useBaseQueryJs = require(_dependencyMap[1], "./useBaseQuery.js");
  var _suspenseJs = require(_dependencyMap[2], "./suspense.js");
  function useSuspenseInfiniteQuery(options, queryClient) {
    if (process.env.NODE_ENV !== "production") {
      if (options.queryFn === _tanstackQueryCore.skipToken) {
        console.error("skipToken is not allowed for useSuspenseInfiniteQuery");
      }
    }
    return (0, _useBaseQueryJs.useBaseQuery)({
      ...options,
      enabled: true,
      suspense: true,
      throwOnError: _suspenseJs.defaultThrowOnError
    }, _tanstackQueryCore.InfiniteQueryObserver, queryClient);
  }
},1322,[1286,1320,1318],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/useSuspenseInfiniteQuery.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/useSuspenseQueries.ts
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "useSuspenseQueries", {
    enumerable: true,
    get: function () {
      return useSuspenseQueries;
    }
  });
  var _tanstackQueryCore = require(_dependencyMap[0], "@tanstack/query-core");
  var _useQueriesJs = require(_dependencyMap[1], "./useQueries.js");
  var _suspenseJs = require(_dependencyMap[2], "./suspense.js");
  function useSuspenseQueries(options, queryClient) {
    return (0, _useQueriesJs.useQueries)({
      ...options,
      queries: options.queries.map(query => {
        if (process.env.NODE_ENV !== "production") {
          if (query.queryFn === _tanstackQueryCore.skipToken) {
            console.error("skipToken is not allowed for useSuspenseQueries");
          }
        }
        return {
          ...query,
          suspense: true,
          throwOnError: _suspenseJs.defaultThrowOnError,
          enabled: true,
          placeholderData: void 0
        };
      })
    }, queryClient);
  }
},1323,[1286,1313,1318],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/useSuspenseQueries.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "usePrefetchQuery", {
    enumerable: true,
    get: function () {
      return usePrefetchQuery;
    }
  });
  var _QueryClientProviderJs = require(_dependencyMap[0], "./QueryClientProvider.js");
  // src/usePrefetchQuery.tsx

  function usePrefetchQuery(options, queryClient) {
    const client = (0, _QueryClientProviderJs.useQueryClient)(queryClient);
    if (!client.getQueryState(options.queryKey)) {
      client.prefetchQuery(options);
    }
  }
},1324,[1314],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/usePrefetchQuery.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "usePrefetchInfiniteQuery", {
    enumerable: true,
    get: function () {
      return usePrefetchInfiniteQuery;
    }
  });
  var _QueryClientProviderJs = require(_dependencyMap[0], "./QueryClientProvider.js");
  // src/usePrefetchInfiniteQuery.tsx

  function usePrefetchInfiniteQuery(options, queryClient) {
    const client = (0, _QueryClientProviderJs.useQueryClient)(queryClient);
    if (!client.getQueryState(options.queryKey)) {
      client.prefetchInfiniteQuery(options);
    }
  }
},1325,[1314],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/usePrefetchInfiniteQuery.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "queryOptions", {
    enumerable: true,
    get: function () {
      return queryOptions;
    }
  });
  // src/queryOptions.ts
  function queryOptions(options) {
    return options;
  }
},1326,[],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/queryOptions.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "infiniteQueryOptions", {
    enumerable: true,
    get: function () {
      return infiniteQueryOptions;
    }
  });
  // src/infiniteQueryOptions.ts
  function infiniteQueryOptions(options) {
    return options;
  }
},1327,[],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/infiniteQueryOptions.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/HydrationBoundary.tsx
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "HydrationBoundary", {
    enumerable: true,
    get: function () {
      return HydrationBoundary;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  var _tanstackQueryCore = require(_dependencyMap[1], "@tanstack/query-core");
  var _QueryClientProviderJs = require(_dependencyMap[2], "./QueryClientProvider.js");
  var HydrationBoundary = ({
    children,
    options = {},
    state,
    queryClient
  }) => {
    const client = (0, _QueryClientProviderJs.useQueryClient)(queryClient);
    const optionsRef = React.useRef(options);
    React.useEffect(() => {
      optionsRef.current = options;
    });
    const hydrationQueue = React.useMemo(() => {
      if (state) {
        if (typeof state !== "object") {
          return;
        }
        const queryCache = client.getQueryCache();
        const queries = state.queries || [];
        const newQueries = [];
        const existingQueries = [];
        for (const dehydratedQuery of queries) {
          const existingQuery = queryCache.get(dehydratedQuery.queryHash);
          if (!existingQuery) {
            newQueries.push(dehydratedQuery);
          } else {
            const hydrationIsNewer = dehydratedQuery.state.dataUpdatedAt > existingQuery.state.dataUpdatedAt || dehydratedQuery.promise && existingQuery.state.status !== "pending" && existingQuery.state.fetchStatus !== "fetching" && dehydratedQuery.dehydratedAt !== void 0 && dehydratedQuery.dehydratedAt > existingQuery.state.dataUpdatedAt;
            if (hydrationIsNewer) {
              existingQueries.push(dehydratedQuery);
            }
          }
        }
        if (newQueries.length > 0) {
          (0, _tanstackQueryCore.hydrate)(client, {
            queries: newQueries
          }, optionsRef.current);
        }
        if (existingQueries.length > 0) {
          return existingQueries;
        }
      }
      return void 0;
    }, [client, state]);
    React.useEffect(() => {
      if (hydrationQueue) {
        (0, _tanstackQueryCore.hydrate)(client, {
          queries: hydrationQueue
        }, optionsRef.current);
      }
    }, [client, hydrationQueue]);
    return children;
  };
},1328,[11,1286,1314],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/HydrationBoundary.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/useIsFetching.ts
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "useIsFetching", {
    enumerable: true,
    get: function () {
      return useIsFetching;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  var _tanstackQueryCore = require(_dependencyMap[1], "@tanstack/query-core");
  var _QueryClientProviderJs = require(_dependencyMap[2], "./QueryClientProvider.js");
  function useIsFetching(filters, queryClient) {
    const client = (0, _QueryClientProviderJs.useQueryClient)(queryClient);
    const queryCache = client.getQueryCache();
    return React.useSyncExternalStore(React.useCallback(onStoreChange => queryCache.subscribe(_tanstackQueryCore.notifyManager.batchCalls(onStoreChange)), [queryCache]), () => client.isFetching(filters), () => client.isFetching(filters));
  }
},1329,[11,1286,1314],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/useIsFetching.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/useMutationState.ts
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "useIsMutating", {
    enumerable: true,
    get: function () {
      return useIsMutating;
    }
  });
  Object.defineProperty(exports, "useMutationState", {
    enumerable: true,
    get: function () {
      return useMutationState;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  var _tanstackQueryCore = require(_dependencyMap[1], "@tanstack/query-core");
  var _QueryClientProviderJs = require(_dependencyMap[2], "./QueryClientProvider.js");
  function useIsMutating(filters, queryClient) {
    const client = (0, _QueryClientProviderJs.useQueryClient)(queryClient);
    return useMutationState({
      filters: {
        ...filters,
        status: "pending"
      }
    }, client).length;
  }
  function getResult(mutationCache, options) {
    return mutationCache.findAll(options.filters).map(mutation => options.select ? options.select(mutation) : mutation.state);
  }
  function useMutationState(options = {}, queryClient) {
    const mutationCache = (0, _QueryClientProviderJs.useQueryClient)(queryClient).getMutationCache();
    const optionsRef = React.useRef(options);
    const result = React.useRef(null);
    if (result.current === null) {
      result.current = getResult(mutationCache, options);
    }
    React.useEffect(() => {
      optionsRef.current = options;
    });
    return React.useSyncExternalStore(React.useCallback(onStoreChange => mutationCache.subscribe(() => {
      const nextResult = (0, _tanstackQueryCore.replaceEqualDeep)(result.current, getResult(mutationCache, optionsRef.current));
      if (result.current !== nextResult) {
        result.current = nextResult;
        _tanstackQueryCore.notifyManager.schedule(onStoreChange);
      }
    }), [mutationCache]), () => result.current, () => result.current);
  }
},1330,[11,1286,1314],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/useMutationState.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/useMutation.ts
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "useMutation", {
    enumerable: true,
    get: function () {
      return useMutation;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopNamespace(_react);
  var _tanstackQueryCore = require(_dependencyMap[1], "@tanstack/query-core");
  var _QueryClientProviderJs = require(_dependencyMap[2], "./QueryClientProvider.js");
  function useMutation(options, queryClient) {
    const client = (0, _QueryClientProviderJs.useQueryClient)(queryClient);
    const [observer] = React.useState(() => new _tanstackQueryCore.MutationObserver(client, options));
    React.useEffect(() => {
      observer.setOptions(options);
    }, [observer, options]);
    const result = React.useSyncExternalStore(React.useCallback(onStoreChange => observer.subscribe(_tanstackQueryCore.notifyManager.batchCalls(onStoreChange)), [observer]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
    const mutate = React.useCallback((variables, mutateOptions) => {
      observer.mutate(variables, mutateOptions).catch(_tanstackQueryCore.noop);
    }, [observer]);
    if (result.error && (0, _tanstackQueryCore.shouldThrowError)(observer.options.throwOnError, [result.error])) {
      throw result.error;
    }
    return {
      ...result,
      mutate,
      mutateAsync: result.mutate
    };
  }
},1331,[11,1286,1314],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/useMutation.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "mutationOptions", {
    enumerable: true,
    get: function () {
      return mutationOptions;
    }
  });
  // src/mutationOptions.ts
  function mutationOptions(options) {
    return options;
  }
},1332,[],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/mutationOptions.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use client";

  // src/useInfiniteQuery.ts
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "useInfiniteQuery", {
    enumerable: true,
    get: function () {
      return useInfiniteQuery;
    }
  });
  var _tanstackQueryCore = require(_dependencyMap[0], "@tanstack/query-core");
  var _useBaseQueryJs = require(_dependencyMap[1], "./useBaseQuery.js");
  function useInfiniteQuery(options, queryClient) {
    return (0, _useBaseQueryJs.useBaseQuery)(options, _tanstackQueryCore.InfiniteQueryObserver, queryClient);
  }
},1333,[1286,1320],"node_modules/.pnpm/@tanstack+react-query@5.100.6_react@19.2.0/node_modules/@tanstack/react-query/build/modern/useInfiniteQuery.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "queryClient", {
    enumerable: true,
    get: function () {
      return queryClient;
    }
  });
  var _tanstackReactQuery = require(_dependencyMap[0], "@tanstack/react-query");
  const queryClient = new _tanstackReactQuery.QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 5 * 60 * 1000,
        // 5 minutes
        gcTime: 10 * 60 * 1000 // 10 minutes
      }
    }
  });
},1524,[1285],"src/services/queryClient.ts");
//# sourceMappingURL=http://127.0.0.1:8095/src/services/queryClient.map?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable&modulesOnly=true&runModule=false