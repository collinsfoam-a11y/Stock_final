__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _vendorEmitterEventEmitter = require(_dependencyMap[0], "../vendor/emitter/EventEmitter");
  var EventEmitter = _interopDefault(_vendorEmitterEventEmitter);
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   * @format
   */

  // FIXME: use typed events

  /**
   * Global EventEmitter used by the native platform to emit events to JavaScript.
   * Events are identified by globally unique event names.
   *
   * NativeModules that emit events should instead subclass `NativeEventEmitter`.
   */
  var _default = new EventEmitter.default();
},5,[6],"node_modules/.pnpm/react-native-web@0.21.2_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/react-native-web/dist/vendor/react-native/EventEmitter/RCTDeviceEventEmitter.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return EventEmitter;
    }
  });
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   * @format
   */

  /**
   * EventEmitter manages listeners and publishes events to them.
   *
   * EventEmitter accepts a single type parameter that defines the valid events
   * and associated listener argument(s).
   *
   * @example
   *
   *   const emitter = new EventEmitter<{
   *     success: [number, string],
   *     error: [Error],
   *   }>();
   *
   *   emitter.on('success', (statusCode, responseText) => {...});
   *   emitter.emit('success', 200, '...');
   *
   *   emitter.on('error', error => {...});
   *   emitter.emit('error', new Error('Resource not found'));
   *
   */
  class EventEmitter {
    constructor() {
      this._registry = {};
    }
    /**
     * Registers a listener that is called when the supplied event is emitted.
     * Returns a subscription that has a `remove` method to undo registration.
     */
    addListener(eventType, listener, context) {
      var registrations = allocate(this._registry, eventType);
      var registration = {
        context,
        listener,
        remove() {
          registrations.delete(registration);
        }
      };
      registrations.add(registration);
      return registration;
    }

    /**
     * Emits the supplied event. Additional arguments supplied to `emit` will be
     * passed through to each of the registered listeners.
     *
     * If a listener modifies the listeners registered for the same event, those
     * changes will not be reflected in the current invocation of `emit`.
     */
    emit(eventType) {
      var registrations = this._registry[eventType];
      if (registrations != null) {
        for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
          args[_key - 1] = arguments[_key];
        }
        for (var _i = 0, _arr = [...registrations]; _i < _arr.length; _i++) {
          var registration = _arr[_i];
          registration.listener.apply(registration.context, args);
        }
      }
    }

    /**
     * Removes all registered listeners.
     */
    removeAllListeners(eventType) {
      if (eventType == null) {
        this._registry = {};
      } else {
        delete this._registry[eventType];
      }
    }

    /**
     * Returns the number of registered listeners for the supplied event.
     */
    listenerCount(eventType) {
      var registrations = this._registry[eventType];
      return registrations == null ? 0 : registrations.size;
    }
  }
  function allocate(registry, eventType) {
    var registrations = registry[eventType];
    if (registrations == null) {
      registrations = new Set();
      registry[eventType] = registrations;
    }
    return registrations;
  }
},6,[],"node_modules/.pnpm/react-native-web@0.21.2_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/react-native-web/dist/vendor/react-native/vendor/emitter/EventEmitter.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  'use strict';

  if (process.env.NODE_ENV === 'production') {
    module.exports = require(_dependencyMap[0], "./cjs/react.production.js");
  } else {
    module.exports = require(_dependencyMap[1], "./cjs/react.development.js");
  }
},11,[12,13],"node_modules/.pnpm/react@19.2.0/node_modules/react/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";
},12,[],"node_modules/.pnpm/metro-runtime@0.83.7/node_modules/metro-runtime/src/modules/empty-module.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * @license React
   * react.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */

  "use strict";

  "production" !== process.env.NODE_ENV && function () {
    function defineDeprecationWarning(methodName, info) {
      Object.defineProperty(Component.prototype, methodName, {
        get: function () {
          console.warn("%s(...) is deprecated in plain JavaScript React classes. %s", info[0], info[1]);
        }
      });
    }
    function getIteratorFn(maybeIterable) {
      if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
      maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
      return "function" === typeof maybeIterable ? maybeIterable : null;
    }
    function warnNoop(publicInstance, callerName) {
      publicInstance = (publicInstance = publicInstance.constructor) && (publicInstance.displayName || publicInstance.name) || "ReactClass";
      var warningKey = publicInstance + "." + callerName;
      didWarnStateUpdateForUnmountedComponent[warningKey] || (console.error("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", callerName, publicInstance), didWarnStateUpdateForUnmountedComponent[warningKey] = !0);
    }
    function Component(props, context, updater) {
      this.props = props;
      this.context = context;
      this.refs = emptyObject;
      this.updater = updater || ReactNoopUpdateQueue;
    }
    function ComponentDummy() {}
    function PureComponent(props, context, updater) {
      this.props = props;
      this.context = context;
      this.refs = emptyObject;
      this.updater = updater || ReactNoopUpdateQueue;
    }
    function noop() {}
    function testStringCoercion(value) {
      return "" + value;
    }
    function checkKeyStringCoercion(value) {
      try {
        testStringCoercion(value);
        var JSCompiler_inline_result = !1;
      } catch (e) {
        JSCompiler_inline_result = !0;
      }
      if (JSCompiler_inline_result) {
        JSCompiler_inline_result = console;
        var JSCompiler_temp_const = JSCompiler_inline_result.error;
        var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
        JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
        return testStringCoercion(value);
      }
    }
    function getComponentNameFromType(type) {
      if (null == type) return null;
      if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE ? null : type.displayName || type.name || null;
      if ("string" === typeof type) return type;
      switch (type) {
        case REACT_FRAGMENT_TYPE:
          return "Fragment";
        case REACT_PROFILER_TYPE:
          return "Profiler";
        case REACT_STRICT_MODE_TYPE:
          return "StrictMode";
        case REACT_SUSPENSE_TYPE:
          return "Suspense";
        case REACT_SUSPENSE_LIST_TYPE:
          return "SuspenseList";
        case REACT_ACTIVITY_TYPE:
          return "Activity";
      }
      if ("object" === typeof type) switch ("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof) {
        case REACT_PORTAL_TYPE:
          return "Portal";
        case REACT_CONTEXT_TYPE:
          return type.displayName || "Context";
        case REACT_CONSUMER_TYPE:
          return (type._context.displayName || "Context") + ".Consumer";
        case REACT_FORWARD_REF_TYPE:
          var innerType = type.render;
          type = type.displayName;
          type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
          return type;
        case REACT_MEMO_TYPE:
          return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
        case REACT_LAZY_TYPE:
          innerType = type._payload;
          type = type._init;
          try {
            return getComponentNameFromType(type(innerType));
          } catch (x) {}
      }
      return null;
    }
    function getTaskName(type) {
      if (type === REACT_FRAGMENT_TYPE) return "<>";
      if ("object" === typeof type && null !== type && type.$$typeof === REACT_LAZY_TYPE) return "<...>";
      try {
        var name = getComponentNameFromType(type);
        return name ? "<" + name + ">" : "<...>";
      } catch (x) {
        return "<...>";
      }
    }
    function getOwner() {
      var dispatcher = ReactSharedInternals.A;
      return null === dispatcher ? null : dispatcher.getOwner();
    }
    function UnknownOwner() {
      return Error("react-stack-top-frame");
    }
    function hasValidKey(config) {
      if (hasOwnProperty.call(config, "key")) {
        var getter = Object.getOwnPropertyDescriptor(config, "key").get;
        if (getter && getter.isReactWarning) return !1;
      }
      return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
      function warnAboutAccessingKey() {
        specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
      }
      warnAboutAccessingKey.isReactWarning = !0;
      Object.defineProperty(props, "key", {
        get: warnAboutAccessingKey,
        configurable: !0
      });
    }
    function elementRefGetterWithDeprecationWarning() {
      var componentName = getComponentNameFromType(this.type);
      didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
      componentName = this.props.ref;
      return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, props, owner, debugStack, debugTask) {
      var refProp = props.ref;
      type = {
        $$typeof: REACT_ELEMENT_TYPE,
        type: type,
        key: key,
        props: props,
        _owner: owner
      };
      null !== (void 0 !== refProp ? refProp : null) ? Object.defineProperty(type, "ref", {
        enumerable: !1,
        get: elementRefGetterWithDeprecationWarning
      }) : Object.defineProperty(type, "ref", {
        enumerable: !1,
        value: null
      });
      type._store = {};
      Object.defineProperty(type._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: 0
      });
      Object.defineProperty(type, "_debugInfo", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: null
      });
      Object.defineProperty(type, "_debugStack", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: debugStack
      });
      Object.defineProperty(type, "_debugTask", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: debugTask
      });
      Object.freeze && (Object.freeze(type.props), Object.freeze(type));
      return type;
    }
    function cloneAndReplaceKey(oldElement, newKey) {
      newKey = ReactElement(oldElement.type, newKey, oldElement.props, oldElement._owner, oldElement._debugStack, oldElement._debugTask);
      oldElement._store && (newKey._store.validated = oldElement._store.validated);
      return newKey;
    }
    function validateChildKeys(node) {
      isValidElement(node) ? node._store && (node._store.validated = 1) : "object" === typeof node && null !== node && node.$$typeof === REACT_LAZY_TYPE && ("fulfilled" === node._payload.status ? isValidElement(node._payload.value) && node._payload.value._store && (node._payload.value._store.validated = 1) : node._store && (node._store.validated = 1));
    }
    function isValidElement(object) {
      return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    function escape(key) {
      var escaperLookup = {
        "=": "=0",
        ":": "=2"
      };
      return "$" + key.replace(/[=:]/g, function (match) {
        return escaperLookup[match];
      });
    }
    function getElementKey(element, index) {
      return "object" === typeof element && null !== element && null != element.key ? (checkKeyStringCoercion(element.key), escape("" + element.key)) : index.toString(36);
    }
    function resolveThenable(thenable) {
      switch (thenable.status) {
        case "fulfilled":
          return thenable.value;
        case "rejected":
          throw thenable.reason;
        default:
          switch ("string" === typeof thenable.status ? thenable.then(noop, noop) : (thenable.status = "pending", thenable.then(function (fulfilledValue) {
            "pending" === thenable.status && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
          }, function (error) {
            "pending" === thenable.status && (thenable.status = "rejected", thenable.reason = error);
          })), thenable.status) {
            case "fulfilled":
              return thenable.value;
            case "rejected":
              throw thenable.reason;
          }
      }
      throw thenable;
    }
    function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
      var type = typeof children;
      if ("undefined" === type || "boolean" === type) children = null;
      var invokeCallback = !1;
      if (null === children) invokeCallback = !0;else switch (type) {
        case "bigint":
        case "string":
        case "number":
          invokeCallback = !0;
          break;
        case "object":
          switch (children.$$typeof) {
            case REACT_ELEMENT_TYPE:
            case REACT_PORTAL_TYPE:
              invokeCallback = !0;
              break;
            case REACT_LAZY_TYPE:
              return invokeCallback = children._init, mapIntoArray(invokeCallback(children._payload), array, escapedPrefix, nameSoFar, callback);
          }
      }
      if (invokeCallback) {
        invokeCallback = children;
        callback = callback(invokeCallback);
        var childKey = "" === nameSoFar ? "." + getElementKey(invokeCallback, 0) : nameSoFar;
        isArrayImpl(callback) ? (escapedPrefix = "", null != childKey && (escapedPrefix = childKey.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function (c) {
          return c;
        })) : null != callback && (isValidElement(callback) && (null != callback.key && (invokeCallback && invokeCallback.key === callback.key || checkKeyStringCoercion(callback.key)), escapedPrefix = cloneAndReplaceKey(callback, escapedPrefix + (null == callback.key || invokeCallback && invokeCallback.key === callback.key ? "" : ("" + callback.key).replace(userProvidedKeyEscapeRegex, "$&/") + "/") + childKey), "" !== nameSoFar && null != invokeCallback && isValidElement(invokeCallback) && null == invokeCallback.key && invokeCallback._store && !invokeCallback._store.validated && (escapedPrefix._store.validated = 2), callback = escapedPrefix), array.push(callback));
        return 1;
      }
      invokeCallback = 0;
      childKey = "" === nameSoFar ? "." : nameSoFar + ":";
      if (isArrayImpl(children)) for (var i = 0; i < children.length; i++) nameSoFar = children[i], type = childKey + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);else if (i = getIteratorFn(children), "function" === typeof i) for (i === children.entries && (didWarnAboutMaps || console.warn("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), didWarnAboutMaps = !0), children = i.call(children), i = 0; !(nameSoFar = children.next()).done;) nameSoFar = nameSoFar.value, type = childKey + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);else if ("object" === type) {
        if ("function" === typeof children.then) return mapIntoArray(resolveThenable(children), array, escapedPrefix, nameSoFar, callback);
        array = String(children);
        throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === array ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead.");
      }
      return invokeCallback;
    }
    function mapChildren(children, func, context) {
      if (null == children) return children;
      var result = [],
        count = 0;
      mapIntoArray(children, result, "", "", function (child) {
        return func.call(context, child, count++);
      });
      return result;
    }
    function lazyInitializer(payload) {
      if (-1 === payload._status) {
        var ioInfo = payload._ioInfo;
        null != ioInfo && (ioInfo.start = ioInfo.end = performance.now());
        ioInfo = payload._result;
        var thenable = ioInfo();
        thenable.then(function (moduleObject) {
          if (0 === payload._status || -1 === payload._status) {
            payload._status = 1;
            payload._result = moduleObject;
            var _ioInfo = payload._ioInfo;
            null != _ioInfo && (_ioInfo.end = performance.now());
            void 0 === thenable.status && (thenable.status = "fulfilled", thenable.value = moduleObject);
          }
        }, function (error) {
          if (0 === payload._status || -1 === payload._status) {
            payload._status = 2;
            payload._result = error;
            var _ioInfo2 = payload._ioInfo;
            null != _ioInfo2 && (_ioInfo2.end = performance.now());
            void 0 === thenable.status && (thenable.status = "rejected", thenable.reason = error);
          }
        });
        ioInfo = payload._ioInfo;
        if (null != ioInfo) {
          ioInfo.value = thenable;
          var displayName = thenable.displayName;
          "string" === typeof displayName && (ioInfo.name = displayName);
        }
        -1 === payload._status && (payload._status = 0, payload._result = thenable);
      }
      if (1 === payload._status) return ioInfo = payload._result, void 0 === ioInfo && console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))\n\nDid you accidentally put curly braces around the import?", ioInfo), "default" in ioInfo || console.error("lazy: Expected the result of a dynamic import() call. Instead received: %s\n\nYour code should look like: \n  const MyComponent = lazy(() => import('./MyComponent'))", ioInfo), ioInfo.default;
      throw payload._result;
    }
    function resolveDispatcher() {
      var dispatcher = ReactSharedInternals.H;
      null === dispatcher && console.error("Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:\n1. You might have mismatching versions of React and the renderer (such as React DOM)\n2. You might be breaking the Rules of Hooks\n3. You might have more than one copy of React in the same app\nSee https://react.dev/link/invalid-hook-call for tips about how to debug and fix this problem.");
      return dispatcher;
    }
    function releaseAsyncTransition() {
      ReactSharedInternals.asyncTransitions--;
    }
    function enqueueTask(task) {
      if (null === enqueueTaskImpl) try {
        var requireString = ("require" + Math.random()).slice(0, 7);
        enqueueTaskImpl = (module && module[requireString]).call(module, "timers").setImmediate;
      } catch (_err) {
        enqueueTaskImpl = function (callback) {
          !1 === didWarnAboutMessageChannel && (didWarnAboutMessageChannel = !0, "undefined" === typeof MessageChannel && console.error("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));
          var channel = new MessageChannel();
          channel.port1.onmessage = callback;
          channel.port2.postMessage(void 0);
        };
      }
      return enqueueTaskImpl(task);
    }
    function aggregateErrors(errors) {
      return 1 < errors.length && "function" === typeof AggregateError ? new AggregateError(errors) : errors[0];
    }
    function popActScope(prevActQueue, prevActScopeDepth) {
      prevActScopeDepth !== actScopeDepth - 1 && console.error("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. ");
      actScopeDepth = prevActScopeDepth;
    }
    function recursivelyFlushAsyncActWork(returnValue, resolve, reject) {
      var queue = ReactSharedInternals.actQueue;
      if (null !== queue) if (0 !== queue.length) try {
        flushActQueue(queue);
        enqueueTask(function () {
          return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
        });
        return;
      } catch (error) {
        ReactSharedInternals.thrownErrors.push(error);
      } else ReactSharedInternals.actQueue = null;
      0 < ReactSharedInternals.thrownErrors.length ? (queue = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(queue)) : resolve(returnValue);
    }
    function flushActQueue(queue) {
      if (!isFlushing) {
        isFlushing = !0;
        var i = 0;
        try {
          for (; i < queue.length; i++) {
            var callback = queue[i];
            do {
              ReactSharedInternals.didUsePromise = !1;
              var continuation = callback(!1);
              if (null !== continuation) {
                if (ReactSharedInternals.didUsePromise) {
                  queue[i] = callback;
                  queue.splice(0, i);
                  return;
                }
                callback = continuation;
              } else break;
            } while (1);
          }
          queue.length = 0;
        } catch (error) {
          queue.splice(0, i + 1), ReactSharedInternals.thrownErrors.push(error);
        } finally {
          isFlushing = !1;
        }
      }
    }
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
    var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"),
      REACT_PORTAL_TYPE = Symbol.for("react.portal"),
      REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"),
      REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"),
      REACT_PROFILER_TYPE = Symbol.for("react.profiler"),
      REACT_CONSUMER_TYPE = Symbol.for("react.consumer"),
      REACT_CONTEXT_TYPE = Symbol.for("react.context"),
      REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"),
      REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"),
      REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"),
      REACT_MEMO_TYPE = Symbol.for("react.memo"),
      REACT_LAZY_TYPE = Symbol.for("react.lazy"),
      REACT_ACTIVITY_TYPE = Symbol.for("react.activity"),
      MAYBE_ITERATOR_SYMBOL = Symbol.iterator,
      didWarnStateUpdateForUnmountedComponent = {},
      ReactNoopUpdateQueue = {
        isMounted: function () {
          return !1;
        },
        enqueueForceUpdate: function (publicInstance) {
          warnNoop(publicInstance, "forceUpdate");
        },
        enqueueReplaceState: function (publicInstance) {
          warnNoop(publicInstance, "replaceState");
        },
        enqueueSetState: function (publicInstance) {
          warnNoop(publicInstance, "setState");
        }
      },
      assign = Object.assign,
      emptyObject = {};
    Object.freeze(emptyObject);
    Component.prototype.isReactComponent = {};
    Component.prototype.setState = function (partialState, callback) {
      if ("object" !== typeof partialState && "function" !== typeof partialState && null != partialState) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, partialState, callback, "setState");
    };
    Component.prototype.forceUpdate = function (callback) {
      this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
    };
    var deprecatedAPIs = {
      isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
      replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
    };
    for (fnName in deprecatedAPIs) deprecatedAPIs.hasOwnProperty(fnName) && defineDeprecationWarning(fnName, deprecatedAPIs[fnName]);
    ComponentDummy.prototype = Component.prototype;
    deprecatedAPIs = PureComponent.prototype = new ComponentDummy();
    deprecatedAPIs.constructor = PureComponent;
    assign(deprecatedAPIs, Component.prototype);
    deprecatedAPIs.isPureReactComponent = !0;
    var isArrayImpl = Array.isArray,
      REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"),
      ReactSharedInternals = {
        H: null,
        A: null,
        T: null,
        S: null,
        actQueue: null,
        asyncTransitions: 0,
        isBatchingLegacy: !1,
        didScheduleLegacyUpdate: !1,
        didUsePromise: !1,
        thrownErrors: [],
        getCurrentStack: null,
        recentlyCreatedOwnerStacks: 0
      },
      hasOwnProperty = Object.prototype.hasOwnProperty,
      createTask = console.createTask ? console.createTask : function () {
        return null;
      };
    deprecatedAPIs = {
      react_stack_bottom_frame: function (callStackForError) {
        return callStackForError();
      }
    };
    var specialPropKeyWarningShown, didWarnAboutOldJSXRuntime;
    var didWarnAboutElementRef = {};
    var unknownOwnerDebugStack = deprecatedAPIs.react_stack_bottom_frame.bind(deprecatedAPIs, UnknownOwner)();
    var unknownOwnerDebugTask = createTask(getTaskName(UnknownOwner));
    var didWarnAboutMaps = !1,
      userProvidedKeyEscapeRegex = /\/+/g,
      reportGlobalError = "function" === typeof reportError ? reportError : function (error) {
        if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
          var event = new window.ErrorEvent("error", {
            bubbles: !0,
            cancelable: !0,
            message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
            error: error
          });
          if (!window.dispatchEvent(event)) return;
        } else if ("object" === typeof process && "function" === typeof process.emit) {
          process.emit("uncaughtException", error);
          return;
        }
        console.error(error);
      },
      didWarnAboutMessageChannel = !1,
      enqueueTaskImpl = null,
      actScopeDepth = 0,
      didWarnNoAwaitAct = !1,
      isFlushing = !1,
      queueSeveralMicrotasks = "function" === typeof queueMicrotask ? function (callback) {
        queueMicrotask(function () {
          return queueMicrotask(callback);
        });
      } : enqueueTask;
    deprecatedAPIs = Object.freeze({
      __proto__: null,
      c: function (size) {
        return resolveDispatcher().useMemoCache(size);
      }
    });
    var fnName = {
      map: mapChildren,
      forEach: function (children, forEachFunc, forEachContext) {
        mapChildren(children, function () {
          forEachFunc.apply(this, arguments);
        }, forEachContext);
      },
      count: function (children) {
        var n = 0;
        mapChildren(children, function () {
          n++;
        });
        return n;
      },
      toArray: function (children) {
        return mapChildren(children, function (child) {
          return child;
        }) || [];
      },
      only: function (children) {
        if (!isValidElement(children)) throw Error("React.Children.only expected to receive a single React element child.");
        return children;
      }
    };
    exports.Activity = REACT_ACTIVITY_TYPE;
    exports.Children = fnName;
    exports.Component = Component;
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.Profiler = REACT_PROFILER_TYPE;
    exports.PureComponent = PureComponent;
    exports.StrictMode = REACT_STRICT_MODE_TYPE;
    exports.Suspense = REACT_SUSPENSE_TYPE;
    exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
    exports.__COMPILER_RUNTIME = deprecatedAPIs;
    exports.act = function (callback) {
      var prevActQueue = ReactSharedInternals.actQueue,
        prevActScopeDepth = actScopeDepth;
      actScopeDepth++;
      var queue = ReactSharedInternals.actQueue = null !== prevActQueue ? prevActQueue : [],
        didAwaitActCall = !1;
      try {
        var result = callback();
      } catch (error) {
        ReactSharedInternals.thrownErrors.push(error);
      }
      if (0 < ReactSharedInternals.thrownErrors.length) throw popActScope(prevActQueue, prevActScopeDepth), callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
      if (null !== result && "object" === typeof result && "function" === typeof result.then) {
        var thenable = result;
        queueSeveralMicrotasks(function () {
          didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"));
        });
        return {
          then: function (resolve, reject) {
            didAwaitActCall = !0;
            thenable.then(function (returnValue) {
              popActScope(prevActQueue, prevActScopeDepth);
              if (0 === prevActScopeDepth) {
                try {
                  flushActQueue(queue), enqueueTask(function () {
                    return recursivelyFlushAsyncActWork(returnValue, resolve, reject);
                  });
                } catch (error$0) {
                  ReactSharedInternals.thrownErrors.push(error$0);
                }
                if (0 < ReactSharedInternals.thrownErrors.length) {
                  var _thrownError = aggregateErrors(ReactSharedInternals.thrownErrors);
                  ReactSharedInternals.thrownErrors.length = 0;
                  reject(_thrownError);
                }
              } else resolve(returnValue);
            }, function (error) {
              popActScope(prevActQueue, prevActScopeDepth);
              0 < ReactSharedInternals.thrownErrors.length ? (error = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, reject(error)) : reject(error);
            });
          }
        };
      }
      var returnValue$jscomp$0 = result;
      popActScope(prevActQueue, prevActScopeDepth);
      0 === prevActScopeDepth && (flushActQueue(queue), 0 !== queue.length && queueSeveralMicrotasks(function () {
        didAwaitActCall || didWarnNoAwaitAct || (didWarnNoAwaitAct = !0, console.error("A component suspended inside an `act` scope, but the `act` call was not awaited. When testing React components that depend on asynchronous data, you must await the result:\n\nawait act(() => ...)"));
      }), ReactSharedInternals.actQueue = null);
      if (0 < ReactSharedInternals.thrownErrors.length) throw callback = aggregateErrors(ReactSharedInternals.thrownErrors), ReactSharedInternals.thrownErrors.length = 0, callback;
      return {
        then: function (resolve, reject) {
          didAwaitActCall = !0;
          0 === prevActScopeDepth ? (ReactSharedInternals.actQueue = queue, enqueueTask(function () {
            return recursivelyFlushAsyncActWork(returnValue$jscomp$0, resolve, reject);
          })) : resolve(returnValue$jscomp$0);
        }
      };
    };
    exports.cache = function (fn) {
      return function () {
        return fn.apply(null, arguments);
      };
    };
    exports.cacheSignal = function () {
      return null;
    };
    exports.captureOwnerStack = function () {
      var getCurrentStack = ReactSharedInternals.getCurrentStack;
      return null === getCurrentStack ? null : getCurrentStack();
    };
    exports.cloneElement = function (element, config, children) {
      if (null === element || void 0 === element) throw Error("The argument must be a React element, but you passed " + element + ".");
      var props = assign({}, element.props),
        key = element.key,
        owner = element._owner;
      if (null != config) {
        var JSCompiler_inline_result;
        a: {
          if (hasOwnProperty.call(config, "ref") && (JSCompiler_inline_result = Object.getOwnPropertyDescriptor(config, "ref").get) && JSCompiler_inline_result.isReactWarning) {
            JSCompiler_inline_result = !1;
            break a;
          }
          JSCompiler_inline_result = void 0 !== config.ref;
        }
        JSCompiler_inline_result && (owner = getOwner());
        hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key);
        for (propName in config) !hasOwnProperty.call(config, propName) || "key" === propName || "__self" === propName || "__source" === propName || "ref" === propName && void 0 === config.ref || (props[propName] = config[propName]);
      }
      var propName = arguments.length - 2;
      if (1 === propName) props.children = children;else if (1 < propName) {
        JSCompiler_inline_result = Array(propName);
        for (var i = 0; i < propName; i++) JSCompiler_inline_result[i] = arguments[i + 2];
        props.children = JSCompiler_inline_result;
      }
      props = ReactElement(element.type, key, props, owner, element._debugStack, element._debugTask);
      for (key = 2; key < arguments.length; key++) validateChildKeys(arguments[key]);
      return props;
    };
    exports.createContext = function (defaultValue) {
      defaultValue = {
        $$typeof: REACT_CONTEXT_TYPE,
        _currentValue: defaultValue,
        _currentValue2: defaultValue,
        _threadCount: 0,
        Provider: null,
        Consumer: null
      };
      defaultValue.Provider = defaultValue;
      defaultValue.Consumer = {
        $$typeof: REACT_CONSUMER_TYPE,
        _context: defaultValue
      };
      defaultValue._currentRenderer = null;
      defaultValue._currentRenderer2 = null;
      return defaultValue;
    };
    exports.createElement = function (type, config, children) {
      for (var i = 2; i < arguments.length; i++) validateChildKeys(arguments[i]);
      i = {};
      var key = null;
      if (null != config) for (propName in didWarnAboutOldJSXRuntime || !("__self" in config) || "key" in config || (didWarnAboutOldJSXRuntime = !0, console.warn("Your app (or one of its dependencies) is using an outdated JSX transform. Update to the modern JSX transform for faster performance: https://react.dev/link/new-jsx-transform")), hasValidKey(config) && (checkKeyStringCoercion(config.key), key = "" + config.key), config) hasOwnProperty.call(config, propName) && "key" !== propName && "__self" !== propName && "__source" !== propName && (i[propName] = config[propName]);
      var childrenLength = arguments.length - 2;
      if (1 === childrenLength) i.children = children;else if (1 < childrenLength) {
        for (var childArray = Array(childrenLength), _i = 0; _i < childrenLength; _i++) childArray[_i] = arguments[_i + 2];
        Object.freeze && Object.freeze(childArray);
        i.children = childArray;
      }
      if (type && type.defaultProps) for (propName in childrenLength = type.defaultProps, childrenLength) void 0 === i[propName] && (i[propName] = childrenLength[propName]);
      key && defineKeyPropWarningGetter(i, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
      var propName = 1e4 > ReactSharedInternals.recentlyCreatedOwnerStacks++;
      return ReactElement(type, key, i, getOwner(), propName ? Error("react-stack-top-frame") : unknownOwnerDebugStack, propName ? createTask(getTaskName(type)) : unknownOwnerDebugTask);
    };
    exports.createRef = function () {
      var refObject = {
        current: null
      };
      Object.seal(refObject);
      return refObject;
    };
    exports.forwardRef = function (render) {
      null != render && render.$$typeof === REACT_MEMO_TYPE ? console.error("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).") : "function" !== typeof render ? console.error("forwardRef requires a render function but was given %s.", null === render ? "null" : typeof render) : 0 !== render.length && 2 !== render.length && console.error("forwardRef render functions accept exactly two parameters: props and ref. %s", 1 === render.length ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined.");
      null != render && null != render.defaultProps && console.error("forwardRef render functions do not support defaultProps. Did you accidentally pass a React component?");
      var elementType = {
          $$typeof: REACT_FORWARD_REF_TYPE,
          render: render
        },
        ownName;
      Object.defineProperty(elementType, "displayName", {
        enumerable: !1,
        configurable: !0,
        get: function () {
          return ownName;
        },
        set: function (name) {
          ownName = name;
          render.name || render.displayName || (Object.defineProperty(render, "name", {
            value: name
          }), render.displayName = name);
        }
      });
      return elementType;
    };
    exports.isValidElement = isValidElement;
    exports.lazy = function (ctor) {
      ctor = {
        _status: -1,
        _result: ctor
      };
      var lazyType = {
          $$typeof: REACT_LAZY_TYPE,
          _payload: ctor,
          _init: lazyInitializer
        },
        ioInfo = {
          name: "lazy",
          start: -1,
          end: -1,
          value: null,
          owner: null,
          debugStack: Error("react-stack-top-frame"),
          debugTask: console.createTask ? console.createTask("lazy()") : null
        };
      ctor._ioInfo = ioInfo;
      lazyType._debugInfo = [{
        awaited: ioInfo
      }];
      return lazyType;
    };
    exports.memo = function (type, compare) {
      null == type && console.error("memo: The first argument must be a component. Instead received: %s", null === type ? "null" : typeof type);
      compare = {
        $$typeof: REACT_MEMO_TYPE,
        type: type,
        compare: void 0 === compare ? null : compare
      };
      var ownName;
      Object.defineProperty(compare, "displayName", {
        enumerable: !1,
        configurable: !0,
        get: function () {
          return ownName;
        },
        set: function (name) {
          ownName = name;
          type.name || type.displayName || (Object.defineProperty(type, "name", {
            value: name
          }), type.displayName = name);
        }
      });
      return compare;
    };
    exports.startTransition = function (scope) {
      var prevTransition = ReactSharedInternals.T,
        currentTransition = {};
      currentTransition._updatedFibers = new Set();
      ReactSharedInternals.T = currentTransition;
      try {
        var returnValue = scope(),
          onStartTransitionFinish = ReactSharedInternals.S;
        null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
        "object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && (ReactSharedInternals.asyncTransitions++, returnValue.then(releaseAsyncTransition, releaseAsyncTransition), returnValue.then(noop, reportGlobalError));
      } catch (error) {
        reportGlobalError(error);
      } finally {
        null === prevTransition && currentTransition._updatedFibers && (scope = currentTransition._updatedFibers.size, currentTransition._updatedFibers.clear(), 10 < scope && console.warn("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table.")), null !== prevTransition && null !== currentTransition.types && (null !== prevTransition.types && prevTransition.types !== currentTransition.types && console.error("We expected inner Transitions to have transferred the outer types set and that you cannot add to the outer Transition while inside the inner.This is a bug in React."), prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
      }
    };
    exports.unstable_useCacheRefresh = function () {
      return resolveDispatcher().useCacheRefresh();
    };
    exports.use = function (usable) {
      return resolveDispatcher().use(usable);
    };
    exports.useActionState = function (action, initialState, permalink) {
      return resolveDispatcher().useActionState(action, initialState, permalink);
    };
    exports.useCallback = function (callback, deps) {
      return resolveDispatcher().useCallback(callback, deps);
    };
    exports.useContext = function (Context) {
      var dispatcher = resolveDispatcher();
      Context.$$typeof === REACT_CONSUMER_TYPE && console.error("Calling useContext(Context.Consumer) is not supported and will cause bugs. Did you mean to call useContext(Context) instead?");
      return dispatcher.useContext(Context);
    };
    exports.useDebugValue = function (value, formatterFn) {
      return resolveDispatcher().useDebugValue(value, formatterFn);
    };
    exports.useDeferredValue = function (value, initialValue) {
      return resolveDispatcher().useDeferredValue(value, initialValue);
    };
    exports.useEffect = function (create, deps) {
      null == create && console.warn("React Hook useEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      return resolveDispatcher().useEffect(create, deps);
    };
    exports.useEffectEvent = function (callback) {
      return resolveDispatcher().useEffectEvent(callback);
    };
    exports.useId = function () {
      return resolveDispatcher().useId();
    };
    exports.useImperativeHandle = function (ref, create, deps) {
      return resolveDispatcher().useImperativeHandle(ref, create, deps);
    };
    exports.useInsertionEffect = function (create, deps) {
      null == create && console.warn("React Hook useInsertionEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      return resolveDispatcher().useInsertionEffect(create, deps);
    };
    exports.useLayoutEffect = function (create, deps) {
      null == create && console.warn("React Hook useLayoutEffect requires an effect callback. Did you forget to pass a callback to the hook?");
      return resolveDispatcher().useLayoutEffect(create, deps);
    };
    exports.useMemo = function (create, deps) {
      return resolveDispatcher().useMemo(create, deps);
    };
    exports.useOptimistic = function (passthrough, reducer) {
      return resolveDispatcher().useOptimistic(passthrough, reducer);
    };
    exports.useReducer = function (reducer, initialArg, init) {
      return resolveDispatcher().useReducer(reducer, initialArg, init);
    };
    exports.useRef = function (initialValue) {
      return resolveDispatcher().useRef(initialValue);
    };
    exports.useState = function (initialState) {
      return resolveDispatcher().useState(initialState);
    };
    exports.useSyncExternalStore = function (subscribe, getSnapshot, getServerSnapshot) {
      return resolveDispatcher().useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
    };
    exports.useTransition = function () {
      return resolveDispatcher().useTransition();
    };
    exports.version = "19.2.0";
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
  }();
},13,[],"node_modules/.pnpm/react@19.2.0/node_modules/react/cjs/react.development.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  /**
   * Copyright (c) Nicolas Gallagher.
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var Platform = {
    OS: 'web',
    select: obj => 'web' in obj ? obj.web : obj.default,
    get isTesting() {
      if (process.env.NODE_ENV === 'test') {
        return true;
      }
      return false;
    },
    get Version() {
      return '0.0.0';
    }
  };
  var _default = Platform;
},18,[],"node_modules/.pnpm/react-native-web@0.21.2_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/react-native-web/dist/exports/Platform/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) 2013-present, Facebook, Inc.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */
  'use strict';

  var validateFormat = process.env.NODE_ENV !== "production" ? function (format) {
    if (format === undefined) {
      throw new Error('invariant(...): Second argument must be a string.');
    }
  } : function (format) {};
  /**
   * Use invariant() to assert state which your program assumes to be true.
   *
   * Provide sprintf-style format (only %s is supported) and arguments to provide
   * information about what broke and what you were expecting.
   *
   * The invariant message will be stripped in production, but the invariant will
   * remain to ensure logic does not differ in production.
   */

  function invariant(condition, format) {
    for (var _len = arguments.length, args = new Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
      args[_key - 2] = arguments[_key];
    }
    validateFormat(format);
    if (!condition) {
      var error;
      if (format === undefined) {
        error = new Error('Minified exception occurred; use the non-minified dev environment ' + 'for the full error message and additional helpful warnings.');
      } else {
        var argIndex = 0;
        error = new Error(format.replace(/%s/g, function () {
          return String(args[argIndex++]);
        }));
        error.name = 'Invariant Violation';
      }
      error.framesToPop = 1; // Skip invariant's own stack frame.

      throw error;
    }
  }
  module.exports = invariant;
},59,[],"node_modules/.pnpm/fbjs@3.0.5/node_modules/fbjs/lib/invariant.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   * @format
   */

  'use strict';

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return NativeEventEmitter;
    }
  });
  var _exportsPlatform = require(_dependencyMap[0], "../../../exports/Platform");
  var Platform = _interopDefault(_exportsPlatform);
  var _RCTDeviceEventEmitter = require(_dependencyMap[1], "./RCTDeviceEventEmitter");
  var RCTDeviceEventEmitter = _interopDefault(_RCTDeviceEventEmitter);
  var _fbjsLibInvariant = require(_dependencyMap[2], "fbjs/lib/invariant");
  var invariant = _interopDefault(_fbjsLibInvariant);
  /**
   * `NativeEventEmitter` is intended for use by Native Modules to emit events to
   * JavaScript listeners. If a `NativeModule` is supplied to the constructor, it
   * will be notified (via `addListener` and `removeListeners`) when the listener
   * count changes to manage "native memory".
   *
   * Currently, all native events are fired via a global `RCTDeviceEventEmitter`.
   * This means event names must be globally unique, and it means that call sites
   * can theoretically listen to `RCTDeviceEventEmitter` (although discouraged).
   */
  class NativeEventEmitter {
    constructor(nativeModule) {
      if (Platform.default.OS === 'ios') {
        (0, invariant.default)(nativeModule != null, '`new NativeEventEmitter()` requires a non-null argument.');
        this._nativeModule = nativeModule;
      }
    }
    addListener(eventType, listener, context) {
      var _this$_nativeModule;
      (_this$_nativeModule = this._nativeModule) == null ? void 0 : _this$_nativeModule.addListener(eventType);
      var subscription = RCTDeviceEventEmitter.default.addListener(eventType, listener, context);
      return {
        remove: () => {
          if (subscription != null) {
            var _this$_nativeModule2;
            (_this$_nativeModule2 = this._nativeModule) == null ? void 0 : _this$_nativeModule2.removeListeners(1);
            // $FlowFixMe[incompatible-use]
            subscription.remove();
            subscription = null;
          }
        }
      };
    }

    /**
     * @deprecated Use `remove` on the EventSubscription from `addListener`.
     */
    removeListener(eventType, listener) {
      var _this$_nativeModule3;
      (_this$_nativeModule3 = this._nativeModule) == null ? void 0 : _this$_nativeModule3.removeListeners(1);
      // NOTE: This will report a deprecation notice via `console.error`.
      // $FlowFixMe[prop-missing] - `removeListener` exists but is deprecated.
      RCTDeviceEventEmitter.default.removeListener(eventType, listener);
    }
    emit(eventType) {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      // Generally, `RCTDeviceEventEmitter` is directly invoked. But this is
      // included for completeness.
      RCTDeviceEventEmitter.default.emit(eventType, ...args);
    }
    removeAllListeners(eventType) {
      var _this$_nativeModule4;
      (0, invariant.default)(eventType != null, '`NativeEventEmitter.removeAllListener()` requires a non-null argument.');
      (_this$_nativeModule4 = this._nativeModule) == null ? void 0 : _this$_nativeModule4.removeListeners(this.listenerCount(eventType));
      RCTDeviceEventEmitter.default.removeAllListeners(eventType);
    }
    listenerCount(eventType) {
      return RCTDeviceEventEmitter.default.listenerCount(eventType);
    }
  }
},578,[18,5,59],"node_modules/.pnpm/react-native-web@0.21.2_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/react-native-web/dist/vendor/react-native/EventEmitter/NativeEventEmitter.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _vendorReactNativeEventEmitterNativeEventEmitter = require(_dependencyMap[0], "../../vendor/react-native/EventEmitter/NativeEventEmitter");
  var NativeEventEmitter = _interopDefault(_vendorReactNativeEventEmitterNativeEventEmitter);
  /**
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * 
   */

  var _default = NativeEventEmitter.default;
},646,[578],"node_modules/.pnpm/react-native-web@0.21.2_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/react-native-web/dist/exports/NativeEventEmitter/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  var _zustandVanilla = require(_dependencyMap[0], "zustand/vanilla");
  Object.keys(_zustandVanilla).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _zustandVanilla[k];
        }
      });
    }
  });
  var _zustandReact = require(_dependencyMap[1], "zustand/react");
  Object.keys(_zustandReact).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _zustandReact[k];
        }
      });
    }
  });
},1358,[1359,1360],"node_modules/.pnpm/zustand@5.0.12_@types+react@19.2.14_react@19.2.0_use-sync-external-store@1.6.0_react@19.2.0_/node_modules/zustand/esm/index.mjs");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "createStore", {
    enumerable: true,
    get: function () {
      return createStore;
    }
  });
  const createStoreImpl = createState => {
    let state;
    const listeners = /* @__PURE__ */new Set();
    const setState = (partial, replace) => {
      const nextState = typeof partial === "function" ? partial(state) : partial;
      if (!Object.is(nextState, state)) {
        const previousState = state;
        state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
        listeners.forEach(listener => listener(state, previousState));
      }
    };
    const getState = () => state;
    const getInitialState = () => initialState;
    const subscribe = listener => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    };
    const api = {
      setState,
      getState,
      getInitialState,
      subscribe
    };
    const initialState = state = createState(setState, getState, api);
    return api;
  };
  const createStore = createState => createState ? createStoreImpl(createState) : createStoreImpl;
},1359,[],"node_modules/.pnpm/zustand@5.0.12_@types+react@19.2.14_react@19.2.0_use-sync-external-store@1.6.0_react@19.2.0_/node_modules/zustand/esm/vanilla.mjs");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "create", {
    enumerable: true,
    get: function () {
      return create;
    }
  });
  Object.defineProperty(exports, "useStore", {
    enumerable: true,
    get: function () {
      return useStore;
    }
  });
  var _react = require(_dependencyMap[0], "react");
  var React = _interopDefault(_react);
  var _zustandVanilla = require(_dependencyMap[1], "zustand/vanilla");
  const identity = arg => arg;
  function useStore(api, selector = identity) {
    const slice = React.default.useSyncExternalStore(api.subscribe, React.default.useCallback(() => selector(api.getState()), [api, selector]), React.default.useCallback(() => selector(api.getInitialState()), [api, selector]));
    React.default.useDebugValue(slice);
    return slice;
  }
  const createImpl = createState => {
    const api = (0, _zustandVanilla.createStore)(createState);
    const useBoundStore = selector => useStore(api, selector);
    Object.assign(useBoundStore, api);
    return useBoundStore;
  };
  const create = createState => createState ? createImpl(createState) : createImpl;
},1360,[11,1359],"node_modules/.pnpm/zustand@5.0.12_@types+react@19.2.14_react@19.2.0_use-sync-external-store@1.6.0_react@19.2.0_/node_modules/zustand/esm/react.mjs");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "logger", {
    enumerable: true,
    get: function () {
      return logger;
    }
  });
  exports.createLogger = createLogger;
  exports.addLogSink = addLogSink;
  exports.removeLogSink = removeLogSink;
  /**
   * Structured Logging Service
   *
   * Provides environment-aware logging with proper sinks.
   * Replaces scattered __DEV__ && console.log patterns.
   */

  // Check if we're in development mode
  const isDev = typeof __DEV__ !== "undefined" ? __DEV__ : process.env.NODE_ENV === "development";

  // Console sink for development
  const consoleSink = entry => {
    const prefix = `[${entry.timestamp.slice(11, 23)}]`;
    const moduleTag = entry.module ? `[${entry.module}]` : "";
    const fullMessage = `${prefix}${moduleTag} ${entry.message}`;
    switch (entry.level) {
      case "debug":
        console.log(`🔍 ${fullMessage}`, entry.context ?? "");
        break;
      case "info":
        console.info(`ℹ️ ${fullMessage}`, entry.context ?? "");
        break;
      case "warn":
        console.warn(`⚠️ ${fullMessage}`, entry.context ?? "");
        break;
      case "error":
        console.error(`❌ ${fullMessage}`, entry.context ?? "");
        break;
    }
  };

  // Production sink - can be extended to send to remote logging service
  const productionSink = entry => {
    // In production, only log warnings and errors
    if (entry.level === "error" || entry.level === "warn") {
      // Could integrate with Sentry, LogRocket, etc.
      // For now, just use console but could be extended
      console[entry.level](entry.message, entry.context ?? "");
    }
  };

  // Active sinks based on environment
  const activeSinks = isDev ? [consoleSink] : [productionSink];

  /**
   * Internal log function
   */
  function log(level, message, context, module) {
    const entry = {
      level,
      message,
      context,
      timestamp: new Date().toISOString(),
      module
    };
    activeSinks.forEach(sink => {
      try {
        sink(entry);
      } catch {
        // Silently fail - don't let logging break the app
      }
    });
  }

  /**
   * Logger instance - use this for structured logging
   *
   * Usage:
   * ```ts
   * import { logger } from '@/services/logging';
   *
   * logger.debug('Looking up barcode', { barcode: '123456' });
   * logger.error('API call failed', { error: err.message });
   * ```
   */
  const logger = {
    debug: (message, context) => log("debug", message, normalizeContext(context)),
    info: (message, context) => log("info", message, normalizeContext(context)),
    warn: (message, context) => log("warn", message, normalizeContext(context)),
    error: (message, context) => log("error", message, normalizeContext(context))
  };

  /**
   * Create a scoped logger with module name prefix
   *
   * Usage:
   * ```ts
   * const log = createLogger('BarcodeService');
   * log.debug('Found item', { itemCode: '12345' });
   * // Outputs: [BarcodeService] Found item { itemCode: '12345' }
   * ```
   */
  function createLogger(module) {
    return {
      debug: (message, context) => log("debug", message, normalizeContext(context), module),
      info: (message, context) => log("info", message, normalizeContext(context), module),
      warn: (message, context) => log("warn", message, normalizeContext(context), module),
      error: (message, context) => log("error", message, normalizeContext(context), module)
    };
  }

  /**
   * Normalizes context into a Record<string, unknown>
   */
  function normalizeContext(context) {
    if (!context) return undefined;
    if (typeof context === "object" && context !== null && !Array.isArray(context)) {
      return context;
    }
    return {
      data: context
    };
  }

  /**
   * Add a custom log sink (e.g., for remote logging)
   */
  function addLogSink(sink) {
    activeSinks.push(sink);
  }

  /**
   * Remove a log sink
   */
  function removeLogSink(sink) {
    const index = activeSinks.indexOf(sink);
    if (index > -1) {
      activeSinks.splice(index, 1);
    }
  }
},1362,[],"src/services/logging.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "useNetworkStore", {
    enumerable: true,
    get: function () {
      return useNetworkStore;
    }
  });
  var _zustand = require(_dependencyMap[0], "zustand");
  const useNetworkStore = (0, _zustand.create)(set => ({
    isOnline: true,
    connectionType: "unknown",
    isInternetReachable: null,
    isRestrictedMode: false,
    setIsOnline: isOnline => set({
      isOnline
    }),
    setConnectionType: type => set({
      connectionType: type
    }),
    setIsInternetReachable: reachable => set({
      isInternetReachable: reachable
    }),
    setRestrictedMode: restricted => set({
      isRestrictedMode: restricted
    })
  }));
},1439,[1358],"src/store/networkStore.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "flags", {
    enumerable: true,
    get: function () {
      return flags;
    }
  });
  Object.defineProperty(exports, "getFlag", {
    enumerable: true,
    get: function () {
      return getFlag;
    }
  });
  Object.defineProperty(exports, "setFlagOverride", {
    enumerable: true,
    get: function () {
      return setFlagOverride;
    }
  });
  Object.defineProperty(exports, "clearFlagOverrides", {
    enumerable: true,
    get: function () {
      return clearFlagOverrides;
    }
  });
  var _servicesLogging = require(_dependencyMap[0], "../services/logging");
  const log = (0, _servicesLogging.createLogger)("flags");
  const LOCAL_OVERRIDE_KEY = "feature_flag_overrides_v1";
  const DEFAULT_FLAGS = {
    enableDeepLinks: true,
    enableHaptics: true,
    enableAnimations: true,
    enableSwipeActions: true,
    enableDebugMode: __DEV__,
    enableNetworkLogging: __DEV__,
    enableOfflineQueue: true,
    enableNotes: true,
    enablePublicRegistration: false,
    uiUpgradeMasterEnabled: true,
    uiAuthRedirectV2: true,
    uiThemeTokensV2: true,
    uiVisualSystemV2: true,
    uiSettingsV2: true,
    uiScanV2: true
  };
  const UI_EPIC_FLAGS = ["uiAuthRedirectV2", "uiThemeTokensV2", "uiVisualSystemV2", "uiSettingsV2", "uiScanV2"];
  const TRUE_VALUES = new Set(["1", "true", "yes", "on"]);
  const FALSE_VALUES = new Set(["0", "false", "no", "off"]);
  const parseFlagValue = raw => {
    if (!raw) return null;
    const normalized = raw.trim().toLowerCase();
    if (TRUE_VALUES.has(normalized)) return true;
    if (FALSE_VALUES.has(normalized)) return false;
    return null;
  };
  const readEnvOverride = flagName => {
    const envKey = `EXPO_PUBLIC_FLAG_${flagName}`;
    return parseFlagValue(process.env[envKey]);
  };
  const readQueryOverride = flagName => {
    if (typeof window === "undefined") return null;
    const search = window.location?.search;
    if (!search) return null;
    const params = new URLSearchParams(search);
    return parseFlagValue(params.get(`flag.${flagName}`) ?? undefined) ?? parseFlagValue(params.get(flagName) ?? undefined);
  };
  const readLocalOverrides = () => {
    if (typeof window === "undefined" || !window.localStorage) return {};
    try {
      const raw = window.localStorage.getItem(LOCAL_OVERRIDE_KEY);
      if (!raw) return {};
      const parsed = JSON.parse(raw);
      const overrides = {};
      for (const key of Object.keys(DEFAULT_FLAGS)) {
        const value = parsed[key];
        if (typeof value === "boolean") {
          overrides[key] = value;
        }
      }
      return overrides;
    } catch (error) {
      log.warn("Failed to parse local feature flag overrides", {
        error: error instanceof Error ? error.message : String(error)
      });
      return {};
    }
  };
  const writeLocalOverrides = overrides => {
    if (typeof window === "undefined" || !window.localStorage) return;
    try {
      window.localStorage.setItem(LOCAL_OVERRIDE_KEY, JSON.stringify(overrides));
    } catch (error) {
      log.warn("Failed to persist local feature flag overrides", {
        error: error instanceof Error ? error.message : String(error)
      });
    }
  };
  const resolveFlags = () => {
    const resolved = {
      ...DEFAULT_FLAGS
    };

    // 1) Build defaults (already copied above)
    // 2) Environment overrides
    for (const key of Object.keys(resolved)) {
      const envValue = readEnvOverride(key);
      if (envValue !== null) {
        resolved[key] = envValue;
      }
    }

    // 3) URL query overrides (web)
    for (const key of Object.keys(resolved)) {
      const queryValue = readQueryOverride(key);
      if (queryValue !== null) {
        resolved[key] = queryValue;
      }
    }

    // 4) Local persisted overrides (web)
    const localOverrides = readLocalOverrides();
    for (const key of Object.keys(localOverrides)) {
      const value = localOverrides[key];
      if (typeof value === "boolean") {
        resolved[key] = value;
      }
    }

    // Emergency kill switch for UI epic.
    if (!resolved.uiUpgradeMasterEnabled) {
      for (const key of UI_EPIC_FLAGS) {
        resolved[key] = false;
      }
    }
    return resolved;
  };
  const applyResolvedFlags = next => {
    for (const key of Object.keys(next)) {
      flags[key] = next[key];
    }
  };
  const flags = resolveFlags();
  const getFlag = flagName => flags[flagName];
  const setFlagOverride = (flagName, value) => {
    const localOverrides = readLocalOverrides();
    if (value === null) {
      delete localOverrides[flagName];
    } else {
      localOverrides[flagName] = value;
    }
    writeLocalOverrides(localOverrides);
    applyResolvedFlags(resolveFlags());
  };
  const clearFlagOverrides = () => {
    writeLocalOverrides({});
    applyResolvedFlags(resolveFlags());
  };
  if (__DEV__) {
    log.info("Resolved feature flags", flags);
  }
},1528,[1362],"src/constants/flags.ts");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  exports.configure = configure;
  exports.fetch = fetch;
  exports.refresh = refresh;
  exports.addEventListener = addEventListener;
  exports.useNetInfo = useNetInfo;
  exports.useNetInfoInstance = useNetInfoInstance;
  var _react = require(_dependencyMap[0], "react");
  var _reactNativeWebDistExportsPlatform = require(_dependencyMap[1], "react-native-web/dist/exports/Platform");
  var Platform = _interopDefault(_reactNativeWebDistExportsPlatform);
  var _internalDefaultConfiguration = require(_dependencyMap[2], "./internal/defaultConfiguration");
  var DEFAULT_CONFIGURATION = _interopDefault(_internalDefaultConfiguration);
  var _internalNativeInterface = require(_dependencyMap[3], "./internal/nativeInterface");
  var NativeInterface = _interopDefault(_internalNativeInterface);
  var _internalState = require(_dependencyMap[4], "./internal/state");
  var State = _interopDefault(_internalState);
  var _internalTypes = require(_dependencyMap[5], "./internal/types");
  Object.keys(_internalTypes).forEach(function (k) {
    if (k !== 'default' && !Object.prototype.hasOwnProperty.call(exports, k)) {
      Object.defineProperty(exports, k, {
        enumerable: true,
        get: function () {
          return _internalTypes[k];
        }
      });
    }
  });
  var Types = _interopNamespace(_internalTypes);
  /**
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * @format
   */

  // Stores the currently used configuration
  let _configuration = DEFAULT_CONFIGURATION.default;

  // Stores the singleton reference to the state manager
  let _state = null;
  const createState = () => {
    return new State.default(_configuration);
  };

  // Track ongoing requests
  let isRequestInProgress = false;
  let requestQueue = [];

  /**
   * Configures the library with the given configuration. Note that calling this will stop all
   * previously added listeners from being called again. It is best to call this right when your
   * application is started to avoid issues. The configuration sets up a global singleton instance.
   *
   * @param configuration The new configuration to set.
   */
  function configure(configuration) {
    _configuration = {
      ...DEFAULT_CONFIGURATION.default,
      ...configuration
    };
    if (_state) {
      _state.tearDown();
      _state = createState();
    }
    if (Platform.default.OS === 'ios') {
      NativeInterface.default.configure(configuration);
    }
  }

  /**
   * Returns a `Promise` that resolves to a `NetInfoState` object.
   * This function operates on the global singleton instance configured using `configure()`
   *
   * @param [requestedInterface] interface from which to obtain the information
   *
   * @returns A Promise which contains the current connection state.
   */
  function fetch(requestedInterface) {
    if (!_state) {
      _state = createState();
    }
    return _state.latest(requestedInterface);
  }

  /**
   * Force-refreshes the internal state of the global singleton managed by this library.
   *
   * @returns A Promise which contains the updated connection state.
   */
  function refresh() {
    if (!_state) {
      _state = createState();
    }

    // If a request is already in progress, return a promise that will resolve when the current request finishes
    if (isRequestInProgress) {
      return new Promise(resolve => {
        requestQueue.push(resolve);
      });
    }
    isRequestInProgress = true;
    return _state._fetchCurrentState().then(result => {
      requestQueue.forEach(resolve => resolve(result));
      requestQueue = [];
      return result;
    }).finally(() => {
      isRequestInProgress = false;
    });
  }

  /**
   * Subscribe to the global singleton's connection information. The callback is called with a parameter of type
   * [`NetInfoState`](README.md#netinfostate) whenever the connection state changes. Your listener
   * will be called with the latest information soon after you subscribe and then with any
   * subsequent changes afterwards. You should not assume that the listener is called in the same
   * way across devices or platforms.
   *
   * @param listener The listener which is called when the network state changes.
   *
   * @returns A function which can be called to unsubscribe.
   */
  function addEventListener(listener) {
    if (!_state) {
      _state = createState();
    }
    _state.add(listener);
    return () => {
      _state && _state.remove(listener);
    };
  }

  /**
   * A React Hook into this library's singleton which updates when the connection state changes.
   *
   * @param {Partial<Types.NetInfoConfiguration>} configuration - Configure the isolated network checker managed by this hook
   *
   * @returns The connection state.
   */
  function useNetInfo(configuration) {
    if (configuration) {
      configure(configuration);
    }
    const [netInfo, setNetInfo] = (0, _react.useState)({
      type: Types.NetInfoStateType.unknown,
      isConnected: null,
      isInternetReachable: null,
      details: null
    });
    (0, _react.useEffect)(() => {
      const unsubscribe = addEventListener(setNetInfo);
      return () => unsubscribe();
    }, []);
    return netInfo;
  }

  /**
   * A React Hook which manages an isolated instance of the network info manager.
   * This is not a hook into a singleton shared state. NetInfo.configure, NetInfo.addEventListener,
   * NetInfo.fetch, NetInfo.refresh are performed on a global singleton and have no affect on this hook.
   * @param {boolean} isPaused - Pause the internal network checks.
   * @param {Partial<Types.NetInfoConfiguration>} configuration - Configure the isolated network checker managed by this hook
   *
   * @returns the netInfo state and a refresh function
   */
  function useNetInfoInstance(isPaused = false, configuration) {
    const [networkInfoManager, setNetworkInfoManager] = (0, _react.useState)();
    const [netInfo, setNetInfo] = (0, _react.useState)({
      type: Types.NetInfoStateType.unknown,
      isConnected: null,
      isInternetReachable: null,
      details: null
    });
    (0, _react.useEffect)(() => {
      if (isPaused) {
        return;
      }
      const config = {
        ...DEFAULT_CONFIGURATION.default,
        ...configuration
      };
      const state = new State.default(config);
      setNetworkInfoManager(state);
      state.add(setNetInfo);
      return state.tearDown;
    }, [isPaused, configuration]);
    const refresh = (0, _react.useCallback)(() => {
      if (networkInfoManager && !isRequestInProgress) {
        isRequestInProgress = true;
        networkInfoManager._fetchCurrentState().finally(() => {
          isRequestInProgress = false;
        });
      }
    }, [networkInfoManager]);
    return {
      netInfo,
      refresh
    };
  }
  var _default = {
    configure,
    fetch,
    refresh,
    addEventListener,
    useNetInfo,
    useNetInfoInstance
  };
},1657,[11,18,1658,1659,1663,1662],"node_modules/.pnpm/@react-native-community+netinfo@11.5.2_react-native@0.83.6_@babel+core@7.29.0_@types+re_9cc5209e1f9e98e394c8c83c27d028e4/node_modules/@react-native-community/netinfo/lib/module/index.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  const DEFAULT_CONFIGURATION = {
    reachabilityUrl: '/',
    reachabilityMethod: "HEAD",
    reachabilityHeaders: {},
    reachabilityTest: response => Promise.resolve(response.status === 200),
    reachabilityShortTimeout: 5 * 1000,
    // 5s
    reachabilityLongTimeout: 60 * 1000,
    // 60s
    reachabilityRequestTimeout: 15 * 1000,
    // 15s
    reachabilityShouldRun: () => true,
    shouldFetchWiFiSSID: true,
    useNativeReachability: true
  };
  var _default = DEFAULT_CONFIGURATION;
},1658,[],"node_modules/.pnpm/@react-native-community+netinfo@11.5.2_react-native@0.83.6_@babel+core@7.29.0_@types+re_9cc5209e1f9e98e394c8c83c27d028e4/node_modules/@react-native-community/netinfo/lib/module/internal/defaultConfiguration.web.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _reactNativeWebDistExportsNativeEventEmitter = require(_dependencyMap[0], "react-native-web/dist/exports/NativeEventEmitter");
  var NativeEventEmitter = _interopDefault(_reactNativeWebDistExportsNativeEventEmitter);
  var _nativeModule = require(_dependencyMap[1], "./nativeModule");
  var RNCNetInfo = _interopDefault(_nativeModule);
  var _privateTypes = require(_dependencyMap[2], "./privateTypes");
  /**
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * @format
   */

  const nativeEventEmitter = new NativeEventEmitter.default();

  // Listen to connectivity events
  RNCNetInfo.default.addListener(_privateTypes.DEVICE_CONNECTIVITY_EVENT, event => {
    nativeEventEmitter.emit(_privateTypes.DEVICE_CONNECTIVITY_EVENT, event);
  });
  var _default = {
    ...RNCNetInfo.default,
    eventEmitter: nativeEventEmitter
  };
},1659,[646,1660,1661],"node_modules/.pnpm/@react-native-community+netinfo@11.5.2_react-native@0.83.6_@babel+core@7.29.0_@types+re_9cc5209e1f9e98e394c8c83c27d028e4/node_modules/@react-native-community/netinfo/lib/module/internal/nativeInterface.web.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return _default;
    }
  });
  var _privateTypes = require(_dependencyMap[0], "./privateTypes");
  var _types = require(_dependencyMap[1], "./types");
  /**
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * @format
   */

  // See https://wicg.github.io/netinfo/#dom-connectiontype

  // See https://wicg.github.io/netinfo/#dom-effectiveconnectiontype

  // https://wicg.github.io/netinfo/#dom-networkinformation-savedata

  // Create (optional) connection APIs on navigator

  // Use a constant test of this form because in SSR on next.js, optional chaining is not sufficient,
  // but this test correctly detects that window is not available and allows for conditionals before access
  const isWindowPresent = typeof window !== 'undefined';

  // Check if window exists and if the browser supports the connection API
  const connection = isWindowPresent && !window.hasOwnProperty('tizen') && !window.hasOwnProperty('webOS') ? window.navigator.connection || window.navigator.mozConnection || window.navigator.webkitConnection : undefined;

  // Map browser types to native types
  const typeMapping = {
    bluetooth: _types.NetInfoStateType.bluetooth,
    cellular: _types.NetInfoStateType.cellular,
    ethernet: _types.NetInfoStateType.ethernet,
    none: _types.NetInfoStateType.none,
    other: _types.NetInfoStateType.other,
    unknown: _types.NetInfoStateType.unknown,
    wifi: _types.NetInfoStateType.wifi,
    wimax: _types.NetInfoStateType.wimax,
    mixed: _types.NetInfoStateType.other
  };
  const effectiveTypeMapping = {
    '2g': _types.NetInfoCellularGeneration['2g'],
    '3g': _types.NetInfoCellularGeneration['3g'],
    '4g': _types.NetInfoCellularGeneration['4g'],
    'slow-2g': _types.NetInfoCellularGeneration['2g']
  };

  // Determine current state of connection
  const getCurrentState = _requestedInterface => {
    const isConnected = isWindowPresent ? navigator.onLine : false;
    const baseState = {
      isInternetReachable: null
    };

    // If we don't have a connection object, we return minimal information
    if (!connection) {
      if (isConnected) {
        const state = {
          ...baseState,
          isConnected: true,
          type: _types.NetInfoStateType.other,
          details: {
            isConnectionExpensive: false
          }
        };
        return state;
      }
      const state = {
        ...baseState,
        isConnected: false,
        isInternetReachable: false,
        type: _types.NetInfoStateType.none,
        details: null
      };
      return state;
    }

    // Otherwise try to return detailed information
    const isConnectionExpensive = connection.saveData;
    const type = connection.type ? typeMapping[connection.type] : isConnected ? _types.NetInfoStateType.other : _types.NetInfoStateType.unknown;
    if (type === _types.NetInfoStateType.bluetooth) {
      const state = {
        ...baseState,
        isConnected: true,
        type,
        details: {
          isConnectionExpensive
        }
      };
      return state;
    } else if (type === _types.NetInfoStateType.cellular) {
      const state = {
        ...baseState,
        isConnected: true,
        type,
        details: {
          isConnectionExpensive,
          cellularGeneration: effectiveTypeMapping[connection.effectiveType] || null,
          carrier: null
        }
      };
      return state;
    } else if (type === _types.NetInfoStateType.ethernet) {
      const state = {
        ...baseState,
        isConnected: true,
        type,
        details: {
          isConnectionExpensive,
          ipAddress: null,
          subnet: null
        }
      };
      return state;
    } else if (type === _types.NetInfoStateType.wifi) {
      const state = {
        ...baseState,
        isConnected: true,
        type,
        details: {
          isConnectionExpensive,
          ssid: null,
          bssid: null,
          strength: null,
          ipAddress: null,
          subnet: null,
          frequency: null,
          linkSpeed: null,
          rxLinkSpeed: null,
          txLinkSpeed: null
        }
      };
      return state;
    } else if (type === _types.NetInfoStateType.wimax) {
      const state = {
        ...baseState,
        isConnected: true,
        type,
        details: {
          isConnectionExpensive
        }
      };
      return state;
    } else if (type === _types.NetInfoStateType.none) {
      const state = {
        ...baseState,
        isConnected: false,
        isInternetReachable: false,
        type,
        details: null
      };
      return state;
    } else if (type === _types.NetInfoStateType.unknown) {
      const state = {
        ...baseState,
        isConnected,
        isInternetReachable: null,
        type,
        details: null
      };
      return state;
    }
    const state = {
      ...baseState,
      isConnected: true,
      type: _types.NetInfoStateType.other,
      details: {
        isConnectionExpensive
      }
    };
    return state;
  };
  const handlers = [];
  const nativeHandlers = [];
  const RNCNetInfo = {
    addListener(type, handler) {
      switch (type) {
        case _privateTypes.DEVICE_CONNECTIVITY_EVENT:
          {
            const nativeHandler = () => {
              handler(getCurrentState());
            };
            if (connection) {
              connection.addEventListener('change', nativeHandler);
            } else {
              if (isWindowPresent) {
                window.addEventListener('online', nativeHandler, false);
                window.addEventListener('offline', nativeHandler, false);
              }
            }

            // Remember handlers
            handlers.push(handler);
            nativeHandlers.push(nativeHandler);
            break;
          }
      }
    },
    removeListeners(type, handler) {
      switch (type) {
        case _privateTypes.DEVICE_CONNECTIVITY_EVENT:
          {
            // Get native handler
            const index = handlers.indexOf(handler);
            const nativeHandler = nativeHandlers[index];
            if (connection) {
              connection.removeEventListener('change', nativeHandler);
            } else {
              if (isWindowPresent) {
                window.removeEventListener('online', nativeHandler);
                window.removeEventListener('offline', nativeHandler);
              }
            }

            // Remove handlers
            handlers.splice(index, 1);
            nativeHandlers.splice(index, 1);
            break;
          }
      }
    },
    async getCurrentState(requestedInterface) {
      return getCurrentState(requestedInterface);
    },
    configure() {
      return;
    }
  };
  var _default = RNCNetInfo;
},1660,[1661,1662],"node_modules/.pnpm/@react-native-community+netinfo@11.5.2_react-native@0.83.6_@babel+core@7.29.0_@types+re_9cc5209e1f9e98e394c8c83c27d028e4/node_modules/@react-native-community/netinfo/lib/module/internal/nativeModule.web.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "DEVICE_CONNECTIVITY_EVENT", {
    enumerable: true,
    get: function () {
      return DEVICE_CONNECTIVITY_EVENT;
    }
  });
  /**
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * @format
   */

  const DEVICE_CONNECTIVITY_EVENT = 'netInfo.networkStatusDidChange';

  // Certain properties are optional when sent by the native module and are handled by the JS code
},1661,[],"node_modules/.pnpm/@react-native-community+netinfo@11.5.2_react-native@0.83.6_@babel+core@7.29.0_@types+re_9cc5209e1f9e98e394c8c83c27d028e4/node_modules/@react-native-community/netinfo/lib/module/internal/privateTypes.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "NetInfoStateType", {
    enumerable: true,
    get: function () {
      return NetInfoStateType;
    }
  });
  Object.defineProperty(exports, "NetInfoCellularGeneration", {
    enumerable: true,
    get: function () {
      return NetInfoCellularGeneration;
    }
  });
  /**
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * @format
   */

  let NetInfoStateType = /*#__PURE__*/function (NetInfoStateType) {
    NetInfoStateType["unknown"] = "unknown";
    NetInfoStateType["none"] = "none";
    NetInfoStateType["cellular"] = "cellular";
    NetInfoStateType["wifi"] = "wifi";
    NetInfoStateType["bluetooth"] = "bluetooth";
    NetInfoStateType["ethernet"] = "ethernet";
    NetInfoStateType["wimax"] = "wimax";
    NetInfoStateType["vpn"] = "vpn";
    NetInfoStateType["other"] = "other";
    return NetInfoStateType;
  }({});
  let NetInfoCellularGeneration = /*#__PURE__*/function (NetInfoCellularGeneration) {
    NetInfoCellularGeneration["2g"] = "2g";
    NetInfoCellularGeneration["3g"] = "3g";
    NetInfoCellularGeneration["4g"] = "4g";
    NetInfoCellularGeneration["5g"] = "5g";
    return NetInfoCellularGeneration;
  }({});
},1662,[],"node_modules/.pnpm/@react-native-community+netinfo@11.5.2_react-native@0.83.6_@babel+core@7.29.0_@types+re_9cc5209e1f9e98e394c8c83c27d028e4/node_modules/@react-native-community/netinfo/lib/module/internal/types.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (e) Object.keys(e).forEach(function (k) {
      var d = Object.getOwnPropertyDescriptor(e, k);
      Object.defineProperty(n, k, d.get ? d : {
        enumerable: true,
        get: function () {
          return e[k];
        }
      });
    });
    n.default = e;
    return n;
  }
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return State;
    }
  });
  var _nativeInterface = require(_dependencyMap[0], "./nativeInterface");
  var NativeInterface = _interopDefault(_nativeInterface);
  var _internetReachability = require(_dependencyMap[1], "./internetReachability");
  var InternetReachability = _interopDefault(_internetReachability);
  var _privateTypes = require(_dependencyMap[2], "./privateTypes");
  var PrivateTypes = _interopNamespace(_privateTypes);
  function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }
    return obj;
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : String(i);
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  /**
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * @format
   */

  class State {
    constructor(configuration) {
      _defineProperty(this, "_nativeEventSubscription", null);
      _defineProperty(this, "_subscriptions", new Set());
      _defineProperty(this, "_latestState", null);
      _defineProperty(this, "_internetReachability", void 0);
      _defineProperty(this, "_handleNativeStateUpdate", state => {
        // Update the internet reachability module
        this._internetReachability.update(state);

        // Convert the state from native to JS shape
        const convertedState = this._convertState(state);

        // Update the listeners
        this._latestState = convertedState;
        this._subscriptions.forEach(handler => handler(convertedState));
      });
      _defineProperty(this, "_handleInternetReachabilityUpdate", isInternetReachable => {
        if (!this._latestState) {
          return;
        }
        const nextState = {
          ...this._latestState,
          isInternetReachable
        };
        this._latestState = nextState;
        this._subscriptions.forEach(handler => handler(nextState));
      });
      _defineProperty(this, "_fetchCurrentState", async requestedInterface => {
        const state = await NativeInterface.default.getCurrentState(requestedInterface);

        // Update the internet reachability module
        this._internetReachability.update(state);
        // Convert and store the new state
        const convertedState = this._convertState(state);
        if (!requestedInterface) {
          this._latestState = convertedState;
          this._subscriptions.forEach(handler => handler(convertedState));
        }
        return convertedState;
      });
      _defineProperty(this, "_convertState", input => {
        if (typeof input.isInternetReachable === 'boolean') {
          return input;
        } else {
          return {
            ...input,
            isInternetReachable: this._internetReachability.currentState()
          };
        }
      });
      _defineProperty(this, "latest", requestedInterface => {
        if (requestedInterface) {
          return this._fetchCurrentState(requestedInterface);
        } else if (this._latestState) {
          return Promise.resolve(this._latestState);
        } else {
          return this._fetchCurrentState();
        }
      });
      _defineProperty(this, "add", handler => {
        // Add the subscription handler to our set
        this._subscriptions.add(handler);

        // Send it the latest data we have
        if (this._latestState) {
          handler(this._latestState);
        } else {
          this.latest().then(handler);
        }
      });
      _defineProperty(this, "remove", handler => {
        this._subscriptions.delete(handler);
      });
      _defineProperty(this, "tearDown", () => {
        if (this._internetReachability) {
          this._internetReachability.tearDown();
        }
        if (this._nativeEventSubscription) {
          this._nativeEventSubscription.remove();
        }
        this._subscriptions.clear();
      });
      // Add the listener to the internet connectivity events
      this._internetReachability = new InternetReachability.default(configuration, this._handleInternetReachabilityUpdate);

      // Add the subscription to the native events
      this._nativeEventSubscription = NativeInterface.default.eventEmitter.addListener(PrivateTypes.DEVICE_CONNECTIVITY_EVENT, this._handleNativeStateUpdate);

      // Fetch the current state from the native module
      this._fetchCurrentState();
    }
  }
},1663,[1659,1664,1661],"node_modules/.pnpm/@react-native-community+netinfo@11.5.2_react-native@0.83.6_@babel+core@7.29.0_@types+re_9cc5209e1f9e98e394c8c83c27d028e4/node_modules/@react-native-community/netinfo/lib/module/internal/state.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function () {
      return InternetReachability;
    }
  });
  function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
      Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
      });
    } else {
      obj[key] = value;
    }
    return obj;
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : String(i);
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  /**
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *
   * @format
   */

  class InternetReachability {
    constructor(configuration, listener) {
      _defineProperty(this, "_configuration", void 0);
      _defineProperty(this, "_listener", void 0);
      _defineProperty(this, "_isInternetReachable", undefined);
      _defineProperty(this, "_currentInternetReachabilityCheckHandler", null);
      _defineProperty(this, "_currentTimeoutHandle", null);
      _defineProperty(this, "_setIsInternetReachable", isInternetReachable => {
        if (this._isInternetReachable === isInternetReachable) {
          return;
        }
        this._isInternetReachable = isInternetReachable;
        this._listener(this._isInternetReachable);
      });
      _defineProperty(this, "_setExpectsConnection", expectsConnection => {
        // Cancel any pending check
        if (this._currentInternetReachabilityCheckHandler !== null) {
          this._currentInternetReachabilityCheckHandler.cancel();
          this._currentInternetReachabilityCheckHandler = null;
        }
        // Cancel any pending timeout
        if (this._currentTimeoutHandle !== null) {
          clearTimeout(this._currentTimeoutHandle);
          this._currentTimeoutHandle = null;
        }
        if (expectsConnection && this._configuration.reachabilityShouldRun()) {
          // If we expect a connection, start the process for finding if we have one
          // Set the state to "null" if it was previously false
          if (!this._isInternetReachable) {
            this._setIsInternetReachable(null);
          }
          // Start a network request to check for internet
          this._currentInternetReachabilityCheckHandler = this._checkInternetReachability();
        } else {
          // If we don't expect a connection or don't run reachability check, just change the state to "false"
          this._setIsInternetReachable(false);
        }
      });
      _defineProperty(this, "_checkInternetReachability", () => {
        const controller = new AbortController();
        const responsePromise = fetch(this._configuration.reachabilityUrl, {
          headers: this._configuration.reachabilityHeaders,
          method: this._configuration.reachabilityMethod,
          cache: 'no-cache',
          signal: controller.signal
        });

        // Create promise that will reject after the request timeout has been reached
        let timeoutHandle;
        const timeoutPromise = new Promise((_, reject) => {
          timeoutHandle = setTimeout(() => reject('timedout'), this._configuration.reachabilityRequestTimeout);
        });

        // Create promise that makes it possible to cancel a pending request through a reject
        // eslint-disable-next-line @typescript-eslint/no-empty-function
        let cancel = () => {};
        const cancelPromise = new Promise((_, reject) => {
          cancel = () => reject('canceled');
        });
        const promise = Promise.race([responsePromise, timeoutPromise, cancelPromise]).then(response => {
          return this._configuration.reachabilityTest(response);
        }).then(result => {
          this._setIsInternetReachable(result);
          const nextTimeoutInterval = this._isInternetReachable ? this._configuration.reachabilityLongTimeout : this._configuration.reachabilityShortTimeout;
          this._currentTimeoutHandle = setTimeout(this._checkInternetReachability, nextTimeoutInterval);
        }).catch(error => {
          if ('canceled' === error) {
            controller.abort();
          } else {
            if ('timedout' === error) {
              controller.abort();
            }
            this._setIsInternetReachable(false);
            this._currentTimeoutHandle = setTimeout(this._checkInternetReachability, this._configuration.reachabilityShortTimeout);
          }
        })
        // Clear request timeout and propagate any errors
        .then(() => {
          clearTimeout(timeoutHandle);
        }, error => {
          clearTimeout(timeoutHandle);
          throw error;
        });
        return {
          promise,
          cancel
        };
      });
      _defineProperty(this, "update", state => {
        if (typeof state.isInternetReachable === 'boolean' && this._configuration.useNativeReachability) {
          this._setIsInternetReachable(state.isInternetReachable);
        } else {
          this._setExpectsConnection(state.isConnected);
        }
      });
      _defineProperty(this, "currentState", () => {
        return this._isInternetReachable;
      });
      _defineProperty(this, "tearDown", () => {
        // Cancel any pending check
        if (this._currentInternetReachabilityCheckHandler !== null) {
          this._currentInternetReachabilityCheckHandler.cancel();
          this._currentInternetReachabilityCheckHandler = null;
        }

        // Cancel any pending timeout
        if (this._currentTimeoutHandle !== null) {
          clearTimeout(this._currentTimeoutHandle);
          this._currentTimeoutHandle = null;
        }
      });
      this._configuration = configuration;
      this._listener = listener;
    }
  }
},1664,[],"node_modules/.pnpm/@react-native-community+netinfo@11.5.2_react-native@0.83.6_@babel+core@7.29.0_@types+re_9cc5209e1f9e98e394c8c83c27d028e4/node_modules/@react-native-community/netinfo/lib/module/internal/internetReachability.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  function _interopDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  Object.defineProperty(exports, "initializeNetworkListener", {
    enumerable: true,
    get: function () {
      return initializeNetworkListener;
    }
  });
  var _reactNativeCommunityNetinfo = require(_dependencyMap[0], "@react-native-community/netinfo");
  var NetInfo = _interopDefault(_reactNativeCommunityNetinfo);
  var _constantsFlags = require(_dependencyMap[1], "../constants/flags");
  var _storeNetworkStore = require(_dependencyMap[2], "../store/networkStore");
  function toReachableValue(isConnected, isInternetReachable) {
    // This app commonly runs on a local LAN backend.
    // NetInfo's `isInternetReachable=false` can mean "no internet" while LAN still works.
    // Treat it as UNKNOWN (null) rather than definitively offline.
    if (!isConnected) return null;
    return isInternetReachable === true ? true : null;
  }
  function applyNetInfoState(state) {
    const isConnected = state.isConnected ?? false;
    const reachable = toReachableValue(isConnected, state.isInternetReachable);
    const type = state.type ?? "unknown";
    const store = _storeNetworkStore.useNetworkStore.getState();
    store.setIsOnline(isConnected);
    store.setConnectionType(type);
    store.setIsInternetReachable(reachable);

    // When the network changes, clear restricted mode so the app can re-check.
    // Restricted mode will be re-enabled by the API interceptor if still applicable.
    store.setRestrictedMode(false);
    if (_constantsFlags.flags.enableNetworkLogging) {
      // Keep logs minimal in production.
      console.log("[NetInfo]", {
        isConnected,
        isInternetReachable: state.isInternetReachable,
        normalizedReachable: reachable,
        type
      });
    }
  }
  const initializeNetworkListener = () => {
    // Initialize store from a one-time fetch so we don't depend on the first event.
    NetInfo.default.fetch().then(state => applyNetInfoState(state)).catch(() => {
      // If NetInfo fails, leave defaults; API layer will degrade gracefully.
    });
    const unsubscribe = NetInfo.default.addEventListener(state => {
      applyNetInfoState(state);
    });
    return unsubscribe;
  };
},1999,[1657,1528,1439],"src/services/networkService.ts");
//# sourceMappingURL=http://127.0.0.1:8095/src/services/networkService.map?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable&modulesOnly=true&runModule=false