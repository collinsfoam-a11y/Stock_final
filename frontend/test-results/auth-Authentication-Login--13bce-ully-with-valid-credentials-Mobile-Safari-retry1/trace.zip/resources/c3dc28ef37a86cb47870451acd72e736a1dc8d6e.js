__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "lightTheme", {
    enumerable: true,
    get: function () {
      return lightTheme;
    }
  });
  Object.defineProperty(exports, "darkTheme", {
    enumerable: true,
    get: function () {
      return darkTheme;
    }
  });
  Object.defineProperty(exports, "ThemeService", {
    enumerable: true,
    get: function () {
      return ThemeService;
    }
  });
  const lightTheme = {
    background: "#ffffff",
    surface: "#f8f9fa",
    surfaceDark: "#e9ecef",
    text: "#212529",
    textSecondary: "#6c757d",
    textTertiary: "#868e96",
    primary: "#007bff",
    secondary: "#6c757d",
    success: "#28a745",
    error: "#dc3545",
    warning: "#ffc107",
    info: "#17a2b8",
    border: "#dee2e6",
    overlayPrimary: "rgba(0, 123, 255, 0.1)"
  };
  const darkTheme = {
    background: "#121212",
    surface: "#1e1e1e",
    surfaceDark: "#2d2d2d",
    text: "#ffffff",
    textSecondary: "#b0b0b0",
    textTertiary: "#888888",
    primary: "#0d6efd",
    secondary: "#6c757d",
    success: "#198754",
    error: "#dc3545",
    warning: "#ffc107",
    info: "#0dcaf0",
    border: "#495057",
    overlayPrimary: "rgba(13, 110, 253, 0.1)"
  };
  class ThemeService {
    static currentTheme = "system";
    static listeners = [];
    static async initialize() {
      // Initialize theme settings if needed
      return Promise.resolve();
    }
    static getTheme() {
      // Return full theme object (colors + utils)
      // For now returning colors structure to match ErrorBoundary expectation
      // In a real app this would return the Unistyles theme object
      const colors = this.getThemeColors(this.currentTheme);
      return {
        colors
      };
    }
    static setTheme(theme) {
      this.currentTheme = theme;
      const themeObj = this.getTheme();
      this.listeners.forEach(listener => listener(themeObj));
    }
    static subscribe(listener) {
      this.listeners.push(listener);
      return () => {
        this.listeners = this.listeners.filter(l => l !== listener);
      };
    }
    static getThemeColors(theme) {
      switch (theme) {
        case "dark":
          return darkTheme;
        case "light":
        default:
          return lightTheme;
      }
    }
  }
},1444,[],"src/services/themeService.ts");
//# sourceMappingURL=http://127.0.0.1:8095/src/services/themeService.map?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable&modulesOnly=true&runModule=false