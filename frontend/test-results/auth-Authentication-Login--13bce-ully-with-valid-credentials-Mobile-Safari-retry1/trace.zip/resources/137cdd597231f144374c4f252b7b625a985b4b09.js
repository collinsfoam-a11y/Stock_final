__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "env", {
    enumerable: true,
    get: function () {
      return env;
    }
  });
  const dotEnvModules = require(_dependencyMap[0], "../../../../../..");
  const env = !dotEnvModules.keys().length ? process.env : {
    ...process.env,
    ...['.env', '.env.development', '.env.local', '.env.development.local'].reduce((acc, file) => {
      return {
        ...acc,
        ...(dotEnvModules(file)?.default ?? {})
      };
    }, {})
  };
},1340,[1341],"node_modules/.pnpm/expo@55.0.26_@babel+core@7.29.0_@expo+dom-webview@55.0.5_@expo+metro-runtime@55.0.11_ex_bdec6bb26e1e837c438f67856f11b7de/node_modules/expo/virtual/env.js");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  function metroEmptyContext(request) {
    let e = new Error('No modules in context');
    e.code = 'MODULE_NOT_FOUND';
    throw e;
  }

  // Return the keys that can be resolved.
  metroEmptyContext.keys = () => [];

  // Return the module identifier for a user request.
  metroEmptyContext.resolve = function metroContextResolve(request) {
    throw new Error('Unimplemented Metro module context functionality');
  };
  module.exports = metroEmptyContext;
},1341,[],"../frontend?ctx=1122149ada429c11a789cd9dfdcaefb64b6dd8f5");
__d(function (global, require, _$$_IMPORT_DEFAULT, _$$_IMPORT_ALL, module, exports, _dependencyMap) {
  "use strict";

  var _s = $RefreshSig$();
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
  Object.defineProperty(exports, "initReactotron", {
    enumerable: true,
    get: function () {
      return initReactotron;
    }
  });
  var _expoVirtualEnv = require(_dependencyMap[0], "expo/virtual/env");
  let initialized = false;
  const isReactotronEnabled = () => _expoVirtualEnv.env.EXPO_PUBLIC_ENABLE_REACTOTRON === "true";
  const loadReactotron = () => {
    if (!isReactotronEnabled()) {
      return null;
    }
    try {
      // Reactotron is an optional dev-only dependency, so keep the load dynamic.
      // eslint-disable-next-line @typescript-eslint/no-require-imports, import/no-extraneous-dependencies, import/no-unresolved
      const loaded = require(_dependencyMap[1], "reactotron-react-native");
      if (loaded && typeof loaded === "object" && "default" in loaded) {
        return loaded.default ?? null;
      }
      return loaded;
    } catch (error) {
      console.warn("Reactotron package not available, skipping initialization", error);
      return null;
    }
  };
  const initReactotron = async () => {
    _s();
    if (!__DEV__ || initialized) return;
    const Reactotron = loadReactotron();
    if (!Reactotron) {
      return;
    }
    Reactotron.configure({
      name: "Stock Final"
    }).useReactNative().connect();
    if (typeof Reactotron.clear === "function") {
      Reactotron.clear();
    }
    initialized = true;
    console.log("Reactotron initialized");
  };
  _s(initReactotron, "YNGxd3LV4s8IPFWjySBzuaoqPjE=", true);
},1998,[1340,null],"src/services/devtools/reactotron.ts");
//# sourceMappingURL=http://127.0.0.1:8095/src/services/devtools/reactotron.map?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable&modulesOnly=true&runModule=false